/**
*   @file    global_defs.h
*
*   @brief   Contains the global defined macros.
*
*   @addtogroup security_installer
*   @{
*/
/*==================================================================================================
*
*   Copyright 2020-2021 NXP.
*
*   This software is owned or controlled by NXP and may only be used strictly in accordance with
*   the applicable license terms. By expressly accepting such terms or by downloading, installing,
*   activating and/or otherwise using the software, you are agreeing that you have read, and that
*   you agree to comply with and are bound by, such license terms. If you do not agree to
*   be bound by the applicable license terms, then you may not retain, install, activate or
*   otherwise use the software.
==================================================================================================*/

#ifndef GLOBAL_DEFS_H
#define GLOBAL_DEFS_H

#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "global_types.h"
#include "hse_interface.h"

/*==================================================================================================
*                              SOURCE FILE VERSION INFORMATION
==================================================================================================*/

/*==================================================================================================
*                                     FILE VERSION CHECKS
==================================================================================================*/

/*==================================================================================================
*                                          CONSTANTS
==================================================================================================*/

/*==================================================================================================
*                                      DEFINES AND MACROS
==================================================================================================*/

#if !defined(ARRAY_SIZE)
    #define ARRAY_SIZE(x) (sizeof(x) / sizeof((x)[0]))
#endif

#if !defined(BITS_TO_BYTES)
    #define BITS_TO_BYTES(bitLen)               ((uint16_t)(((bitLen) + 7U) / 8U))
#endif
#if !defined(BYTES_TO_BITS)
    #define BYTES_TO_BITS(byteLen)              ((byteLen) * 8U)
#endif

#define ASSERT(condition)   \
    do {                    \
        if(!(condition))    \
            __asm("BKPT #0");       \
    } while(0)

#define ASSERT_RETRY(condition) \
    while(!(condition));

#ifdef DEBUG
    #define DEBUG_LOOP(var) while(!(var))
#else
    #define DEBUG_LOOP(var)
#endif

#define NVM_SHE_AES128_BOOT_KEY                 GET_KEY_HANDLE(HSE_KEY_CATALOG_ID_NVM, 0, 1)

#define NVM_AES128_PROVISION_KEY                GET_KEY_HANDLE(HSE_KEY_CATALOG_ID_NVM, 1, 0)
#define NVM_AES128_BOOT_KEY                     GET_KEY_HANDLE(HSE_KEY_CATALOG_ID_NVM, 1, 1)
#define NVM_AES128_AUTHORIZATION_KEY            GET_KEY_HANDLE(HSE_KEY_CATALOG_ID_NVM, 1, 2)

#define NVM_AES256_PROVISION_KEY0               GET_KEY_HANDLE(HSE_KEY_CATALOG_ID_NVM, 2, 0)
#define NVM_AES256_PROVISION_KEY1               GET_KEY_HANDLE(HSE_KEY_CATALOG_ID_NVM, 2, 1)
#define NVM_AES256_KEY2                         GET_KEY_HANDLE(HSE_KEY_CATALOG_ID_NVM, 2, 2)
#define NVM_AES256_KEY3                         GET_KEY_HANDLE(HSE_KEY_CATALOG_ID_NVM, 2, 3)

#define NVM_HMAC_KEY0                           GET_KEY_HANDLE(HSE_KEY_CATALOG_ID_NVM, 3, 0)
#define NVM_HMAC_KEY1                           GET_KEY_HANDLE(HSE_KEY_CATALOG_ID_NVM, 3, 1)

#define NVM_ECC_BOOT_KEY_HANDLE                 GET_KEY_HANDLE(HSE_KEY_CATALOG_ID_NVM, 4, 0)
#define NVM_ECC_BOOT_KEY_HANDLE_1               GET_KEY_HANDLE(HSE_KEY_CATALOG_ID_NVM, 4, 1)
#define NVM_ECC_KEY_HANDLE                      GET_KEY_HANDLE(HSE_KEY_CATALOG_ID_NVM, 4, 2)
#define NVM_ECC_KEY_HANDLE_PAIR_EDDSA           GET_KEY_HANDLE(HSE_KEY_CATALOG_ID_NVM, 4, 3)

#define NVM_ECC_KEY_HANDLE_PUBLIC               GET_KEY_HANDLE(HSE_KEY_CATALOG_ID_NVM, 5, 0)
#define NVM_ECC_KEY_HANDLE_PUBLIC_1             GET_KEY_HANDLE(HSE_KEY_CATALOG_ID_NVM, 5, 1)

/* Copy of authorization keys to generate the signature over the challenge */
#define NVM_RSA2048_PAIR_CUSTAUTH_HANDLE0       GET_KEY_HANDLE(HSE_KEY_CATALOG_ID_NVM, 7, 0)
#define NVM_RSA2048_PAIR_CUSTAUTH_HANDLE1       GET_KEY_HANDLE(HSE_KEY_CATALOG_ID_NVM, 7, 1)

/* Must be in NVM */
#define NVM_RSA2048_PUB_CUSTAUTH_HANDLE0        GET_KEY_HANDLE(HSE_KEY_CATALOG_ID_NVM, 8, 0)
#define NVM_RSA2048_PUB_CUSTAUTH_HANDLE1        GET_KEY_HANDLE(HSE_KEY_CATALOG_ID_NVM, 8, 1)

/* Points to a ECC key pair NVM slot */
#define SHE_RAM_KEY_HANDLE                      GET_KEY_HANDLE(HSE_KEY_CATALOG_ID_RAM, 0, 0)

#define RAM_AES128_KEY0                         GET_KEY_HANDLE(HSE_KEY_CATALOG_ID_RAM, 1, 0)
#define RAM_AES128_KEY1                         GET_KEY_HANDLE(HSE_KEY_CATALOG_ID_RAM, 1, 1)

#define RAM_AES256_KEY0                         GET_KEY_HANDLE(HSE_KEY_CATALOG_ID_RAM, 2, 0)
#define RAM_AES256_KEY1                         GET_KEY_HANDLE(HSE_KEY_CATALOG_ID_RAM, 2, 1)
#define RAM_AES256_KEY2                         GET_KEY_HANDLE(HSE_KEY_CATALOG_ID_RAM, 2, 2)
#define RAM_AES128_ADKP_KEY                     GET_KEY_HANDLE(HSE_KEY_CATALOG_ID_RAM, 2, 3)

#define RAM_HMAC_KEY0                           GET_KEY_HANDLE(HSE_KEY_CATALOG_ID_RAM, 3, 0)
#define RAM_HMAC_KEY1                           GET_KEY_HANDLE(HSE_KEY_CATALOG_ID_RAM, 3, 1)

#define RAM_ECC_PAIR_KEY_HANDLE                 GET_KEY_HANDLE(HSE_KEY_CATALOG_ID_RAM, 6, 0)

#define RAM_ECC_PUB_KEY_HANDLE                  GET_KEY_HANDLE(HSE_KEY_CATALOG_ID_RAM, 7, 0)
#define RAM_ECC_PUB_KEY_HANDLE_SLOT1            GET_KEY_HANDLE(HSE_KEY_CATALOG_ID_RAM, 7, 1)
#define RAM_ECC_PUB_KEY_HANDLE_SLOT3            GET_KEY_HANDLE(HSE_KEY_CATALOG_ID_RAM, 7, 3)

#define DERIVED_KEY_HANDLE                      GET_KEY_HANDLE(HSE_KEY_CATALOG_ID_RAM, 8, 0)
#define BD_SHARED_SECRET_KEY_HANDLE             GET_KEY_HANDLE(HSE_KEY_CATALOG_ID_RAM, 8, 1)

#define DH_SHARED_SECRET_HANDLE                 GET_KEY_HANDLE(HSE_KEY_CATALOG_ID_RAM, 9, 0)
#define RAM_SHARED_SECRET4096_KEY1              GET_KEY_HANDLE(HSE_KEY_CATALOG_ID_RAM, 9, 1)

#define DH_SHARED_SECRET_HANDLE_0               RAM_AES256_KEY0
#define DH_SHARED_SECRET_HANDLE_1               RAM_SHARED_SECRET4096_KEY1

#define SECRET_SRC_KEY_HANDLE                   RAM_AES256_KEY0

#define ALIGN(value, alignment)                 (((value) + (alignment) - 1) & (~((alignment) - 1)))
#define ADDR_NOT_NULL(addr)                     ((0x0UL != (uintptr_t)(addr)) && (0xFFFFFFFFUL != (uintptr_t)(addr)))

#define MU0                     (0U)
#define MU1                     (1U)
#define MU2                     (2U)
#define MU3                     (3U)

/*==================================================================================================
*                                             ENUMS
==================================================================================================*/

/*==================================================================================================
                                 STRUCTURES AND OTHER TYPEDEFS
==================================================================================================*/

/*==================================================================================================
                                 GLOBAL VARIABLE DECLARATIONS
==================================================================================================*/

/*==================================================================================================
                                     FUNCTION PROTOTYPES
==================================================================================================*/

#ifdef __cplusplus
}
#endif

#endif /* GLOBAL_DEFS_H */

/** @} */

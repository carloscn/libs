/*==================================================================================================
*   Project              : RTD AUTOSAR 4.4
*   Platform             : CORTEXM
*   Peripheral           : Emios Siul2 Wkpu LpCmp
*   Dependencies         : none
*
*   Autosar Version      : 4.4.0
*   Autosar Revision     : ASR_REL_4_4_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.0
*   Build Version        : S32K3_RTD_1_0_0_HF01_D2111_ASR_REL_4_4_REV_0000_20211105
*
*   (c) Copyright 2020 - 2021 NXP Semiconductors
*   All Rights Reserved.
*
*   NXP Confidential. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

/**
 *   @file          Wkpu_PBCfg.c
 *   @implements    Icu_PBCfg.c_Artifact
 *   @version       1.0.0
 *
 *   @brief   AUTOSAR Icu - contains the data exported by the Icu module
 *   @details Contains the information that will be exported by the module, as requested by Autosar.
 *
 *   @addtogroup wkpu_icu_ip WKPU IPL
 *   @{
 */
 


#ifdef __cplusplus
extern "C"{
#endif

 /*==================================================================================================
 *                                         INCLUDE FILES
 * 1) system and project includes
 * 2) needed interfaces from external units
 * 3) internal and external interfaces from this unit
 *================================================================================================*/
#include "StandardTypes.h"
#include "Wkpu_Ip_Types.h"

/*==================================================================================================
 *                              SOURCE FILE VERSION INFORMATION
 *================================================================================================*/

#define WKPU_IP_PBCFG_SA_BOARD_INITPERIPHERALS_VENDOR_ID_C                    43
#define WKPU_IP_PBCFG_SA_BOARD_INITPERIPHERALS_AR_RELEASE_MAJOR_VERSION_C     4
#define WKPU_IP_PBCFG_SA_BOARD_INITPERIPHERALS_AR_RELEASE_MINOR_VERSION_C     4
#define WKPU_IP_PBCFG_SA_BOARD_INITPERIPHERALS_AR_RELEASE_REVISION_VERSION_C  0
#define WKPU_IP_PBCFG_SA_BOARD_INITPERIPHERALS_SW_MAJOR_VERSION_C             1
#define WKPU_IP_PBCFG_SA_BOARD_INITPERIPHERALS_SW_MINOR_VERSION_C             0
#define WKPU_IP_PBCFG_SA_BOARD_INITPERIPHERALS_SW_PATCH_VERSION_C             0

/*==================================================================================================
 *                                      FILE VERSION CHECKS
 *================================================================================================*/
/* Check if header file and StandardTypes.h file are of the same Autosar version */
#ifndef DISABLE_MCAL_INTERMODULE_ASR_CHECK
    #if ((WKPU_IP_PBCFG_SA_BOARD_INITPERIPHERALS_AR_RELEASE_MAJOR_VERSION_C != STD_AR_RELEASE_MAJOR_VERSION) || \
         (WKPU_IP_PBCFG_SA_BOARD_INITPERIPHERALS_AR_RELEASE_MINOR_VERSION_C != STD_AR_RELEASE_MINOR_VERSION))
    #error "AutoSar Version Numbers of Wkpu_Ip_SA_BOARD_INITPERIPHERALS_PBcfg.c and StandardTypes.h are different"
    #endif
#endif

/* Check if source file and ICU header file are of the same vendor */
#if (WKPU_IP_PBCFG_SA_BOARD_INITPERIPHERALS_VENDOR_ID_C != WKPU_IP_TYPES_VENDOR_ID)
    #error "Wkpu_Ip_SA_BOARD_INITPERIPHERALS_PBcfg.c and Wkpu_Ip_Types.h have different vendor IDs"
#endif
/* Check if source file and ICU header file are of the same AutoSar version */
#if ((WKPU_IP_PBCFG_SA_BOARD_INITPERIPHERALS_AR_RELEASE_MAJOR_VERSION_C != WKPU_IP_TYPES_AR_RELEASE_MAJOR_VERSION) || \
     (WKPU_IP_PBCFG_SA_BOARD_INITPERIPHERALS_AR_RELEASE_MINOR_VERSION_C != WKPU_IP_TYPES_AR_RELEASE_MINOR_VERSION) || \
     (WKPU_IP_PBCFG_SA_BOARD_INITPERIPHERALS_AR_RELEASE_REVISION_VERSION_C != WKPU_IP_TYPES_AR_RELEASE_REVISION_VERSION))
    #error "AutoSar Version Numbers of Wkpu_Ip_SA_BOARD_INITPERIPHERALS_PBcfg.c and Wkpu_Ip_Types.h are different"
#endif
/* Check if source file and ICU header file are of the same Software version */
#if ((WKPU_IP_PBCFG_SA_BOARD_INITPERIPHERALS_SW_MAJOR_VERSION_C != WKPU_IP_TYPES_SW_MAJOR_VERSION) || \
     (WKPU_IP_PBCFG_SA_BOARD_INITPERIPHERALS_SW_MINOR_VERSION_C != WKPU_IP_TYPES_SW_MINOR_VERSION) || \
     (WKPU_IP_PBCFG_SA_BOARD_INITPERIPHERALS_SW_PATCH_VERSION_C != WKPU_IP_TYPES_SW_PATCH_VERSION))
#error "Software Version Numbers of Wkpu_Ip_SA_BOARD_INITPERIPHERALS_PBcfg.c and Wkpu_Ip_Types.h are different"
#endif
/*================================================================================================*/

/*==================================================================================================
 *                          LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
 *================================================================================================*/

/*==================================================================================================
 *                                       LOCAL MACROS
 *================================================================================================*/

/*==================================================================================================
 *                                      LOCAL CONSTANTS
 *================================================================================================*/

/*==================================================================================================
 *                                       LOCAL VARIABLES
 *================================================================================================*/

/*==================================================================================================
 *                                       GLOBAL FUNCTIONS
 *================================================================================================*/
#define ICU_START_SEC_CODE
#include "Icu_MemMap.h"
extern void IcuSw2Callback(void);
#define ICU_STOP_SEC_CODE
#include "Icu_MemMap.h"
/*==================================================================================================
 *                                       GLOBAL CONSTANTS
 *================================================================================================*/
#define ICU_START_SEC_CONFIG_DATA_UNSPECIFIED
#include "Icu_MemMap.h" 
 
/*
 *  @brief    PB_BOARD_InitPeripherals WKPU Channels Configuration
 */
const Wkpu_Ip_ChannelConfigType Wkpu_Ip_ChannelConfig_PB_BOARD_InitPeripherals[1U] =
{
    /** @brief IcuWkpu_Channel_0 */
    {
        /** @brief Wkpu HW Channel used by the Icu channel */
        47U,
        /** @brief Wkpu HW Channel Filter enable */
        FALSE,
        /** @brief Wkpu HW Channel Pullup enable */
        FALSE,
        /** @brief Wkpu Default Start Edge*/
        WKPU_IP_RISING_EDGE,
        /** @brief Wkpu Channel Callback  */
        NULL_PTR,
        IcuSw2Callback,    /* Notification function */
        /** @brief Wkpu Callback Param1*/
        47U
        }
};
/*
 *  @brief    PB_BOARD_InitPeripherals Default WKPU IP Configuration
 */
const Wkpu_Ip_IrqConfigType Wkpu_Ip_Config_PB_BOARD_InitPeripherals = 
{
    #if (defined (WKPU_IP_NMI_API) && (STD_ON == WKPU_IP_NMI_API))
        /** @brief Number of Wkpu NMI channels in the Icu configuration */
        (uint8)0U,
        /** @brief Pointer to the array of Wkpu enabled Icu channel configurations */
        NULL_PTR,
    #endif
            /** @brief Number of Wkpu channels in the Icu configuration */
        (uint8)1U,
        /** @brief Pointer to the array of Wkpu channel configurations */
        &Wkpu_Ip_ChannelConfig_PB_BOARD_InitPeripherals
    };

#define ICU_STOP_SEC_CONFIG_DATA_UNSPECIFIED
#include "Icu_MemMap.h"  
/*==================================================================================================
 *                                       GLOBAL VARIABLES
 *================================================================================================*/

/*==================================================================================================
 *                                   LOCAL FUNCTION PROTOTYPES
 *================================================================================================*/

/*==================================================================================================
 *                                       LOCAL FUNCTIONS
 *================================================================================================*/

#ifdef __cplusplus
}
#endif

/** @} */


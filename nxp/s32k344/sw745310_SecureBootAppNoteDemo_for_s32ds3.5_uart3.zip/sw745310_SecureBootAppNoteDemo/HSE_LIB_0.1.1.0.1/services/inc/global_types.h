/**
*   @file    global_types.h
*
*   @brief   Contains the global defined types.
*
*   @addtogroup security_installer
*   @{
*/
/*==================================================================================================
*
*    Copyright 2020-2021 NXP.
*
*   This software is owned or controlled by NXP and may only be used strictly in accordance with
*   the applicable license terms. By expressly accepting such terms or by downloading, installing,
*   activating and/or otherwise using the software, you are agreeing that you have read, and that
*   you agree to comply with and are bound by, such license terms. If you do not agree to
*   be bound by the applicable license terms, then you may not retain, install, activate or
*   otherwise use the software.
==================================================================================================*/

#ifndef GLOBAL_TYPES_H
#define GLOBAL_TYPES_H

#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/

#include "std_typedefs.h"

#include "hse_interface.h"
/*==================================================================================================
*                              SOURCE FILE VERSION INFORMATION
==================================================================================================*/

/*==================================================================================================
*                                     FILE VERSION CHECKS
==================================================================================================*/

/*==================================================================================================
*                                          CONSTANTS
==================================================================================================*/

/*==================================================================================================
*                                      DEFINES AND MACROS
==================================================================================================*/

/*==================================================================================================
*                                             ENUMS
==================================================================================================*/



/*==================================================================================================
                                 STRUCTURES AND OTHER TYPEDEFS
==================================================================================================*/

typedef struct
{
    /*00h*/    uint32_t IVT_header;            /**< @brief IVT header marker */

    /*04h*/    uint32_t bootCfgWord;           /**< @brief Boot Configuration Word */

    /*08h*/    uint32_t reserved1;             /**< @brief 4 bytes reserved */

    /*0ch*/    uint32_t pAppImg_addr_0;        /**< @brief Application address for Boot Target 0 */

    /*10h*/    uint32_t reserved2;             /**< @brief 4 bytes reserved */

    /*14h*/    uint32_t pAppImg_addr_1;        /**< @brief Application address for Boot Target 1 */

    /*18h*/    uint32_t reserved3[2];             /**< @brief 4 bytes reserved */
    /*1ch*/
    /*20h*/    uint32_t pXRDC_Config;              /**< @brief XRDC configuration */

    /*24h*/    uint32_t LCCfgWord;             /**< @brief Life-Cycle configuration word */

    /*28h*/    uint32_t reserved4;

    /*2ch*/    uint32_t pHSE;                  /**< @brief pointer to HSE image */

    /*30h*/    uint32_t AppBL;                  /**< @brief 192 bytes reserved */

    /*34h*/    uint32_t reserved5[1];         /**< @brief 192 bytes reserved */

    /*38h*/    uint32_t AppBL_backup;          /**< @brief 192 bytes reserved */

    /*3ch*/    uint32_t reserved6[45];         /**< @brief 192 bytes reserved */

    /*F0h*/    uint32_t GMAC[4];               /**< @brief GMAC TAG over the IVT image */
} ivt_t;
#if 0
typedef struct
{
    /*0x00h*/    uint8_t hdrTag;                    /**< @brief App header tag shall be 0xD5. */

    /*0x01h*/    uint8_t reserved1[2];              /**< @brief Reserved field has no impact. Set to all zeroes. */

    /*0x03h*/    uint8_t hdrVersion;                /**< @brief App header version shall be 0x60. */

    /*0x04h*/    uint32_t pAppDestAddres;           /**< @brief The destination address where the application will be copied. Note : HSE-B, it is NULL to execute the code from flash. */

    /*0x08h*/    uint32_t pAppStartEntry ;          /**< @brief The address of the first instruction to be executed. */

    /*0x0ch*/    uint32_t codeLength ;              /**< @brief Length of application image. */

    /*0x10h*/    uint8_t coreId;                    /**< @brief The application core ID that will be un-gated. Note : Valid for HSE-B devices only , S32K344 set 0. For HSE-H core id defined in IVT. */

    /* .ARM.exidx */
    /*0x11h*/    uint8_t reserved2[0x40u-0x11u];            /**< @brief Reserved field has no impact. Set to all zeroes */

    /*0x40h*/       /* app code bin */

    /*0x40h+N*/     /* app header tag (HMAC) */
} app_header_t;
#else
typedef hseAppHeader_t app_header_t ;
#endif

typedef struct
{
  uint32_t  Header;
  uint32_t  MDAConfig_ProcessorCore0;
  uint32_t  MDAConfig_eDMA_AHB;
  uint32_t  MDAConfig_TestPort_AHB;
  uint32_t  MDAConfig_ProcessorCore1;
  uint32_t  MDAConfig_ENET_AHB;
  uint32_t  Reserved0[10];
  uint32_t  PDAC[14][2];
  uint32_t  Reserved2[20];
  uint8_t   CMAC[16];
} xrdc_config_t;

typedef struct
{
    uint8_t tag;              /**< Tag field */
    uint8_t len[2];           /**< Length field in bytes (big-endian) */
    uint8_t par;              /**< Parameters field */
} hseIvtDcdHdr_t;

/*==================================================================================================
                                 GLOBAL VARIABLE DECLARATIONS
==================================================================================================*/

/*==================================================================================================
                                     FUNCTION PROTOTYPES
==================================================================================================*/

#ifdef __cplusplus
}
#endif

#endif /* GLOBAL_TYPES_H */

/** @} */

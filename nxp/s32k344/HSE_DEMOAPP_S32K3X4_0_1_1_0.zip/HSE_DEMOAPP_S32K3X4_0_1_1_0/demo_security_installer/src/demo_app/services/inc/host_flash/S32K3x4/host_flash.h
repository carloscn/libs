/*============================================================================*/

/*==================================================================================================
*
*   Copyright 2020-2021 NXP.
*
*   This software is owned or controlled by NXP and may only be used strictly in accordance with
*   the applicable license terms. By expressly accepting such terms or by downloading, installing,
*   activating and/or otherwise using the software, you are agreeing that you have read, and that
*   you agree to comply with and are bound by, such license terms. If you do not agree to
*   be bound by the applicable license terms, then you may not retain, install, activate or
*   otherwise use the software.
==================================================================================================*/
/*============================================================================*/

/*=============================================================================
                                   Description
==============================================================================*/
/**
 *   @file    host_flash.h
 *
 *   @brief   This file contains host flash api.
 */

#ifndef HOST_FLASH_H
#define HOST_FLASH_H
/*=============================================================================
 *                                 INCLUDE FILES
 =============================================================================*/
#include "hse_common_types.h"
#include "Fls_Registers.h"
#include "Fls_Api.h"
/*=============================================================================
                                      MACROS
==============================================================================*/
#define HOST_CODE_MEMORY_TYPE			HSE_FW_BLOCK2_CODE_MEMORY
#define BACKUP_ADDRESS_OFFSET			0x00200000UL

#define UTEST_FLASH_SEC         FLS_UTEST_ARRAY_0_S000
#define DATA_FLASH_SEC          FLS_DATA_ARRAY_0_BLOCK_4_S000

#define BLOCK_0_SEC 			FLS_CODE_ARRAY_0_BLOCK_0_S000 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S001 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S002 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S003 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S004 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S005 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S006 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S007 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S008 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S009 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S010 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S011 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S012 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S013 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S014 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S015 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S016 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S017 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S018 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S019 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S020 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S021 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S022 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S023 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S024 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S025 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S026 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S027 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S028 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S029 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S030 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S031 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S032 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S033 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S034 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S035 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S036 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S037 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S038 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S039 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S040 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S041 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S042 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S043 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S044 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S045 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S046 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S047 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S048 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S049 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S050 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S051 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S052 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S053 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S054 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S055 ,  \
								FLS_CODE_ARRAY_0_BLOCK_0_S056 ,  \
                                FLS_CODE_ARRAY_0_BLOCK_0_S057 /*0x00472000*/
#define BLOCK_1_SEC            	FLS_UTEST_ARRAY_0_S000

#define BLOCK_2_SEC 			FLS_CODE_ARRAY_0_BLOCK_2_S256, \
								FLS_CODE_ARRAY_0_BLOCK_2_S257, \
								FLS_CODE_ARRAY_0_BLOCK_2_S258, \
								FLS_CODE_ARRAY_0_BLOCK_2_S259, \
								FLS_CODE_ARRAY_0_BLOCK_2_S260, \
								FLS_CODE_ARRAY_0_BLOCK_2_S261, \
								FLS_CODE_ARRAY_0_BLOCK_2_S262, \
								FLS_CODE_ARRAY_0_BLOCK_2_S263, \
								FLS_CODE_ARRAY_0_BLOCK_2_S264, \
								FLS_CODE_ARRAY_0_BLOCK_2_S265, \
								FLS_CODE_ARRAY_0_BLOCK_2_S266, \
								FLS_CODE_ARRAY_0_BLOCK_2_S267, \
								FLS_CODE_ARRAY_0_BLOCK_2_S268, \
								FLS_CODE_ARRAY_0_BLOCK_2_S269, \
								FLS_CODE_ARRAY_0_BLOCK_2_S270, \
								FLS_CODE_ARRAY_0_BLOCK_2_S271, \
								FLS_CODE_ARRAY_0_BLOCK_2_S272, \
								FLS_CODE_ARRAY_0_BLOCK_2_S273, \
								FLS_CODE_ARRAY_0_BLOCK_2_S274, \
								FLS_CODE_ARRAY_0_BLOCK_2_S275, \
								FLS_CODE_ARRAY_0_BLOCK_2_S276, \
								FLS_CODE_ARRAY_0_BLOCK_2_S277, \
								FLS_CODE_ARRAY_0_BLOCK_2_S278, \
								FLS_CODE_ARRAY_0_BLOCK_2_S279, \
								FLS_CODE_ARRAY_0_BLOCK_2_S280, \
								FLS_CODE_ARRAY_0_BLOCK_2_S281, \
								FLS_CODE_ARRAY_0_BLOCK_2_S282, \
								FLS_CODE_ARRAY_0_BLOCK_2_S283, \
								FLS_CODE_ARRAY_0_BLOCK_2_S284, \
								FLS_CODE_ARRAY_0_BLOCK_2_S285, \
								FLS_CODE_ARRAY_0_BLOCK_2_S286, \
								FLS_CODE_ARRAY_0_BLOCK_2_S287, \
								FLS_CODE_ARRAY_0_BLOCK_2_S288, \
								FLS_CODE_ARRAY_0_BLOCK_2_S289, \
								FLS_CODE_ARRAY_0_BLOCK_2_S290, \
								FLS_CODE_ARRAY_0_BLOCK_2_S291, \
								FLS_CODE_ARRAY_0_BLOCK_2_S292, \
								FLS_CODE_ARRAY_0_BLOCK_2_S293, \
								FLS_CODE_ARRAY_0_BLOCK_2_S294, \
								FLS_CODE_ARRAY_0_BLOCK_2_S295, \
								FLS_CODE_ARRAY_0_BLOCK_2_S296, \
								FLS_CODE_ARRAY_0_BLOCK_2_S297, \
								FLS_CODE_ARRAY_0_BLOCK_2_S298, \
								FLS_CODE_ARRAY_0_BLOCK_2_S299, \
								FLS_CODE_ARRAY_0_BLOCK_2_S300, \
								FLS_CODE_ARRAY_0_BLOCK_2_S301, \
								FLS_CODE_ARRAY_0_BLOCK_2_S302, \
								FLS_CODE_ARRAY_0_BLOCK_2_S303, \
								FLS_CODE_ARRAY_0_BLOCK_2_S304, \
								FLS_CODE_ARRAY_0_BLOCK_2_S305, \
								FLS_CODE_ARRAY_0_BLOCK_2_S306, \
								FLS_CODE_ARRAY_0_BLOCK_2_S307, \
								FLS_CODE_ARRAY_0_BLOCK_2_S308, \
								FLS_CODE_ARRAY_0_BLOCK_2_S309, \
								FLS_CODE_ARRAY_0_BLOCK_2_S310, \
								FLS_CODE_ARRAY_0_BLOCK_2_S311, \
								FLS_CODE_ARRAY_0_BLOCK_2_S312, \
								FLS_CODE_ARRAY_0_BLOCK_2_S313   /*0x00672000*/

#define BLOCK_3_SEC             FLS_UTEST_ARRAY_0_S000
   
#define BLOCK_4_SEC             FLS_UTEST_ARRAY_0_S000

#define BLOCK_5_SEC             FLS_UTEST_ARRAY_0_S000

#define BLOCK_6_SEC             FLS_UTEST_ARRAY_0_S000

#define BLOCK_7_SEC             FLS_UTEST_ARRAY_0_S000
/*=============================================================================
 *                        TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
 =============================================================================*/

/*=============================================================================
                                     CONSTANTS
==============================================================================*/

/*=============================================================================
 *                               GLOBAL VARIABLES
 =============================================================================*/

/*=============================================================================
                                FUNCTION PROTOTYPES
==============================================================================*/

#endif

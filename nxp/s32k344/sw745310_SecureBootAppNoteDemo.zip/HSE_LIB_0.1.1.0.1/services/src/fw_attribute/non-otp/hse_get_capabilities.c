/**
*   @file    hse_get_version.c
*
*   @brief   Example of HSE service - get version
*   @details Example of simplest HSE service - get FW version.
*
*   @addtogroup [HSE_GET_VERSION]
*   @{
*/
/*=============================================================================
*
*   Copyright 2020-2021 NXP.
*
*   This software is owned or controlled by NXP and may only be used strictly in accordance with
*   the applicable license terms. By expressly accepting such terms or by downloading, installing,
*   activating and/or otherwise using the software, you are agreeing that you have read, and that
*   you agree to comply with and are bound by, such license terms. If you do not agree to
*   be bound by the applicable license terms, then you may not retain, install, activate or
*   otherwise use the software.
=============================================================================*/

#ifdef __cplusplus
extern "C"{
#endif

/*=============================================================================
*                              INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
=============================================================================*/

#include "global_variables.h"
#include "hse_host_attrs.h"

/*=============================================================================
 *              LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
 * ==========================================================================*/

/*=============================================================================
 *                        LOCAL MACROS
 * ==========================================================================*/
#define HSE_CAPABILITY_LENGTH     8U
/*=============================================================================
 *                       LOCAL CONSTANTS
 * ==========================================================================*/

/*=============================================================================
 *                      LOCAL VARIABLES
 * ==========================================================================*/

/*=============================================================================
 *                     GLOBAL CONSTANTS
 * ==========================================================================*/

/*=============================================================================
 *                      GLOBAL VARIABLES
 * ==========================================================================*/

/*=============================================================================
 *                      LOCAL FUNCTION PROTOTYPES
 * ==========================================================================*/

/*=============================================================================
 *                       LOCAL FUNCTIONS
 * ==========================================================================*/

/*=============================================================================
 *                       GLOBAL FUNCTIONS
 * ==========================================================================*/

/******************************************************************************
 * Function:    HSE_GetCapabilities_Example
 * Description: Example of HSE service - get HSE FW capabilities
******************************************************************************/
hseSrvResponse_t HSE_GetCapabilities_Example( uint8_t *phseCapabilites )
{
    hseSrvResponse_t srvResponse;
    srvResponse = GetAttr( HSE_CAPABILITIES_ATTR_ID, HSE_CAPABILITY_LENGTH,
            phseCapabilites );
    ASSERT(HSE_SRV_RSP_OK == srvResponse);
    return srvResponse;
}

#ifdef __cplusplus
}
#endif

/** @} */

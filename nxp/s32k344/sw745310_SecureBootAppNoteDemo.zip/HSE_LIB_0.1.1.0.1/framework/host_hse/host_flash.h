/*============================================================================*/

/*==================================================================================================
*
*   Copyright 2020-2021 NXP.
*
*   This software is owned or controlled by NXP and may only be used strictly in accordance with
*   the applicable license terms. By expressly accepting such terms or by downloading, installing,
*   activating and/or otherwise using the software, you are agreeing that you have read, and that
*   you agree to comply with and are bound by, such license terms. If you do not agree to
*   be bound by the applicable license terms, then you may not retain, install, activate or
*   otherwise use the software.
==================================================================================================*/
/*============================================================================*/

/*=============================================================================
                                   Description
==============================================================================*/
/**
 *   @file    host_flash.h
 *
 *   @brief   This file contains host flash api.
 */

#ifndef HOST_FLASH_H
#define HOST_FLASH_H
/*=============================================================================
 *                                 INCLUDE FILES
 =============================================================================*/
#include "Mcal.h"
#include "C40_Ip.h"
/*=============================================================================
                                      MACROS
==============================================================================*/
#define FLS_MASTER_ID                (0U)

/* program data registers (DATA0 - DATA31) */
#define FLS_PROGRAM_DATA_REG_SIZE    (4u)
#define FLS_PROGRAM_DATA_REG_NUM     (32u)
#define FLS_PROGRAM_MAX_LEN          (C40_DATA_SIZE_BYTES_U32)
#define FLS_PROGRAM_MIN_LEN          (C40_WRITE_DOUBLE_WORD)

#define FLS_SECTOR_MIN_ERASE_SIZE    (C40_SECTOR_SIZE)


#define HOST_FLASH_RAM_CODE         (1)

/*=============================================================================
 *                        TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
 =============================================================================*/
typedef enum
{
    FLS_JOB_OK                = 0x5AA5U,    /* Successful job */
    FLS_JOB_FAILED            = 0x27E4U,    /* Errors because of failed hardware */
    FLS_TIMEOUT_FAILED        = 0x2BD4U,    /* Errors because of failed timeout */
    FLS_INPUT_PARAM_FAILED    = 0x2DB4U,    /* Errors because of input parma */
    FLS_BLANK_CHECK_FAILED    = 0x2E74U,    /* Errors because of failed blank check */
    FLS_PROGRAM_VERIFY_FAILED = 0x33CCU,    /* Errors because of failed program verify */
    FLS_USER_TEST_BREAK_SBC   = 0x35ACU,    /* Break single bit correction */
    FLS_USER_TEST_BREAK_DBD   = 0x366CU     /* Break double bit detection */
} Fls_CheckStatusType;
/*=============================================================================
                                     CONSTANTS
==============================================================================*/

/*=============================================================================
 *                               GLOBAL VARIABLES
 =============================================================================*/

/*=============================================================================
                                FUNCTION PROTOTYPES
==============================================================================*/

Fls_CheckStatusType HostFlash_Init(void);

#if ( 1 == HOST_FLASH_RAM_CODE )
Fls_CheckStatusType __attribute__((section (".ramcode"))) HostFlash_Program(uint32_t DestAddress,
        uint8_t* SourceAddress, uint32_t Length);

Fls_CheckStatusType __attribute__((section (".ramcode"))) HostFlash_EraseSector(uint32_t DestAddress,
        uint32_t NoOfSectors);

Fls_CheckStatusType __attribute__((section (".ramcode"))) HostFlash_EraseByLen(uint32_t Address, uint32_t Length);
#else
Fls_CheckStatusType HostFlash_Program(uint32_t DestAddress,
        uint8_t* SourceAddress, uint32_t Length);

Fls_CheckStatusType HostFlash_EraseSector(uint32_t DestAddress,
        uint32_t NoOfSectors);

Fls_CheckStatusType HostFlash_EraseByLen(uint32_t Address, uint32_t Length);
#endif



#endif

Project: S32K344_SecureBootAppABSwap_Example_100_341_FW0110
Example Description:
    This example project to configure secure boot on S32K3xx(AB_SWAP).
Hardware:
    SCH-47478 REV A/SCH-47478 REV C
Environment:
    S32DS 3.4.1
Software:
    SW32K3_RTD_4.4_1.0.0
    HSE_FW_S32K3X4_0_1_1_0(AB_SWAP)
Test steps:
S32K344_SecureBootCfgABSwap_Example_100_341_FW0110 is referred to as "Cfg" 
S32K344_SecureBootAppABSwap_Example_100_341_FW0110 is referred to as "App" 
    1. build App project first(DEBUG_FLASH), the linkfile(.ld) of the cfg project will reference the binary file(.bin) compiled by the app project.
    2. build Cfg project(DEBUG_FLASH), connect uart console@9600bps
    3. Debug the application on the board(S32K3 white board SCH-47478)
    4. run Cfg program(low address), out put info via uart and wait it completed
    5. Press SW3(partition swap and functional reset)
    6. run Cfg program(high address), if secure boot configuration on both side completed, change IVT BOOT SEQ
    7. Press SW3(partition swap and functional reset)
    8. run App program(low address)
    9. run App program(high address)
    

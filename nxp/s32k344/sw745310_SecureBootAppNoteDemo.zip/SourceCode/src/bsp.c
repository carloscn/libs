/*
 * bsp.c
 *
 *  Created on: Jan 27, 2021
 *      Author: nxf55009
 */

#include <bsp.h>


volatile uint8_t erase_flag = 0 ;

volatile uint8_t reset_flag = 0 ;

static Hse_Ip_MuStateType HseIp_aMuState[HSE_NUM_OF_MU_INSTANCES];





void IcuSw2Callback(void)
{
    Siul2_Dio_Ip_TogglePins(LED_DIO_PORT, (1<<LED_DIO_Q2_PIN));

    /* TODO : add erase */

    erase_flag = 1 ;

    /* ensure erase */
    HSE_EraseKeys();

}


void IcuSw3Callback(void)
{
    Siul2_Dio_Ip_TogglePins(LED_DIO_PORT, (1<<LED_DIO_Q3_PIN));
#ifdef HSE_S32K3XX_OTA_ENABLE
    hseSrvResponse_t HseResponse;
    HseResponse = HSE_ActivatePassiveBlock();
    ASSERT(HSE_SRV_RSP_OK == HseResponse);
#endif

#ifdef SECURE_BOOT_CFG
    Power_Ip_MC_ME_SocTriggerResetEvent( POWER_IP_FUNC_RESET_MODE );
#endif

#ifdef SECURE_BOOT_APP
#if ( false == MEASURE_PERFORMANCE )
    Power_Ip_MC_ME_SocTriggerResetEvent( POWER_IP_FUNC_RESET_MODE );
#else
    /* performance */
    Power_Ip_MC_ME_SocTriggerResetEvent( POWER_IP_DEST_RESET_MODE );
#endif
#endif
    reset_flag = 1 ;
}




void PitNotification(void)
{
    Siul2_Dio_Ip_TogglePins(LED_DIO_PORT, (1<<LED_DIO_Q4_PIN));
}

extern void Mu_Ip_Mu0_OredRx_Isr(void);
extern void Mu_Ip_Mu0_OredGP_Isr(void);

void BSP_Init(void)
{
    /* =============================================================================================================================== */
    /*    Initialize Hse Ip layer for MU0 instance                                                                                     */
    /* =============================================================================================================================== */
    Hse_Ip_StatusType HseIpStatus = HSE_IP_STATUS_ERROR ;
    (void)HseIpStatus;
    HseIpStatus = Hse_Ip_Init(0, &HseIp_aMuState[0]);

    /* post boot (parallel) performance measure */
#if ( true == MEASURE_PERFORMANCE )
    while ( FALSE == HSE_CheckStatus(HSE_STATUS_INIT_OK) )
    {
        ;
    }
    TOGGLE_IO();
#endif

    /* Install ORed RX interrupt for MU-0 */
    IntCtrl_Ip_InstallHandler(HSE_MU0_RX_IRQn, &Mu_Ip_Mu0_OredRx_Isr, NULL_PTR);
    IntCtrl_Ip_InstallHandler(HSE_MU0_ORED_IRQn, &Mu_Ip_Mu0_OredGP_Isr, NULL_PTR);
    /* Enable ORed RX interrupt for MU-0 */
    IntCtrl_Ip_EnableIrq(HSE_MU0_RX_IRQn);
    IntCtrl_Ip_EnableIrq(HSE_MU0_ORED_IRQn);

    /* Clocks Configuration */
    Clock_Ip_Init(&Mcu_aClockConfigPB[0]);

    /* Initialize all pins using the Port driver */
    Siul2_Port_Ip_Init(NUM_OF_CONFIGURED_PINS0, g_pin_mux_InitConfigArr0);

    /* Interrupt Configuration */
    IntCtrl_Ip_Init(&IntCtrlConfig_0);
    IntCtrl_Ip_ConfigIrqRouting(&intRouteConfig);

    /* PIT0 (RTI) Configuration */
    Pit_Ip_Init(PIT_INST, &PIT_0_InitConfig_PB);
    Pit_Ip_InitChannel(PIT_INST, PIT_0_CH_0);
    IntCtrl_Ip_InstallHandler(PIT0_IRQn,PIT_0_ISR,NULL_PTR);

    Pit_Ip_EnableChannelInterrupt(PIT_INST, CH0);
    Pit_Ip_StartChannel(PIT_INST, CH0, PIT_PERIOD);


    /* SIUL2 IRQ configuration */
    Siul2_Icu_Ip_Init(SIUL2_ICU_IP_INSTANCE, &Siul2_Icu_Ip_0_Config_PB_BOARD_InitPeripherals);


    /* Enable SIUL2_EIRQ16 */
    Siul2_Icu_Ip_EnableNotification(SIUL2_ICU_IP_INSTANCE, (*Siul2_Icu_Ip_0_Config_PB_BOARD_InitPeripherals.pChannelsConfig)[0].hwChannel);
    Siul2_Icu_Ip_EnableInterrupt (SIUL2_ICU_IP_INSTANCE, (*Siul2_Icu_Ip_0_Config_PB_BOARD_InitPeripherals.pChannelsConfig)[0].hwChannel);
    /* Enable SIUL2_EIRQ17 */
    Siul2_Icu_Ip_EnableNotification(SIUL2_ICU_IP_INSTANCE, (*Siul2_Icu_Ip_0_Config_PB_BOARD_InitPeripherals.pChannelsConfig)[1].hwChannel);
    Siul2_Icu_Ip_EnableInterrupt (SIUL2_ICU_IP_INSTANCE, (*Siul2_Icu_Ip_0_Config_PB_BOARD_InitPeripherals.pChannelsConfig)[1].hwChannel);

    ISR(SIUL2_EXT_IRQ_16_23_ISR);
    /* Install IRQ handler for SIUL2 EIRQ16~23 */
    IntCtrl_Ip_InstallHandler(SIUL_2_IRQn, SIUL2_EXT_IRQ_16_23_ISR, NULL_PTR);
    /* Enable SIUL2 EIRQ16~23 in NVIC */
    IntCtrl_Ip_EnableIrq(SIUL_2_IRQn);


	/* Initializes an UART driver*/
	Lpuart_Uart_Ip_Init(LPUART_UART_IP_INSTANCE_USING_0, &Lpuart_Uart_Ip_xHwConfigPB_0_BOARD_INITPERIPHERALS);
    IntCtrl_Ip_EnableIrq(LPUART0_IRQn);

    Mpu_M7_Ip_Init(&MPU_M7_ModuleConfig_0);

    OsIf_Init(NULL);
}





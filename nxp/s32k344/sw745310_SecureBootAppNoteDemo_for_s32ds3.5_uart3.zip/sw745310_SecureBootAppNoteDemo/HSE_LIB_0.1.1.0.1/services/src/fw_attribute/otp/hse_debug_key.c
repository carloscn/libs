/**
*   @file    hse_fuses.c
*
*   @brief   Examples of HSE fuses programming.
*
*   @addtogroup [hse_fuses]
*   @{
*/
/*==================================================================================================
*
*   Copyright 2020-2021 NXP.
*
*   This software is owned or controlled by NXP and may only be used strictly in accordance with
*   the applicable license terms. By expressly accepting such terms or by downloading, installing,
*   activating and/or otherwise using the software, you are agreeing that you have read, and that
*   you agree to comply with and are bound by, such license terms. If you do not agree to
*   be bound by the applicable license terms, then you may not retain, install, activate or
*   otherwise use the software.
==================================================================================================*/

#ifdef __cplusplus
extern "C"{
#endif

/*=============================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
=============================================================================*/
#include "demo_app_services.h"
#include "global_variables.h"
#include "hse_host_attrs.h"
#include "string.h"

/*=============================================================================
*                 LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
=============================================================================*/

/*=============================================================================
*                         LOCAL MACROS
=============================================================================*/

/*=============================================================================
*                         LOCAL CONSTANTS
=============================================================================*/

/*=============================================================================
*                         LOCAL VARIABLES
=============================================================================*/
uint32_t length_adkphash = ADKP_LENGTH;
/*=============================================================================
*                         GLOBAL CONSTANTS
=============================================================================*/

/*=============================================================================
*                         GLOBAL VARIABLES
=============================================================================*/

/*=============================================================================
*                      LOCAL FUNCTION PROTOTYPES
=============================================================================*/

/*=============================================================================
*                      LOCAL FUNCTIONS
=============================================================================*/

/*=============================================================================
*                      GLOBAL FUNCTIONS
=============================================================================*/


/******************************************************************************
 * Function:    HSE_ReadAdkp
 * Description: Function for programming ADK/P request.
 *              It is a write-once operation.
******************************************************************************/
hseSrvResponse_t HSE_ProgramAdkp(void)
{
    hseSrvResponse_t srvResponse;

    /* WARNING: This operation is irreversible */
    /* Program the ADK/P (Application debug key/password) */
    srvResponse = SetAttr(HSE_APP_DEBUG_KEY_ATTR_ID,
        sizeof(hseAttrApplDebugKey_t), (void *)&applicationDebugKeyPassword);
    ASSERT(HSE_SRV_RSP_OK == srvResponse);
    return srvResponse;
}

/******************************************************************************
 * Function:    HSE_ReadAdkp
 * Description: Reads ADKP hash
 ******************************************************************************/
hseSrvResponse_t HSE_ReadAdkp( uint8_t *pDebugKey )
{
    hseSrvResponse_t srvResponse;
    srvResponse = GetAttr
            (
                    HSE_APP_DEBUG_KEY_ATTR_ID,
                    sizeof(hseAttrApplDebugKey_t),
                    (void *)pDebugKey
            );
    return srvResponse;
}

/******************************************************************************
 * Function:    HSE_CalculateHASH
 * Description: Calculates hash of programmed ADKP key
 ******************************************************************************/
hseSrvResponse_t HSE_CalculateHASH( uint8_t *pAdkpHash )
{
    hseSrvResponse_t srvResponse;
    srvResponse = HSE_HashDataNonBlocking
            (
                    MU0,
                    HSE_ACCESS_MODE_ONE_PASS,
                    0,
                    HSE_HASH_ALGO_SHA2_224,
                    (const uint8_t *)&applicationDebugKeyPassword[0],
                    sizeof(hseAttrApplDebugKey_t),
                    pAdkpHash,
                    &length_adkphash
            );

    ASSERT(HSE_SRV_RSP_OK == srvResponse);
    return srvResponse;
}

/******************************************************************************
 * Function:    HSE_CompareAdkp
 * Description: compares ADKP hashes
 ******************************************************************************/
bool_t HSE_CompareAdkp( uint8_t *pDebugKey, uint8_t *pAdkpHash )
{
    bool_t status = FALSE;
    if ( 0U == memcmp((void *)pDebugKey, (void *)pAdkpHash, ADKP_LENGTH) )
    {
     status = TRUE;
    }
    return status;
}

/******************************************************************************
 * Function:    check_debug_password_programmed_status
 * Description: checks if debug key is programmed
 ******************************************************************************/
bool_t check_debug_password_programmed_status(void)
{
    //clear the buffers
    bool_t status = FALSE;
    memset((void *)&programmed_appdebugkey,0U,ADKP_LENGTH);
    memset((void *)&adkp_hash,0U,ADKP_LENGTH);
    hseSrvResponse_t srvResponse = HSE_ReadAdkp((uint8_t *)&programmed_appdebugkey);
    //read ADKP hash value
    if( HSE_SRV_RSP_OK == srvResponse )
    {
        //calculate ADKP hash
        //srvResponse = HSE_CalculateHASH(&adkp_hash);
        //compare ADKP hashes, if matches then ADKP is programmed
        //if( HSE_SRV_RSP_OK == srvResponse)
        //{
            //status = HSE_CompareAdkp(&programmed_appdebugkey,&adkp_hash);
            status = TRUE;
        //}
    }
    return status;
}
#ifdef __cplusplus
}
#endif

/** @} */

/*==================================================================================================
*   Project              : RTD AUTOSAR 4.4
*   Platform             : CORTEXM
*   Peripheral           : C40_IP IPV_QSPI
*   Dependencies         : none
*
*   Autosar Version      : 4.4.0
*   Autosar Revision     : ASR_REL_4_4_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.0
*   Build Version        : S32K3_RTD_1_0_0_HF02_D2112_ASR_REL_4_4_REV_0000_20211222
*
*   (c) Copyright 2020 - 2021 NXP Semiconductors
*   All Rights Reserved.
*
*   NXP Confidential. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

#ifndef C40_IP_CFG_H
#define C40_IP_CFG_H

/**
*   @file C40_Ip_Cfg.h
*
*   @addtogroup FLS
*   @{
*/

/* implements C40_Ip_Cfg.h_Artifact */

#ifdef __cplusplus
extern "C"{
#endif


/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "OsIf.h"
#include "C40_Ip_Types.h"
#include "S32K344_PFLASH.h"
#include "S32K344_FLASH.h"



/*==================================================================================================
*                              SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define FLS_C40_IP_VENDOR_ID_CFG                          43
#define FLS_C40_IP_AR_RELEASE_MAJOR_VERSION_CFG           4
#define FLS_C40_IP_AR_RELEASE_MINOR_VERSION_CFG           4
#define FLS_C40_IP_AR_RELEASE_REVISION_VERSION_CFG        0
#define FLS_C40_IP_SW_MAJOR_VERSION_CFG                   1
#define FLS_C40_IP_SW_MINOR_VERSION_CFG                   0
#define FLS_C40_IP_SW_PATCH_VERSION_CFG                   0


/*==================================================================================================
*                              SOURCE FILE VERSION INFORMATION
==================================================================================================*/
/* Check if current file and C40_Ip_Types header file are of the same vendor */
#if (FLS_C40_IP_VENDOR_ID_CFG != C40_IP_TYPES_VENDOR_ID_CFG)
    #error "C40_Ip_Cfg.h and C40_Ip_Types.h have different vendor ids"
#endif
/* Check if current file and C40_Ip_Types header file are of the same Autosar version */
#if ((FLS_C40_IP_AR_RELEASE_MAJOR_VERSION_CFG    != C40_IP_TYPES_AR_RELEASE_MAJOR_VERSION_CFG) || \
     (FLS_C40_IP_AR_RELEASE_MINOR_VERSION_CFG    != C40_IP_TYPES_AR_RELEASE_MINOR_VERSION_CFG) || \
     (FLS_C40_IP_AR_RELEASE_REVISION_VERSION_CFG != C40_IP_TYPES_AR_RELEASE_REVISION_VERSION_CFG) \
    )
    #error "AutoSar Version Numbers of C40_Ip_Cfg.h and C40_Ip_Types.h are different"
#endif
/* Check if current file and C40_Ip_Types header file are of the same Software version */
#if ((FLS_C40_IP_SW_MAJOR_VERSION_CFG != C40_IP_TYPES_SW_MAJOR_VERSION_CFG) || \
     (FLS_C40_IP_SW_MINOR_VERSION_CFG != C40_IP_TYPES_SW_MINOR_VERSION_CFG) || \
     (FLS_C40_IP_SW_PATCH_VERSION_CFG != C40_IP_TYPES_SW_PATCH_VERSION_CFG) \
    )
    #error "Software Version Numbers of C40_Ip_Cfg.h and C40_Ip_Types.h are different"
#endif


/*==================================================================================================
                                       DEFINES AND MACROS
==================================================================================================*/

/**
 * @brief  PFlash register base address of Pflash
 */
#define PFLASH_BASEADDR                             IP_PFLASH_BASE

#define FLS_MAX_DATA_SECTOR                         (32U)

#define FLS_DATA_PFCBLK_ORDER                       (PFLASH_PFCBLKI_SPELOCK_COUNT - 1U)

/* Order of data flash PFCBLK Registers Arrays */
#define PFLASH_PFCBLK_DATA_LOCKMASTER_S0_ADDR32 ((uint32)(PFLASH_BASEADDR + (uint32)0x440UL))

/**
 * @brief  Block a Lock Master Sectorb
 */
#define PFLASH_PFCBLK0_LOCKMASTER_S0_ADDR32     ((uint32)(PFLASH_BASEADDR + (uint32)0x3C0UL))
/**
 * @brief   Block UTEST Lock Master Sector
 */
#define PFLASH_PFCBLKU_LOCKMASTER_S_ADDR32      ((uint32)(PFLASH_BASEADDR + (uint32)0x480UL))
/**
 * @brief   Block a Lock Master Super Sectorb
 */
#define PFLASH_PFCBLK0_LOCKMASTER_SS0_ADDR32    ((uint32)(PFLASH_BASEADDR + (uint32)0x484UL))

/* Mask of failed  address regions: A0-A5 */
#define FLASH_ADDRESS_REGION_0              (FLASH_ADR_A0_MASK)
#define FLASH_ADDRESS_REGION_1              (FLASH_ADR_A1_MASK)
#define FLASH_ADDRESS_REGION_2              (FLASH_ADR_A2_MASK)
#define FLASH_ADDRESS_REGION_3              (FLASH_ADR_A3_MASK)
#define FLASH_ADDRESS_REGION_4              (FLASH_ADR_A4_MASK)
#define FLASH_ADDRESS_REGION_5              (FLASH_ADR_A5_MASK)

#define FLASH_FAILED_ADDRESS_REGION_MASK    (FLASH_ADDRESS_REGION_0  | \
                                             FLASH_ADDRESS_REGION_1  | \
                                             FLASH_ADDRESS_REGION_2  | \
                                             FLASH_ADDRESS_REGION_3  | \
                                             FLASH_ADDRESS_REGION_4  | \
                                             FLASH_ADDRESS_REGION_5)


/* Enable the use of cache invalidate */
#define C40_IP_SYNCRONIZE_CACHE             (STD_OFF)

#define C40_MAIN_INTERFACE_ENABLED          (STD_ON)


#define C40_IP_ENABLE_USER_MODE_SUPPORT     (STD_OFF)

#ifndef MCAL_ENABLE_USER_MODE_SUPPORT
    #if (STD_ON == C40_IP_ENABLE_USER_MODE_SUPPORT)
        #error MCAL_ENABLE_USER_MODE_SUPPORT is not enabled. For running Fls in user mode the MCAL_ENABLE_USER_MODE_SUPPORT needs to be defined
    #endif
#endif

#define C40_TIMEOUT_SUPERVISION_ENABLED     (STD_OFF)

#define C40_ERASE_VERIFICATION_ENABLED      (STD_OFF)

#define C40_PROGRAM_VERIFICATION_ENABLED    (STD_OFF)

#define C40_ERASED_VALUE_32                 (0xFFFFFFFFU)

#define C40_ERASED_VALUE_16                 (C40_ERASED_VALUE_32 & 0xFFFFU)

#define C40_ERASED_VALUE_8                  (C40_ERASED_VALUE_32 & 0xFFU)

#define C40_DATA_FLASH_ERROR_SUPPRESSION    (STD_OFF)

#define FLS_BLOCK_4_PIPE_SELECTABLE         (STD_ON)

#if (STD_ON == FLS_BLOCK_4_PIPE_SELECTABLE)
#define C40_BLOCK4_PIPE_SELECT              (0x00U)
#endif

#define C40_ECC_CHECK                       (STD_OFF)

#define C40_ECC_CHECK_BY_AUTOSAR_OS         (STD_OFF)

#if ( (C40_ECC_CHECK == STD_ON) || (C40_ECC_CHECK_BY_AUTOSAR_OS == STD_ON) )
    #define C40_ECC_VALUE                   (0x55155515U)
#endif

/*! Enable development error check */
#define C40_IP_DEV_ASSERT(x)                ((void)(x))

#define C40_TIMEOUT_TYPE                    (OSIF_COUNTER_DUMMY)

#if (STD_ON == C40_TIMEOUT_SUPERVISION_ENABLED)

#define C40_ASYNC_WRITE_TIMEOUT             (2147483647U)

#define C40_ASYNC_ERASE_TIMEOUT             (2147483647U)

#define C40_SYNC_WRITE_TIMEOUT              (2147483647U)

#define C40_SYNC_ERASE_TIMEOUT              (2147483647U)

#define C40_ABORT_TIMEOUT                   (32767U)

#endif  /*(STD_ON == C40_TIMEOUT_SUPERVISION_ENABLED)*/

#define FLS_HAS_CODE_ARRAY_0_BLOCK_2        (1U)
#define FLS_HAS_CODE_ARRAY_0_BLOCK_3        (1U)

#define FLS_HAS_CODE_ARRAY_0_BLOCK_2_AND_3  (FLS_HAS_CODE_ARRAY_0_BLOCK_2 & FLS_HAS_CODE_ARRAY_0_BLOCK_3)

/* Code block 0 addresses */
#define FLS_CODE_BLOCK_0_BASE_ADDR          (0x00400000U)  /*!< the base address of code block 0 */
#define FLS_CODE_BLOCK_0_END_ADDR           (0x004FFFFFU)  /*!< the end address of code block 0 */

/* Code block 1 addresses */
#define FLS_CODE_BLOCK_1_BASE_ADDR          (0x00500000U)  /*!< the base address of code block 1 */
#define FLS_CODE_BLOCK_1_END_ADDR           (0x005FFFFFU)  /*!< the end address of code block 1 */

#if (FLS_HAS_CODE_ARRAY_0_BLOCK_2 == 1U)
/* Code block 2 addresses */
#define FLS_CODE_BLOCK_2_BASE_ADDR          (0x00600000U)  /*!< the base address of code block 2 */
#define FLS_CODE_BLOCK_2_END_ADDR           (0x006FFFFFU)  /*!< the end address of code block 2 */
#endif

#if (FLS_HAS_CODE_ARRAY_0_BLOCK_3 == 1U)
/* Code block 3 addresses */
#define FLS_CODE_BLOCK_3_BASE_ADDR          (0x00700000U)  /*!< the base address of code block 3 */
#define FLS_CODE_BLOCK_3_END_ADDR           (0x007FFFFFU)  /*!< the end address of code block 3 */
#endif

/* Data block addresses */
#define FLS_DATA_BLOCK_BASE_ADDR            (0x10000000U)  /*!< the base address of data block */
#define FLS_DATA_BLOCK_END_ADDR             (0x1003FFFFU)  /*!< the end address of data block */

/* Utest block addresses */
#define FLS_UTEST_BLOCK_BASE_ADDR           (0x1B000000U)  /*!< the base address of Utest block */
#define FLS_UTEST_BLOCK_END_ADDR            (0x1B001FFFU)  /*!< the end address of Utest block */

/* Memory flash sector characteristics */
#define FLS_MAX_VIRTUAL_SECTOR              (544U)

#define FLS_CODE_BLOCK_END_ADDR             FLS_CODE_BLOCK_3_END_ADDR

/*==================================================================================================
                                 ENUM TYPEDEFS
==================================================================================================*/

typedef uint32 C40_Ip_VirtualSectorsType;

/**
    For flash area : Code flash : Start 0040_0000h -> 0x007F_E000h and Data Flash: 1000_0000h -> 1003_FFFFh and Utest Flash :  1B00_0000h -> 1B00_1FFFh
*/
#define C40_DATA_ARRAY_0_BLOCK_4_S000       (0U)    /* 0x10000000 */
#define C40_DATA_ARRAY_0_BLOCK_4_S001       (1U)    /* 0x10002000 */
#define C40_DATA_ARRAY_0_BLOCK_4_S002       (2U)    /* 0x10004000 */
#define C40_DATA_ARRAY_0_BLOCK_4_S003       (3U)    /* 0x10006000 */
#define C40_DATA_ARRAY_0_BLOCK_4_S004       (4U)    /* 0x10008000 */
#define C40_DATA_ARRAY_0_BLOCK_4_S005       (5U)    /* 0x1000A000 */
#define C40_DATA_ARRAY_0_BLOCK_4_S006       (6U)    /* 0x1000C000 */
#define C40_DATA_ARRAY_0_BLOCK_4_S007       (7U)    /* 0x1000E000 */
#define C40_DATA_ARRAY_0_BLOCK_4_S008       (8U)    /* 0x10010000 */
#define C40_DATA_ARRAY_0_BLOCK_4_S009       (9U)    /* 0x10012000 */
#define C40_DATA_ARRAY_0_BLOCK_4_S010       (10U)    /* 0x10014000 */
#define C40_DATA_ARRAY_0_BLOCK_4_S011       (11U)    /* 0x10016000 */
#define C40_DATA_ARRAY_0_BLOCK_4_S012       (12U)    /* 0x10018000 */
#define C40_DATA_ARRAY_0_BLOCK_4_S013       (13U)    /* 0x1001A000 */
#define C40_DATA_ARRAY_0_BLOCK_4_S014       (14U)    /* 0x1001C000 */
#define C40_DATA_ARRAY_0_BLOCK_4_S015       (15U)    /* 0x1001E000 */
#define C40_DATA_ARRAY_0_BLOCK_4_S016       (16U)    /* 0x10020000 */
#define C40_DATA_ARRAY_0_BLOCK_4_S017       (17U)    /* 0x10022000 */
#define C40_DATA_ARRAY_0_BLOCK_4_S018       (18U)    /* 0x10024000 */
#define C40_DATA_ARRAY_0_BLOCK_4_S019       (19U)    /* 0x10026000 */
#define C40_DATA_ARRAY_0_BLOCK_4_S020       (20U)    /* 0x10028000 */
#define C40_DATA_ARRAY_0_BLOCK_4_S021       (21U)    /* 0x1002A000 */
#define C40_DATA_ARRAY_0_BLOCK_4_S022       (22U)    /* 0x1002C000 */
#define C40_DATA_ARRAY_0_BLOCK_4_S023       (23U)    /* 0x1002E000 */
#define C40_DATA_ARRAY_0_BLOCK_4_S024       (24U)    /* 0x10030000 */
#define C40_DATA_ARRAY_0_BLOCK_4_S025       (25U)    /* 0x10032000 */
#define C40_DATA_ARRAY_0_BLOCK_4_S026       (26U)    /* 0x10034000 */
#define C40_DATA_ARRAY_0_BLOCK_4_S027       (27U)    /* 0x10036000 */
#define C40_DATA_ARRAY_0_BLOCK_4_S028       (28U)    /* 0x10038000 */
#define C40_DATA_ARRAY_0_BLOCK_4_S029       (29U)    /* 0x1003A000 */
#define C40_DATA_ARRAY_0_BLOCK_4_S030       (30U)    /* 0x1003C000 */
#define C40_DATA_ARRAY_0_BLOCK_4_S031       (31U)    /* 0x1003E000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S000       (32U)    /* 0x00400000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S001       (33U)    /* 0x00402000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S002       (34U)    /* 0x00404000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S003       (35U)    /* 0x00406000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S004       (36U)    /* 0x00408000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S005       (37U)    /* 0x0040A000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S006       (38U)    /* 0x0040C000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S007       (39U)    /* 0x0040E000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S008       (40U)    /* 0x00410000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S009       (41U)    /* 0x00412000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S010       (42U)    /* 0x00414000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S011       (43U)    /* 0x00416000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S012       (44U)    /* 0x00418000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S013       (45U)    /* 0x0041A000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S014       (46U)    /* 0x0041C000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S015       (47U)    /* 0x0041E000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S016       (48U)    /* 0x00420000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S017       (49U)    /* 0x00422000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S018       (50U)    /* 0x00424000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S019       (51U)    /* 0x00426000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S020       (52U)    /* 0x00428000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S021       (53U)    /* 0x0042A000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S022       (54U)    /* 0x0042C000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S023       (55U)    /* 0x0042E000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S024       (56U)    /* 0x00430000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S025       (57U)    /* 0x00432000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S026       (58U)    /* 0x00434000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S027       (59U)    /* 0x00436000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S028       (60U)    /* 0x00438000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S029       (61U)    /* 0x0043A000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S030       (62U)    /* 0x0043C000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S031       (63U)    /* 0x0043E000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S032       (64U)    /* 0x00440000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S033       (65U)    /* 0x00442000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S034       (66U)    /* 0x00444000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S035       (67U)    /* 0x00446000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S036       (68U)    /* 0x00448000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S037       (69U)    /* 0x0044A000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S038       (70U)    /* 0x0044C000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S039       (71U)    /* 0x0044E000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S040       (72U)    /* 0x00450000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S041       (73U)    /* 0x00452000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S042       (74U)    /* 0x00454000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S043       (75U)    /* 0x00456000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S044       (76U)    /* 0x00458000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S045       (77U)    /* 0x0045A000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S046       (78U)    /* 0x0045C000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S047       (79U)    /* 0x0045E000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S048       (80U)    /* 0x00460000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S049       (81U)    /* 0x00462000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S050       (82U)    /* 0x00464000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S051       (83U)    /* 0x00466000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S052       (84U)    /* 0x00468000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S053       (85U)    /* 0x0046A000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S054       (86U)    /* 0x0046C000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S055       (87U)    /* 0x0046E000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S056       (88U)    /* 0x00470000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S057       (89U)    /* 0x00472000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S058       (90U)    /* 0x00474000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S059       (91U)    /* 0x00476000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S060       (92U)    /* 0x00478000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S061       (93U)    /* 0x0047A000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S062       (94U)    /* 0x0047C000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S063       (95U)    /* 0x0047E000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S064       (96U)    /* 0x00480000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S065       (97U)    /* 0x00482000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S066       (98U)    /* 0x00484000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S067       (99U)    /* 0x00486000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S068       (100U)    /* 0x00488000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S069       (101U)    /* 0x0048A000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S070       (102U)    /* 0x0048C000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S071       (103U)    /* 0x0048E000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S072       (104U)    /* 0x00490000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S073       (105U)    /* 0x00492000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S074       (106U)    /* 0x00494000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S075       (107U)    /* 0x00496000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S076       (108U)    /* 0x00498000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S077       (109U)    /* 0x0049A000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S078       (110U)    /* 0x0049C000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S079       (111U)    /* 0x0049E000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S080       (112U)    /* 0x004A0000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S081       (113U)    /* 0x004A2000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S082       (114U)    /* 0x004A4000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S083       (115U)    /* 0x004A6000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S084       (116U)    /* 0x004A8000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S085       (117U)    /* 0x004AA000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S086       (118U)    /* 0x004AC000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S087       (119U)    /* 0x004AE000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S088       (120U)    /* 0x004B0000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S089       (121U)    /* 0x004B2000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S090       (122U)    /* 0x004B4000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S091       (123U)    /* 0x004B6000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S092       (124U)    /* 0x004B8000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S093       (125U)    /* 0x004BA000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S094       (126U)    /* 0x004BC000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S095       (127U)    /* 0x004BE000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S096       (128U)    /* 0x004C0000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S097       (129U)    /* 0x004C2000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S098       (130U)    /* 0x004C4000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S099       (131U)    /* 0x004C6000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S100       (132U)    /* 0x004C8000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S101       (133U)    /* 0x004CA000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S102       (134U)    /* 0x004CC000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S103       (135U)    /* 0x004CE000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S104       (136U)    /* 0x004D0000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S105       (137U)    /* 0x004D2000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S106       (138U)    /* 0x004D4000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S107       (139U)    /* 0x004D6000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S108       (140U)    /* 0x004D8000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S109       (141U)    /* 0x004DA000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S110       (142U)    /* 0x004DC000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S111       (143U)    /* 0x004DE000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S112       (144U)    /* 0x004E0000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S113       (145U)    /* 0x004E2000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S114       (146U)    /* 0x004E4000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S115       (147U)    /* 0x004E6000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S116       (148U)    /* 0x004E8000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S117       (149U)    /* 0x004EA000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S118       (150U)    /* 0x004EC000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S119       (151U)    /* 0x004EE000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S120       (152U)    /* 0x004F0000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S121       (153U)    /* 0x004F2000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S122       (154U)    /* 0x004F4000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S123       (155U)    /* 0x004F6000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S124       (156U)    /* 0x004F8000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S125       (157U)    /* 0x004FA000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S126       (158U)    /* 0x004FC000 */
#define C40_CODE_ARRAY_0_BLOCK_0_S127       (159U)    /* 0x004FE000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S128       (160U)    /* 0x00500000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S129       (161U)    /* 0x00502000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S130       (162U)    /* 0x00504000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S131       (163U)    /* 0x00506000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S132       (164U)    /* 0x00508000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S133       (165U)    /* 0x0050A000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S134       (166U)    /* 0x0050C000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S135       (167U)    /* 0x0050E000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S136       (168U)    /* 0x00510000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S137       (169U)    /* 0x00512000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S138       (170U)    /* 0x00514000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S139       (171U)    /* 0x00516000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S140       (172U)    /* 0x00518000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S141       (173U)    /* 0x0051A000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S142       (174U)    /* 0x0051C000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S143       (175U)    /* 0x0051E000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S144       (176U)    /* 0x00520000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S145       (177U)    /* 0x00522000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S146       (178U)    /* 0x00524000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S147       (179U)    /* 0x00526000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S148       (180U)    /* 0x00528000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S149       (181U)    /* 0x0052A000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S150       (182U)    /* 0x0052C000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S151       (183U)    /* 0x0052E000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S152       (184U)    /* 0x00530000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S153       (185U)    /* 0x00532000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S154       (186U)    /* 0x00534000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S155       (187U)    /* 0x00536000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S156       (188U)    /* 0x00538000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S157       (189U)    /* 0x0053A000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S158       (190U)    /* 0x0053C000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S159       (191U)    /* 0x0053E000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S160       (192U)    /* 0x00540000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S161       (193U)    /* 0x00542000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S162       (194U)    /* 0x00544000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S163       (195U)    /* 0x00546000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S164       (196U)    /* 0x00548000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S165       (197U)    /* 0x0054A000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S166       (198U)    /* 0x0054C000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S167       (199U)    /* 0x0054E000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S168       (200U)    /* 0x00550000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S169       (201U)    /* 0x00552000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S170       (202U)    /* 0x00554000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S171       (203U)    /* 0x00556000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S172       (204U)    /* 0x00558000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S173       (205U)    /* 0x0055A000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S174       (206U)    /* 0x0055C000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S175       (207U)    /* 0x0055E000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S176       (208U)    /* 0x00560000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S177       (209U)    /* 0x00562000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S178       (210U)    /* 0x00564000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S179       (211U)    /* 0x00566000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S180       (212U)    /* 0x00568000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S181       (213U)    /* 0x0056A000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S182       (214U)    /* 0x0056C000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S183       (215U)    /* 0x0056E000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S184       (216U)    /* 0x00570000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S185       (217U)    /* 0x00572000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S186       (218U)    /* 0x00574000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S187       (219U)    /* 0x00576000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S188       (220U)    /* 0x00578000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S189       (221U)    /* 0x0057A000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S190       (222U)    /* 0x0057C000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S191       (223U)    /* 0x0057E000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S192       (224U)    /* 0x00580000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S193       (225U)    /* 0x00582000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S194       (226U)    /* 0x00584000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S195       (227U)    /* 0x00586000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S196       (228U)    /* 0x00588000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S197       (229U)    /* 0x0058A000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S198       (230U)    /* 0x0058C000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S199       (231U)    /* 0x0058E000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S200       (232U)    /* 0x00590000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S201       (233U)    /* 0x00592000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S202       (234U)    /* 0x00594000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S203       (235U)    /* 0x00596000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S204       (236U)    /* 0x00598000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S205       (237U)    /* 0x0059A000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S206       (238U)    /* 0x0059C000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S207       (239U)    /* 0x0059E000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S208       (240U)    /* 0x005A0000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S209       (241U)    /* 0x005A2000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S210       (242U)    /* 0x005A4000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S211       (243U)    /* 0x005A6000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S212       (244U)    /* 0x005A8000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S213       (245U)    /* 0x005AA000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S214       (246U)    /* 0x005AC000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S215       (247U)    /* 0x005AE000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S216       (248U)    /* 0x005B0000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S217       (249U)    /* 0x005B2000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S218       (250U)    /* 0x005B4000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S219       (251U)    /* 0x005B6000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S220       (252U)    /* 0x005B8000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S221       (253U)    /* 0x005BA000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S222       (254U)    /* 0x005BC000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S223       (255U)    /* 0x005BE000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S224       (256U)    /* 0x005C0000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S225       (257U)    /* 0x005C2000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S226       (258U)    /* 0x005C4000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S227       (259U)    /* 0x005C6000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S228       (260U)    /* 0x005C8000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S229       (261U)    /* 0x005CA000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S230       (262U)    /* 0x005CC000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S231       (263U)    /* 0x005CE000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S232       (264U)    /* 0x005D0000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S233       (265U)    /* 0x005D2000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S234       (266U)    /* 0x005D4000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S235       (267U)    /* 0x005D6000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S236       (268U)    /* 0x005D8000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S237       (269U)    /* 0x005DA000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S238       (270U)    /* 0x005DC000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S239       (271U)    /* 0x005DE000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S240       (272U)    /* 0x005E0000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S241       (273U)    /* 0x005E2000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S242       (274U)    /* 0x005E4000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S243       (275U)    /* 0x005E6000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S244       (276U)    /* 0x005E8000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S245       (277U)    /* 0x005EA000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S246       (278U)    /* 0x005EC000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S247       (279U)    /* 0x005EE000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S248       (280U)    /* 0x005F0000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S249       (281U)    /* 0x005F2000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S250       (282U)    /* 0x005F4000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S251       (283U)    /* 0x005F6000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S252       (284U)    /* 0x005F8000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S253       (285U)    /* 0x005FA000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S254       (286U)    /* 0x005FC000 */
#define C40_CODE_ARRAY_0_BLOCK_1_S255       (287U)    /* 0x005FE000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S256       (288U)    /* 0x00600000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S257       (289U)    /* 0x00602000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S258       (290U)    /* 0x00604000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S259       (291U)    /* 0x00606000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S260       (292U)    /* 0x00608000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S261       (293U)    /* 0x0060A000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S262       (294U)    /* 0x0060C000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S263       (295U)    /* 0x0060E000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S264       (296U)    /* 0x00610000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S265       (297U)    /* 0x00612000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S266       (298U)    /* 0x00614000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S267       (299U)    /* 0x00616000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S268       (300U)    /* 0x00618000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S269       (301U)    /* 0x0061A000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S270       (302U)    /* 0x0061C000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S271       (303U)    /* 0x0061E000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S272       (304U)    /* 0x00620000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S273       (305U)    /* 0x00622000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S274       (306U)    /* 0x00624000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S275       (307U)    /* 0x00626000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S276       (308U)    /* 0x00628000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S277       (309U)    /* 0x0062A000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S278       (310U)    /* 0x0062C000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S279       (311U)    /* 0x0062E000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S280       (312U)    /* 0x00630000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S281       (313U)    /* 0x00632000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S282       (314U)    /* 0x00634000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S283       (315U)    /* 0x00636000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S284       (316U)    /* 0x00638000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S285       (317U)    /* 0x0063A000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S286       (318U)    /* 0x0063C000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S287       (319U)    /* 0x0063E000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S288       (320U)    /* 0x00640000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S289       (321U)    /* 0x00642000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S290       (322U)    /* 0x00644000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S291       (323U)    /* 0x00646000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S292       (324U)    /* 0x00648000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S293       (325U)    /* 0x0064A000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S294       (326U)    /* 0x0064C000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S295       (327U)    /* 0x0064E000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S296       (328U)    /* 0x00650000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S297       (329U)    /* 0x00652000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S298       (330U)    /* 0x00654000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S299       (331U)    /* 0x00656000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S300       (332U)    /* 0x00658000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S301       (333U)    /* 0x0065A000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S302       (334U)    /* 0x0065C000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S303       (335U)    /* 0x0065E000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S304       (336U)    /* 0x00660000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S305       (337U)    /* 0x00662000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S306       (338U)    /* 0x00664000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S307       (339U)    /* 0x00666000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S308       (340U)    /* 0x00668000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S309       (341U)    /* 0x0066A000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S310       (342U)    /* 0x0066C000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S311       (343U)    /* 0x0066E000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S312       (344U)    /* 0x00670000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S313       (345U)    /* 0x00672000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S314       (346U)    /* 0x00674000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S315       (347U)    /* 0x00676000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S316       (348U)    /* 0x00678000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S317       (349U)    /* 0x0067A000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S318       (350U)    /* 0x0067C000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S319       (351U)    /* 0x0067E000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S320       (352U)    /* 0x00680000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S321       (353U)    /* 0x00682000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S322       (354U)    /* 0x00684000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S323       (355U)    /* 0x00686000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S324       (356U)    /* 0x00688000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S325       (357U)    /* 0x0068A000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S326       (358U)    /* 0x0068C000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S327       (359U)    /* 0x0068E000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S328       (360U)    /* 0x00690000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S329       (361U)    /* 0x00692000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S330       (362U)    /* 0x00694000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S331       (363U)    /* 0x00696000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S332       (364U)    /* 0x00698000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S333       (365U)    /* 0x0069A000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S334       (366U)    /* 0x0069C000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S335       (367U)    /* 0x0069E000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S336       (368U)    /* 0x006A0000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S337       (369U)    /* 0x006A2000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S338       (370U)    /* 0x006A4000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S339       (371U)    /* 0x006A6000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S340       (372U)    /* 0x006A8000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S341       (373U)    /* 0x006AA000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S342       (374U)    /* 0x006AC000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S343       (375U)    /* 0x006AE000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S344       (376U)    /* 0x006B0000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S345       (377U)    /* 0x006B2000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S346       (378U)    /* 0x006B4000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S347       (379U)    /* 0x006B6000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S348       (380U)    /* 0x006B8000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S349       (381U)    /* 0x006BA000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S350       (382U)    /* 0x006BC000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S351       (383U)    /* 0x006BE000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S352       (384U)    /* 0x006C0000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S353       (385U)    /* 0x006C2000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S354       (386U)    /* 0x006C4000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S355       (387U)    /* 0x006C6000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S356       (388U)    /* 0x006C8000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S357       (389U)    /* 0x006CA000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S358       (390U)    /* 0x006CC000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S359       (391U)    /* 0x006CE000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S360       (392U)    /* 0x006D0000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S361       (393U)    /* 0x006D2000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S362       (394U)    /* 0x006D4000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S363       (395U)    /* 0x006D6000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S364       (396U)    /* 0x006D8000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S365       (397U)    /* 0x006DA000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S366       (398U)    /* 0x006DC000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S367       (399U)    /* 0x006DE000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S368       (400U)    /* 0x006E0000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S369       (401U)    /* 0x006E2000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S370       (402U)    /* 0x006E4000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S371       (403U)    /* 0x006E6000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S372       (404U)    /* 0x006E8000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S373       (405U)    /* 0x006EA000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S374       (406U)    /* 0x006EC000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S375       (407U)    /* 0x006EE000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S376       (408U)    /* 0x006F0000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S377       (409U)    /* 0x006F2000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S378       (410U)    /* 0x006F4000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S379       (411U)    /* 0x006F6000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S380       (412U)    /* 0x006F8000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S381       (413U)    /* 0x006FA000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S382       (414U)    /* 0x006FC000 */
#define C40_CODE_ARRAY_0_BLOCK_2_S383       (415U)    /* 0x006FE000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S384       (416U)    /* 0x00700000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S385       (417U)    /* 0x00702000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S386       (418U)    /* 0x00704000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S387       (419U)    /* 0x00706000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S388       (420U)    /* 0x00708000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S389       (421U)    /* 0x0070A000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S390       (422U)    /* 0x0070C000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S391       (423U)    /* 0x0070E000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S392       (424U)    /* 0x00710000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S393       (425U)    /* 0x00712000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S394       (426U)    /* 0x00714000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S395       (427U)    /* 0x00716000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S396       (428U)    /* 0x00718000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S397       (429U)    /* 0x0071A000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S398       (430U)    /* 0x0071C000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S399       (431U)    /* 0x0071E000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S400       (432U)    /* 0x00720000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S401       (433U)    /* 0x00722000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S402       (434U)    /* 0x00724000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S403       (435U)    /* 0x00726000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S404       (436U)    /* 0x00728000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S405       (437U)    /* 0x0072A000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S406       (438U)    /* 0x0072C000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S407       (439U)    /* 0x0072E000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S408       (440U)    /* 0x00730000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S409       (441U)    /* 0x00732000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S410       (442U)    /* 0x00734000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S411       (443U)    /* 0x00736000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S412       (444U)    /* 0x00738000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S413       (445U)    /* 0x0073A000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S414       (446U)    /* 0x0073C000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S415       (447U)    /* 0x0073E000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S416       (448U)    /* 0x00740000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S417       (449U)    /* 0x00742000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S418       (450U)    /* 0x00744000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S419       (451U)    /* 0x00746000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S420       (452U)    /* 0x00748000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S421       (453U)    /* 0x0074A000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S422       (454U)    /* 0x0074C000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S423       (455U)    /* 0x0074E000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S424       (456U)    /* 0x00750000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S425       (457U)    /* 0x00752000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S426       (458U)    /* 0x00754000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S427       (459U)    /* 0x00756000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S428       (460U)    /* 0x00758000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S429       (461U)    /* 0x0075A000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S430       (462U)    /* 0x0075C000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S431       (463U)    /* 0x0075E000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S432       (464U)    /* 0x00760000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S433       (465U)    /* 0x00762000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S434       (466U)    /* 0x00764000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S435       (467U)    /* 0x00766000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S436       (468U)    /* 0x00768000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S437       (469U)    /* 0x0076A000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S438       (470U)    /* 0x0076C000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S439       (471U)    /* 0x0076E000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S440       (472U)    /* 0x00770000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S441       (473U)    /* 0x00772000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S442       (474U)    /* 0x00774000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S443       (475U)    /* 0x00776000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S444       (476U)    /* 0x00778000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S445       (477U)    /* 0x0077A000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S446       (478U)    /* 0x0077C000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S447       (479U)    /* 0x0077E000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S448       (480U)    /* 0x00780000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S449       (481U)    /* 0x00782000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S450       (482U)    /* 0x00784000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S451       (483U)    /* 0x00786000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S452       (484U)    /* 0x00788000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S453       (485U)    /* 0x0078A000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S454       (486U)    /* 0x0078C000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S455       (487U)    /* 0x0078E000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S456       (488U)    /* 0x00790000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S457       (489U)    /* 0x00792000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S458       (490U)    /* 0x00794000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S459       (491U)    /* 0x00796000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S460       (492U)    /* 0x00798000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S461       (493U)    /* 0x0079A000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S462       (494U)    /* 0x0079C000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S463       (495U)    /* 0x0079E000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S464       (496U)    /* 0x007A0000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S465       (497U)    /* 0x007A2000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S466       (498U)    /* 0x007A4000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S467       (499U)    /* 0x007A6000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S468       (500U)    /* 0x007A8000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S469       (501U)    /* 0x007AA000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S470       (502U)    /* 0x007AC000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S471       (503U)    /* 0x007AE000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S472       (504U)    /* 0x007B0000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S473       (505U)    /* 0x007B2000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S474       (506U)    /* 0x007B4000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S475       (507U)    /* 0x007B6000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S476       (508U)    /* 0x007B8000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S477       (509U)    /* 0x007BA000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S478       (510U)    /* 0x007BC000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S479       (511U)    /* 0x007BE000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S480       (512U)    /* 0x007C0000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S481       (513U)    /* 0x007C2000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S482       (514U)    /* 0x007C4000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S483       (515U)    /* 0x007C6000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S484       (516U)    /* 0x007C8000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S485       (517U)    /* 0x007CA000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S486       (518U)    /* 0x007CC000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S487       (519U)    /* 0x007CE000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S488       (520U)    /* 0x007D0000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S489       (521U)    /* 0x007D2000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S490       (522U)    /* 0x007D4000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S491       (523U)    /* 0x007D6000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S492       (524U)    /* 0x007D8000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S493       (525U)    /* 0x007DA000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S494       (526U)    /* 0x007DC000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S495       (527U)    /* 0x007DE000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S496       (528U)    /* 0x007E0000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S497       (529U)    /* 0x007E2000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S498       (530U)    /* 0x007E4000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S499       (531U)    /* 0x007E6000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S500       (532U)    /* 0x007E8000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S501       (533U)    /* 0x007EA000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S502       (534U)    /* 0x007EC000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S503       (535U)    /* 0x007EE000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S504       (536U)    /* 0x007F0000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S505       (537U)    /* 0x007F2000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S506       (538U)    /* 0x007F4000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S507       (539U)    /* 0x007F6000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S508       (540U)    /* 0x007F8000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S509       (541U)    /* 0x007FA000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S510       (542U)    /* 0x007FC000 */
#define C40_CODE_ARRAY_0_BLOCK_3_S511       (543U)    /* 0x007FE000 */
#define C40_UTEST_ARRAY_0_S000              (544U)    /* 0x1B000000 */
#define C40_SECTOR_ERROR                    (545U)    /* default and error return value */


/*==================================================================================================
                                 GLOBAL CONSTANT DECLARATIONS
==================================================================================================*/
#define FLS_START_SEC_CONFIG_DATA_UNSPECIFIED
#include "Fls_MemMap.h"

extern const C40_ConfigType C40ConfigSet_BOARD_InitPeripherals_InitCfg;

#define FLS_STOP_SEC_CONFIG_DATA_UNSPECIFIED
#include "Fls_MemMap.h"


#ifdef __cplusplus
}
#endif

/** @} */

#endif /* C40_IP_CFG_H */


/**
    @file        main.c
    @version     1.0.0

    @brief       HSE - Host SHE command application.
    @details     Sample application demonstrating host request flow using MU driver.

    This file contains sample code only. It is not part of the production code deliverables.
*/
/*==================================================================================================
*
*   Copyright 2020-2021 NXP.
*
*   This software is owned or controlled by NXP and may only be used strictly in accordance with 
*   the applicable license terms. By expressly accepting such terms or by downloading, installing, 
*   activating and/or otherwise using the software, you are agreeing that you have read, and that 
*   you agree to comply with and are bound by, such license terms. If you do not agree to 
*   be bound by the applicable license terms, then you may not retain, install, activate or 
*   otherwise use the software.
==================================================================================================*/

#ifdef __cplusplus
extern "C"{
#endif
#include "host_test.h"
#include "she_commands.h"
#include "host_common.h"
#include "host_wrappers.h"
/*==================================================================================================
                                         INCLUDE FILES
 1) system and project includes
 2) needed interfaces from external units
 3) internal and external interfaces from this unit
==================================================================================================*/

/*==================================================================================================
                                        LOCAL MACROS
==================================================================================================*/

/*==================================================================================================
                                      FILE VERSION CHECKS
==================================================================================================*/

/*==================================================================================================
                          LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/

/*==================================================================================================
                                       LOCAL CONSTANTS
==================================================================================================*/

/*==================================================================================================
                                       LOCAL VARIABLES
==================================================================================================*/

/*==================================================================================================
                                       GLOBAL CONSTANTS
==================================================================================================*/

/*==================================================================================================
                                       GLOBAL VARIABLES
==================================================================================================*/

/*==================================================================================================
  
                                   LOCAL FUNCTION PROTOTYPES
==================================================================================================*/

/*==================================================================================================
                                       LOCAL FUNCTIONS
==================================================================================================*/

/*==================================================================================================
                                       GLOBAL FUNCTIONS
==================================================================================================*/
/*******************************************************************************
 * Function:    main
 * Description: main function which calls following test functions
 *              AES-ECB Encryption & Decryption
 *              AES-CBC Encryption & Decryption
 *              CMAC generation & verification
 *              SHE load key import & export
 *              Generate Random Number
 *              Sys Authorization
 ******************************************************************************/
int main(void)
{
    uint8_t no_test_run = 1U;

    /* manual interruption required */
    while(no_test_run);

    HSE_ConfigKeyCatalogs();

    ASSERT(HSE_SRV_RSP_OK == Load_Relevant_Keys());

    ASSERT( HSE_SRV_RSP_OK == Test_ECB_ENC_DEC() );

    ASSERT( HSE_SRV_RSP_OK == Test_CBC_ENC_DEC() );
    
    ASSERT( HSE_SRV_RSP_OK == Test_CMAC_GENERATE_VERIFY() );

    ASSERT( HSE_SRV_RSP_OK == Test_SHE_LOAD_KEYS() );

    ASSERT(HSE_SRV_RSP_OK == Test_SHE_LOAD_PLAIN_KEY());

    ASSERT(HSE_SRV_RSP_OK == Test_EXPORT_RAM_KEY());

    ASSERT(HSE_SRV_RSP_OK == Test_CMD_EXTEND_SEED());

    ASSERT(HSE_SRV_RSP_OK == Test_RANDOM_NUM_REQ());

    ASSERT( HSE_SRV_RSP_OK == Test_SHE_GET_ID() );

    ASSERT(HSE_SRV_RSP_OK == Test_CMD_DEBUG_CHAL_AUTH());

    ASSERT( HSE_SRV_RSP_OK == Test_CMD_TRNG_RND());

   while(1);    //never return

}

void CopyFlashToSRAMHseHost(void)
{
    volatile uint32_t* FlashRamAddr=0U;
    volatile uint32_t* FlashSrcAddr=0U;
    volatile uint32_t* FlashSrcEndAddr=0U;
    uint32_t i=0U;

    FlashRamAddr=HSE_HOST_RAM_DST_START_ADDR ;
    FlashSrcAddr=HSE_HOST_FLASH_SRC_START_ADDR ;
    FlashSrcEndAddr=HSE_HOST_FLASH_SRC_END_ADDR ;

    /*Copying the UnsecureBAF Code from flash to RAM to avoid read while write
     *  violation */
    for(i=0U;i<(((uint32_t)FlashSrcEndAddr-(uint32_t)FlashSrcAddr)/4U);i++)
    {
        FlashRamAddr[i]=FlashSrcAddr[i];
    }
}

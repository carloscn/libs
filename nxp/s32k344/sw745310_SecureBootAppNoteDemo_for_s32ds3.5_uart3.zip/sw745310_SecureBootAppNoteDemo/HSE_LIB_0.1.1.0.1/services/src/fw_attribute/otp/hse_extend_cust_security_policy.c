/**
*   @file    hse_fuses.c
*
*   @brief   Examples of HSE fuses programming.
*
*   @addtogroup [hse_fuses]
*   @{
*/
/*==================================================================================================
*
*   Copyright 2020-2021 NXP.
*
*   This software is owned or controlled by NXP and may only be used strictly in accordance with
*   the applicable license terms. By expressly accepting such terms or by downloading, installing,
*   activating and/or otherwise using the software, you are agreeing that you have read, and that
*   you agree to comply with and are bound by, such license terms. If you do not agree to
*   be bound by the applicable license terms, then you may not retain, install, activate or
*   otherwise use the software.
==================================================================================================*/

#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/

#include "global_variables.h"
#include "hse_host_attrs.h"

#include "string.h"

/*=============================================================================
*                          LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
=============================================================================*/

/*=============================================================================
*                                       LOCAL MACROS
=============================================================================*/

/*=============================================================================
*                                      LOCAL CONSTANTS
=============================================================================*/

/*=============================================================================
*                                      LOCAL VARIABLES
=============================================================================*/

/*=============================================================================
*                                      GLOBAL CONSTANTS
=============================================================================*/

/*=============================================================================
*                                      GLOBAL VARIABLES
=============================================================================*/

/* HSE extend CUST security policies attribute */
hseAttrExtendCustSecurityPolicy_t gHSEextendCustSecurityPolicy;
/*=============================================================================
*                                   LOCAL FUNCTION PROTOTYPES
=============================================================================*/

/*=============================================================================
*                                       LOCAL FUNCTIONS
=============================================================================*/

/*=============================================================================
*                                       GLOBAL FUNCTIONS
=============================================================================*/


/******************************************************************************
 * Function:    HSE_AttrExtendCustSecurityPolicy
 * Warning:     This is one time configurable only, the reverse is not possible
 * Description: Function for programming ADK/P (Application debug key/password)
 *              request. When Debug Authorization Mode bit is not set,
 *              it is interpreted as a password.
 *              When Debug Authorization Mode bit is set, it is interpreted as
 *              a key for challenge-response mechanism.
******************************************************************************/
hseSrvResponse_t HSE_AttrExtendCustSecurityPolicy( bool_t EnableAdkmBit, bool_t StartAsUserBit )
{
    hseSrvResponse_t srvResponse;
    /* enable ASKP master */
    gHSEextendCustSecurityPolicy.enableADKm = EnableAdkmBit;
    /* Host granted Super User rights, one time programmable,
     * operation not reversible
     */
    gHSEextendCustSecurityPolicy.startAsUser = StartAsUserBit;
    /* WARNING: This operation is irreversible */
    srvResponse = SetAttr
            (
                    HSE_EXTEND_CUST_SECURITY_POLICY_ATTR_ID,
                    sizeof(hseAttrExtendCustSecurityPolicy_t),
                    (void *)&gHSEextendCustSecurityPolicy
            );
    ASSERT(HSE_SRV_RSP_OK == srvResponse);
    return srvResponse;
}

/******************************************************************************
 * Function:    HSE_ReadAttrExtendCustSecurityPolicy
 * Description: Returns extended customer security policy value
******************************************************************************/
hseSrvResponse_t HSE_ReadAttrExtendCustSecurityPolicy
( hseAttrExtendCustSecurityPolicy_t *pSecurityPolicy )
{
    hseSrvResponse_t srvResponse;
    /* Read extended customer security policy attribute value */
    srvResponse = GetAttr
            (
                    HSE_EXTEND_CUST_SECURITY_POLICY_ATTR_ID,
                    sizeof(hseAttrExtendCustSecurityPolicy_t),
                    (void *)pSecurityPolicy
            );
    ASSERT(HSE_SRV_RSP_OK == srvResponse);
    return srvResponse;
}
#ifdef __cplusplus
}
#endif

/** @} */

/*
 * main implementation: use this 'C' sample to create your own application
 *
 */
/*=============================================================================
                                         INCLUDE FILES
 1) system and project includes
 2) needed interfaces from external units
 3) internal and external interfaces from this unit
=============================================================================*/

#include "S32K344.h"
#include <typedefs.h>
#include <string.h>

#include "hse_mu.h"
#include "hse_host_attrs.h"
#include "pflash.h"
#include "flash.h"


/*=============================================================================
                   LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
=============================================================================*/

typedef enum
{
    FW_NOT_INSTALLED = 0,
    FW_INSTALLED
}fwteststatus_t;


/*=============================================================================
*                         LOCAL MACROS
=============================================================================*/

#define ASSERT(condition)   \
    do {                    \
        if(!(condition))    \
            while(1);       \
    } while(0)


#define UTEST_BASE_ADDRESS		        0x1B000000UL

/*=============================================================================
*                         LOCAL VARIABLES
=============================================================================*/
/* HSE FW feature usage flag to be loaded in UTEST */
static uint8_t hseFwFeatureFlagEnabledValue[8] = {0xAA, 0xBB, 0xCC, 0xDD,
										   0xDD, 0xCC, 0xBB, 0xAA};

/*=============================================================================
*                         GLOBAL CONSTANTS
=============================================================================*/

/*=============================================================================
*                         GLOBAL VARIABLES
=============================================================================*/

/* Variable to store HSE FW version details */
hseAttrFwVersion_t gHseFwVersion = {0U};
hseAttrFwVersion_t gnewHseFwVersion = {0U};

volatile fwteststatus_t gInstallHSEFwTest = FW_NOT_INSTALLED;

/*=============================================================================
 *                        GLOBAL FUNCTIONS
 * ==========================================================================*/
boolean checkHseFwFeatureFlagEnabled(void);
hseSrvResponse_t HSE_GetVersion_Example( hseAttrFwVersion_t *pHseFwVersion );

extern uint32_t __HSE_BIN_START;	// Address taken from linker file, , where HSE encrypted bin is included

int main(void)
{
	/* Status variable for flash interface */
	tFLASH_STATUS status;
	hseSrvResponse_t hseSrvResponse;

    /* Check if HSE FW usage flag is already enabled. Otherwise program the flag */
    if(FALSE == checkHseFwFeatureFlagEnabled())
    {
#if 1
    	  /* unlock UTEST data flash sector */
    	  PFLASH_Unlock (PFLASH_BL5, PFLASH_SS0, PFLASH_S0);

    	  /* Write in UtestSector using main interface */
    	  status = FLASH_Write ((uint32_t*)UTEST_BASE_ADDRESS,
    			  	  	  	  	  	  	   hseFwFeatureFlagEnabledValue,
    	                                   sizeof(hseFwFeatureFlagEnabledValue));
#endif

    	  while(1)
    	  {
    		  /*HSE usage not enable & have not HSE FW*/
    	  }

    	  (void)status;	// Dummy read to remove warning
    }

    /* Wait for HSE to initialize(read status bits) after installation */
    while((HSE_STATUS_INIT_OK & HSE_MU_GetHseStatus(0)) == 0)
    {
        gInstallHSEFwTest = FW_NOT_INSTALLED;
    }

    (void)HSE_GetVersion_Example(&gHseFwVersion);
    if((gHseFwVersion.majorVersion != 1) && (gHseFwVersion.minorVersion != 1))
    {
    	hseSrvResponse = TrigUpdateHSEFW((uint32_t)&__HSE_BIN_START, HSE_ACCESS_MODE_ONE_PASS);
    	ASSERT(HSE_SRV_RSP_OK == hseSrvResponse);
    }

    while(1);
    return 0;
}


/******************************************************************************
 * Function:    checkHseFwFeatureFlagEnabled
 * Description: Verifies whether hse fw feature flag is already enabled or not
 *****************************************************************************/
boolean checkHseFwFeatureFlagEnabled(void)
{
    boolean fw_enabled = FALSE;
    uint64_t default_val = 0xFFFFFFFFFFFFFFFFUL;
    uint64_t hsefwfeatureflag = *(uint64_t*)(UTEST_BASE_ADDRESS);

    //check the default value
    if(FALSE != memcmp((void *)&hsefwfeatureflag, (void *)&default_val, 0x8U))
    {
        fw_enabled = TRUE;
    }
    return fw_enabled;
}

/******************************************************************************
 * Function:    HSE_GetVersion_Example
 * Description: Example of HSE service - get FW version
******************************************************************************/
hseSrvResponse_t HSE_GetVersion_Example( hseAttrFwVersion_t *pHseFwVersion )
{
    hseSrvResponse_t srvResponse;
    srvResponse = GetAttr(
            HSE_FW_VERSION_ATTR_ID,
            sizeof(hseAttrFwVersion_t),
            pHseFwVersion );
    ASSERT(HSE_SRV_RSP_OK == srvResponse);
    return srvResponse;
}


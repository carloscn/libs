/*==================================================================================================
*
*   Copyright 2020-2021 NXP.
*
*   This software is owned or controlled by NXP and may only be used strictly in accordance with
*   the applicable license terms. By expressly accepting such terms or by downloading, installing,
*   activating and/or otherwise using the software, you are agreeing that you have read, and that
*   you agree to comply with and are bound by, such license terms. If you do not agree to
*   be bound by the applicable license terms, then you may not retain, install, activate or
*   otherwise use the software.
==================================================================================================*/
#ifndef _FLS_TYPE_H_
#define _FLS_TYPE_H_

#include "Platform_Types.h"
/*==================================================================================================
                                 DEFINE TYPEDEFS
==================================================================================================*/
#define FLS_SECTOR_SIZE  8192U     /*(each sector has 8k size) */
#define FLS_TOTAL_SECTORS  545U
#define FLS_VERIFY4BYTE_BLANK_CHECK  0xFFFFFFFFU
#define FLS_VERIFY1BYTE_BLANK_CHECK  0xFFU
#define FLS_CODE_BASE_ADDRESS   0x00400000U
#define FLS_DATA_BASE_ADDRESS   0x10000000U
#define FLS_UTEST_BASE_ADDRESS  0x1B000000U
#define FLS_DATA_SIZE_BYTES_U32  (128U)  /*Program Data Register (DATA0 - DATA31)*/
#define FLS_ADATA_SIZE_BYTES_U32 (32U)   /*Alternate Program Data Register (ADATA0 - ADATA7)*/
#define C55_USER_TEST_PASSWORD   (0xF9F99999U)  /* For UTE bit, the password 0xF9F9_9999 must be written to the UT0 register, and this must be a 32bit write*/
#define FLS_WELL_KNOWN_SECURE_COUNTER   10U       /* This well-known secure counter will help to determine the attack */

/*==================================================================================================
                                 STANDARD TYPEDEFS
==================================================================================================*/
#ifndef TRUE
    /** 
    * @brief Boolean true value
    */
    #define TRUE 1
#endif
#ifndef FALSE
    /** 
    * @implements TRUE_FALSE_enumeration
    */
    #define FALSE 0
#endif
#ifndef STD_ON
    /** 
    * @brief Boolean STD_ON value
    */
    #define STD_ON 1
#endif
#ifndef STD_OFF
    /** 
    * @brief Boolean STD_OFF value
    */
    #define STD_OFF 0
#endif
#ifndef NULL_PTR
    /** 
    * @brief NULL_PTR value
    */
    #define NULL_PTR ((void *)0)
#endif


/*==================================================================================================
                                 ENUM TYPEDEFS
==================================================================================================*/
/** 
    For flash area : Code flash : Start 0000_0000h -> 003F_FFFFh and Data Flash: 1000_0000h -> 1003_FFFFh and Utest Flash :  1B00_0000h -> 1B00_1FFFh
    @brief Sector Physical List.
*/
typedef enum
{
   FLS_DATA_ARRAY_0_BLOCK_4_S000 = 0U,   /*0x10000000*/
   FLS_DATA_ARRAY_0_BLOCK_4_S001 ,       /*0x10002000*/
   FLS_DATA_ARRAY_0_BLOCK_4_S002 ,       /*0x10004000*/
   FLS_DATA_ARRAY_0_BLOCK_4_S003 ,       /*0x10006000*/
   FLS_DATA_ARRAY_0_BLOCK_4_S004 ,       /*0x10008000*/
   FLS_DATA_ARRAY_0_BLOCK_4_S005 ,       /*0x1000A000*/
   FLS_DATA_ARRAY_0_BLOCK_4_S006 ,       /*0x1000C000*/
   FLS_DATA_ARRAY_0_BLOCK_4_S007 ,       /*0x1000E000*/
   FLS_DATA_ARRAY_0_BLOCK_4_S008 ,       /*0x10010000*/
   FLS_DATA_ARRAY_0_BLOCK_4_S009 ,       /*0x10012000*/
   FLS_DATA_ARRAY_0_BLOCK_4_S010 ,       /*0x10014000*/
   FLS_DATA_ARRAY_0_BLOCK_4_S011 ,       /*0x10016000*/
   FLS_DATA_ARRAY_0_BLOCK_4_S012 ,       /*0x10018000*/
   FLS_DATA_ARRAY_0_BLOCK_4_S013 ,       /*0x1001A000*/
   FLS_DATA_ARRAY_0_BLOCK_4_S014 ,       /*0x1001C000*/
   FLS_DATA_ARRAY_0_BLOCK_4_S015 ,       /*0x1001E000*/
   FLS_DATA_ARRAY_0_BLOCK_4_S016 ,       /*0x10020000*/
   FLS_DATA_ARRAY_0_BLOCK_4_S017 ,       /*0x10022000*/
   FLS_DATA_ARRAY_0_BLOCK_4_S018 ,       /*0x10024000*/
   FLS_DATA_ARRAY_0_BLOCK_4_S019 ,       /*0x10026000*/
   FLS_DATA_ARRAY_0_BLOCK_4_S020 ,       /*0x10028000*/
   FLS_DATA_ARRAY_0_BLOCK_4_S021 ,       /*0x1002A000*/
   FLS_DATA_ARRAY_0_BLOCK_4_S022 ,       /*0x1002C000*/
   FLS_DATA_ARRAY_0_BLOCK_4_S023 ,       /*0x1002E000*/
   FLS_DATA_ARRAY_0_BLOCK_4_S024 ,       /*0x10030000*/
   FLS_DATA_ARRAY_0_BLOCK_4_S025 ,       /*0x10032000*/
   FLS_DATA_ARRAY_0_BLOCK_4_S026 ,       /*0x10034000*/
   FLS_DATA_ARRAY_0_BLOCK_4_S027 ,       /*0x10036000*/
   FLS_DATA_ARRAY_0_BLOCK_4_S028 ,       /*0x10038000*/
   FLS_DATA_ARRAY_0_BLOCK_4_S029 ,       /*0x1003A000*/
   FLS_DATA_ARRAY_0_BLOCK_4_S030 ,       /*0x1003C000*/
   FLS_DATA_ARRAY_0_BLOCK_4_S031 ,       /*0x1003E000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S000 ,       /*0x00400000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S001 ,       /*0x00402000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S002 ,       /*0x00404000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S003 ,       /*0x00406000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S004 ,       /*0x00408000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S005 ,       /*0x0040A000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S006 ,       /*0x0040C000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S007 ,       /*0x0040E000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S008 ,       /*0x00410000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S009 ,       /*0x00412000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S010 ,       /*0x00414000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S011 ,       /*0x00416000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S012 ,       /*0x00418000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S013 ,       /*0x0041A000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S014 ,       /*0x0041C000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S015 ,       /*0x0041E000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S016 ,       /*0x00420000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S017 ,       /*0x00422000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S018 ,       /*0x00424000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S019 ,       /*0x00426000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S020 ,       /*0x00428000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S021 ,       /*0x0042A000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S022 ,       /*0x0042C000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S023 ,       /*0x0042E000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S024 ,       /*0x00430000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S025 ,       /*0x00432000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S026 ,       /*0x00434000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S027 ,       /*0x00436000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S028 ,       /*0x00438000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S029 ,       /*0x0043A000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S030 ,       /*0x0043C000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S031 ,       /*0x0043E000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S032 ,       /*0x00440000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S033 ,       /*0x00442000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S034 ,       /*0x00444000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S035 ,       /*0x00446000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S036 ,       /*0x00448000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S037 ,       /*0x0044A000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S038 ,       /*0x0044C000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S039 ,       /*0x0044E000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S040 ,       /*0x00450000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S041 ,       /*0x00452000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S042 ,       /*0x00454000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S043 ,       /*0x00456000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S044 ,       /*0x00458000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S045 ,       /*0x0045A000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S046 ,       /*0x0045C000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S047 ,       /*0x0045E000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S048 ,       /*0x00460000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S049 ,       /*0x00462000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S050 ,       /*0x00464000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S051 ,       /*0x00466000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S052 ,       /*0x0046800*/
   FLS_CODE_ARRAY_0_BLOCK_0_S053 ,       /*0x0046A000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S054 ,       /*0x0046C000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S055 ,       /*0x0046E000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S056 ,       /*0x00470000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S057 ,       /*0x00472000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S058 ,       /*0x00474000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S059 ,       /*0x00476000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S060 ,       /*0x00478000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S061 ,       /*0x0047A000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S062 ,       /*0x0047C000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S063 ,       /*0x0047E000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S064 ,       /*0x00480000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S065 ,       /*0x00482000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S066 ,       /*0x00484000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S067 ,       /*0x00486000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S068 ,       /*0x00488000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S069 ,       /*0x0048A000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S070 ,       /*0x0048C000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S071 ,       /*0x0048E000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S072 ,       /*0x00490000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S073 ,       /*0x00492000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S074 ,       /*0x00494000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S075 ,       /*0x00496000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S076 ,       /*0x00498000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S077 ,       /*0x0049A000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S078 ,       /*0x0049C000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S079 ,       /*0x0049E000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S080 ,       /*0x004A0000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S081 ,       /*0x004A2000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S082 ,       /*0x004A4000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S083 ,       /*0x004A6000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S084 ,       /*0x004A8000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S085 ,       /*0x004AA000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S086 ,       /*0x004AC000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S087 ,       /*0x004AE000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S088 ,       /*0x004B0000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S089 ,       /*0x004B2000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S090 ,       /*0x004B4000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S091 ,       /*0x004B6000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S092 ,       /*0x004B8000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S093 ,       /*0x004BA000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S094 ,       /*0x004BC000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S095 ,       /*0x004BE000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S096 ,       /*0x004C0000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S097 ,       /*0x004C2000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S098 ,       /*0x004C4000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S099 ,       /*0x004C6000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S100 ,       /*0x004C8000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S101 ,       /*0x004CA000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S102 ,       /*0x004CC000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S103 ,       /*0x004CE000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S104 ,       /*0x004D0000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S105 ,       /*0x004D2000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S106 ,       /*0x004D4000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S107 ,       /*0x004D6000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S108 ,       /*0x004D8000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S109 ,       /*0x004DA000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S110 ,       /*0x004DC000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S111 ,       /*0x004DE000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S112 ,       /*0x004E0000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S113 ,       /*0x004E2000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S114 ,       /*0x004E4000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S115 ,       /*0x004E6000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S116 ,       /*0x004E8000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S117 ,       /*0x004EA000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S118 ,       /*0x004EC000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S119 ,       /*0x004EE000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S120 ,       /*0x004F0000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S121 ,       /*0x004F2000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S122 ,       /*0x004F4000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S123 ,       /*0x004F6000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S124 ,       /*0x004F8000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S125 ,       /*0x004FA000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S126 ,       /*0x004FC000*/
   FLS_CODE_ARRAY_0_BLOCK_0_S127 ,       /*0x004FE000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S128 ,       /*0x00500000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S129 ,       /*0x00502000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S130 ,       /*0x00504000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S131 ,       /*0x00506000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S132 ,       /*0x00508000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S133 ,       /*0x0050A000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S134 ,       /*0x0050C000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S135 ,       /*0x0050E000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S136 ,       /*0x00510000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S137 ,       /*0x00512000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S138 ,       /*0x00514000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S139 ,       /*0x00516000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S140 ,       /*0x00518000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S141 ,       /*0x0051A000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S142 ,       /*0x0051C000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S143 ,       /*0x0051E000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S144 ,       /*0x00520000*/      
   FLS_CODE_ARRAY_0_BLOCK_1_S145 ,       /*0x00522000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S146 ,       /*0x00524000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S147 ,       /*0x00526000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S148 ,       /*0x00528000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S149 ,       /*0x0052A000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S150 ,       /*0x0052C000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S151 ,       /*0x0052E000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S152 ,       /*0x00530000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S153 ,       /*0x00532000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S154 ,       /*0x00534000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S155 ,       /*0x00536000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S156 ,       /*0x00538000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S157 ,       /*0x0053A000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S158 ,       /*0x0053C000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S159 ,       /*0x0053E000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S160 ,       /*0x00540000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S161 ,       /*0x00542000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S162 ,       /*0x00544000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S163 ,       /*0x00546000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S164 ,       /*0x00548000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S165 ,       /*0x0054A000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S166 ,       /*0x0054C000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S167 ,       /*0x0054E000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S168 ,       /*0x00550000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S169 ,       /*0x00552000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S170 ,       /*0x00554000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S171 ,       /*0x00556000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S172 ,       /*0x00558000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S173 ,       /*0x0055A000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S174 ,       /*0x0055C000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S175 ,       /*0x0055E000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S176 ,       /*0x00560000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S177 ,       /*0x00562000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S178 ,       /*0x00564000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S179 ,       /*0x00566000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S180 ,       /*0x00568000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S181 ,       /*0x0056A000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S182 ,       /*0x0056C000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S183 ,       /*0x0056E000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S184 ,       /*0x00570000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S185 ,       /*0x00572000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S186 ,       /*0x00574000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S187 ,       /*0x00576000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S188 ,       /*0x00578000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S189 ,       /*0x0057A000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S190 ,       /*0x0057C000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S191 ,       /*0x0057E000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S192 ,       /*0x00580000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S193 ,       /*0x00582000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S194 ,       /*0x00584000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S195 ,       /*0x00586000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S196 ,       /*0x00588000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S197 ,       /*0x0058A000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S198 ,       /*0x0058C000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S199 ,       /*0x0058E000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S200 ,       /*0x00590000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S201 ,       /*0x00592000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S202 ,       /*0x00594000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S203 ,       /*0x00596000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S204 ,       /*0x00598000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S205 ,       /*0x0059A000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S206 ,       /*0x0059C000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S207 ,       /*0x0059E000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S208 ,       /*0x005A0000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S209 ,       /*0x005A2000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S210 ,       /*0x005A4000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S211 ,       /*0x005A6000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S212 ,       /*0x005A8000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S213 ,       /*0x005AA000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S214 ,       /*0x005AC000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S215 ,       /*0x005AE000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S216 ,       /*0x005B0000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S217 ,       /*0x005B2000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S218 ,       /*0x005B4000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S219 ,       /*0x005B6000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S220 ,       /*0x005B8000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S221 ,       /*0x005BA000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S222 ,       /*0x005BC000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S223 ,       /*0x005BE000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S224 ,       /*0x005C0000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S225 ,       /*0x005C2000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S226 ,       /*0x005C4000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S227 ,       /*0x005C6000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S228 ,       /*0x005C8000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S229 ,       /*0x005CA000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S230 ,       /*0x005CC000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S231 ,       /*0x005CE000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S232 ,       /*0x005D0000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S233 ,       /*0x005D2000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S234 ,       /*0x005D4000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S235 ,       /*0x005D6000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S236 ,       /*0x005D8000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S237 ,       /*0x005DA000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S238 ,       /*0x005DC000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S239 ,       /*0x005DE000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S240 ,       /*0x005E0000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S241 ,       /*0x005E2000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S242 ,       /*0x005E4000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S243 ,       /*0x005E6000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S244 ,       /*0x005E8000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S245 ,       /*0x005EA000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S246 ,       /*0x005EC000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S247 ,       /*0x005EE000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S248 ,       /*0x005F0000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S249 ,       /*0x005F2000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S250 ,       /*0x005F4000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S251 ,       /*0x005F6000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S252 ,       /*0x005F8000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S253 ,       /*0x005FA000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S254 ,       /*0x005FC000*/
   FLS_CODE_ARRAY_0_BLOCK_1_S255 ,       /*0x005FE000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S256 ,       /*0x00600000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S257 ,       /*0x00602000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S258 ,       /*0x00604000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S259 ,       /*0x00606000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S260 ,       /*0x00608000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S261 ,       /*0x0060A000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S262 ,       /*0x0060C000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S263 ,       /*0x0060E000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S264 ,       /*0x00610000*/ 
   FLS_CODE_ARRAY_0_BLOCK_2_S265 ,       /*0x00612000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S266 ,       /*0x00614000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S267 ,       /*0x00616000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S268 ,       /*0x00618000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S269 ,       /*0x0061A000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S270 ,       /*0x0061C000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S271 ,       /*0x0061E000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S272 ,       /*0x00620000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S273 ,       /*0x00622000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S274 ,       /*0x00624000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S275 ,       /*0x00626000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S276 ,       /*0x00628000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S277 ,       /*0x0062A000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S278 ,       /*0x0062C000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S279 ,       /*0x0062E000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S280 ,       /*0x00630000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S281 ,       /*0x00632000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S282 ,       /*0x00634000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S283 ,       /*0x00636000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S284 ,       /*0x00638000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S285 ,       /*0x0063A000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S286 ,       /*0x0063C000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S287 ,       /*0x0063E000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S288 ,       /*0x00640000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S289 ,       /*0x00642000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S290 ,       /*0x00644000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S291 ,       /*0x00646000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S292 ,       /*0x00648000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S293 ,       /*0x0064A000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S294 ,       /*0x0064C000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S295 ,       /*0x0064E000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S296 ,       /*0x00650000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S297 ,       /*0x00652000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S298 ,       /*0x00654000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S299 ,       /*0x00656000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S300 ,       /*0x00658000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S301 ,       /*0x0065A000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S302 ,       /*0x0065C000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S303 ,       /*0x0065E000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S304 ,       /*0x00660000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S305 ,       /*0x00662000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S306 ,       /*0x00664000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S307 ,       /*0x00666000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S308 ,       /*0x00668000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S309 ,       /*0x0066A000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S310 ,       /*0x0066C000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S311 ,       /*0x0066E000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S312 ,       /*0x00670000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S313 ,       /*0x00672000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S314 ,       /*0x00674000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S315 ,       /*0x00676000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S316 ,       /*0x00678000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S317 ,       /*0x0067A000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S318 ,       /*0x0067C000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S319 ,       /*0x0067E000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S320 ,       /*0x00680000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S321 ,       /*0x00682000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S322 ,       /*0x00684000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S323 ,       /*0x00686000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S324 ,       /*0x00688000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S325 ,       /*0x0068A000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S326 ,       /*0x0068C000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S327 ,       /*0x0068E000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S328 ,       /*0x00690000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S329 ,       /*0x00692000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S330 ,       /*0x00694000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S331 ,       /*0x00696000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S332 ,       /*0x00698000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S333 ,       /*0x0069A000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S334 ,       /*0x0069C000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S335 ,       /*0x0069E000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S336 ,       /*0x006A0000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S337 ,       /*0x006A2000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S338 ,       /*0x006A4000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S339 ,       /*0x006A6000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S340 ,       /*0x006A8000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S341 ,       /*0x006AA000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S342 ,       /*0x006AC000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S343 ,       /*0x006AE000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S344 ,       /*0x006B0000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S345 ,       /*0x006B2000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S346 ,       /*0x006B4000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S347 ,       /*0x006B6000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S348 ,       /*0x006B8000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S349 ,       /*0x006BA000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S350 ,       /*0x006BC000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S351 ,       /*0x006BE000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S352 ,       /*0x006C0000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S353 ,       /*0x006C2000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S354 ,       /*0x006C4000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S355 ,       /*0x006C6000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S356 ,       /*0x006C8000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S357 ,       /*0x006CA000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S358 ,       /*0x006CC000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S359 ,       /*0x006CE000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S360 ,       /*0x006D0000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S361 ,       /*0x006D2000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S362 ,       /*0x006D4000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S363 ,       /*0x006D6000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S364 ,       /*0x006D8000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S365 ,       /*0x006DA000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S366 ,       /*0x006DC000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S367 ,       /*0x006DE000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S368 ,       /*0x006E0000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S369 ,       /*0x006E2000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S370 ,       /*0x006E4000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S371 ,       /*0x006E6000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S372 ,       /*0x006E8000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S373 ,       /*0x006EA000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S374 ,       /*0x006EC000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S375 ,       /*0x006EE000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S376 ,       /*0x006F0000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S377 ,       /*0x006F2000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S378 ,       /*0x006F4000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S379 ,       /*0x006F6000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S380 ,       /*0x006F8000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S381 ,       /*0x006FA000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S382 ,       /*0x006FC000*/
   FLS_CODE_ARRAY_0_BLOCK_2_S383 ,       /*0x006FE000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S384 ,       /*0x00700000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S385 ,       /*0x00702000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S386 ,       /*0x00704000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S387 ,       /*0x00706000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S388 ,       /*0x00708000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S389 ,       /*0x0070A000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S390 ,       /*0x0070C000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S391 ,       /*0x0070E000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S392 ,       /*0x00710000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S393 ,       /*0x00712000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S394 ,       /*0x00714000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S395 ,       /*0x00716000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S396 ,       /*0x00718000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S397 ,       /*0x0071A000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S398 ,       /*0x0071C000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S399 ,       /*0x0071E000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S400 ,       /*0x00720000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S401 ,       /*0x00722000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S402 ,       /*0x00724000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S403 ,       /*0x00726000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S404 ,       /*0x00728000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S405 ,       /*0x0072A000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S406 ,       /*0x0072C000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S407 ,       /*0x0072E000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S408 ,       /*0x00730000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S409 ,       /*0x00732000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S410 ,       /*0x00734000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S411 ,       /*0x00736000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S412 ,       /*0x00738000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S413 ,       /*0x0073A000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S414 ,       /*0x0073C000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S415 ,       /*0x0073E000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S416 ,       /*0x00740000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S417 ,       /*0x00742000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S418 ,       /*0x00744000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S419 ,       /*0x00746000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S420 ,       /*0x00748000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S421 ,       /*0x0074A000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S422 ,       /*0x0074C000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S423 ,       /*0x0074E000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S424 ,       /*0x00750000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S425 ,       /*0x00752000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S426 ,       /*0x00754000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S427 ,       /*0x00756000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S428 ,       /*0x00758000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S429 ,       /*0x0075A000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S430 ,       /*0x0075C000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S431 ,       /*0x0075E000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S432 ,       /*0x00760000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S433 ,       /*0x00762000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S434 ,       /*0x00764000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S435 ,       /*0x00766000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S436 ,       /*0x00768000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S437 ,       /*0x0076A000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S438 ,       /*0x0076C000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S439 ,       /*0x0076E000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S440 ,       /*0x00770000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S441 ,       /*0x00772000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S442 ,       /*0x00774000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S443 ,       /*0x00776000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S444 ,       /*0x00778000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S445 ,       /*0x0077A000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S446 ,       /*0x0077C000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S447 ,       /*0x0077E000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S448 ,       /*0x00780000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S449 ,       /*0x00782000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S450 ,       /*0x00784000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S451 ,       /*0x00786000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S452 ,       /*0x00788000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S453 ,       /*0x0078A000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S454 ,       /*0x0078C000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S455 ,       /*0x0078E000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S456 ,       /*0x00790000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S457 ,       /*0x00792000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S458 ,       /*0x00794000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S459 ,       /*0x00796000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S460 ,       /*0x00798000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S461 ,       /*0x0079A000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S462 ,       /*0x0079C000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S463 ,       /*0x0079E000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S464 ,       /*0x007A0000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S465 ,       /*0x007A2000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S466 ,       /*0x007A4000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S467 ,       /*0x007A6000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S468 ,       /*0x007A8000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S469 ,       /*0x007AA000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S470 ,       /*0x007AC000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S471 ,       /*0x007AE000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S472 ,       /*0x007B0000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S473 ,       /*0x007B2000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S474 ,       /*0x007B4000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S475 ,       /*0x007B6000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S476 ,       /*0x007B8000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S477 ,       /*0x007BA000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S478 ,       /*0x007BC000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S479 ,       /*0x007BE000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S480 ,       /*0x007C0000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S481 ,       /*0x007C2000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S482 ,       /*0x007C4000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S483 ,       /*0x007C6000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S484 ,       /*0x007C8000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S485 ,       /*0x007CA000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S486 ,       /*0x007CC000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S487 ,       /*0x007CE000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S488 ,       /*0x007D0000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S489 ,       /*0x007D2000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S490 ,       /*0x007D4000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S491 ,       /*0x007D6000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S492 ,       /*0x007D8000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S493 ,       /*0x007DA000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S494 ,       /*0x007DC000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S495 ,       /*0x007DE000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S496 ,       /*0x007E0000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S497 ,       /*0x007E2000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S498 ,       /*0x007E4000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S499 ,       /*0x007E6000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S500 ,       /*0x007E8000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S501 ,       /*0x007EA000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S502 ,       /*0x007EC000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S503 ,       /*0x007EE000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S504 ,       /*0x007F0000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S505 ,       /*0x007F2000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S506 ,       /*0x007F4000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S507 ,       /*0x007F6000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S508 ,       /*0x007F8000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S509 ,       /*0x007FA000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S510 ,       /*0x007FC000*/
   FLS_CODE_ARRAY_0_BLOCK_3_S511 ,       /*0x007FE000*/
   FLS_UTEST_ARRAY_0_S000                /*0x1B000000*/
} Fls_VirtualListType;    
/*               
    @brief Enumeration of physical flash sectors program size
*/                                       
typedef enum                             
{                                      
    FLS_WRITE_DOUBLE_WORD = 8U,    /* Support to write double word mode */
    FLS_WRITE_PAGE        = 32U,   /* Support to write page mode */
    FLS_WRITE_QPAGE       = 128U   /* Support to write quad page mode */
} Fls_ProgSizeType;
/**
    @brief Enumeration of checking status errors or not.
*/
typedef enum
{
    FLS_JOB_OK                = 0x5AA5U,    /* Successful job */
    FLS_JOB_FAILED            = 0x27E4U,    /* Errors because of failed hardware */
    FLS_TIMEOUT_FAILED        = 0x2BD4U,    /* Errors because of failed timeout */
    FLS_INPUT_PARAM_FAILED    = 0x2DB4U,    /* Errors because of input parma */
    FLS_BLANK_CHECK_FAILED    = 0x2E74U,    /* Errors because of failed blank check */
    FLS_PROGRAM_VERIFY_FAILED = 0x33CCU,    /* Errors because of failed program verify */
    FLS_USER_TEST_BREAK_SBC   = 0x35ACU,    /* Break single bit correction */
    FLS_USER_TEST_BREAK_DBD   = 0x366CU     /* Break double bit detection */
} Fls_CheckStatusType;
/**
* @brief the number of bytes uses to compare.    
*
*/
typedef enum
{
    FLS_SIZE_1BYTE = 1U,
    FLS_SIZE_4BYTE = 4U
} Fls_DataBytesType;
/**
    @brief Enumeration of Getting status of lock bits .
*/
typedef enum
{
    FLS_UNPROTECT_SECTOR        = 0xD42BU,
    FLS_PROTECT_SECTOR          = 0xD81BU,
    FLS_NO_CHECK_PROTECT_SECTOR = 0xE187U
} Fls_GetStatusLockBitType;
/**
    @brief Enumeration of Array Integrity Sequence(proprietary sequence or sequential) .
*/
typedef enum
{
    FLS_PROPRIETARY_SEQENCE = 0U,
    FLS_SEQUENTIAL
} Fls_ArrayIntegritySequenceType;
/**
    @brief Enumeration of Blocks of memory flash .
*/
typedef enum
{
    FLS_BLOCK_0  = 0U,
    FLS_BLOCK_1  = 0x100000U,
    FLS_BLOCK_2  = 0x200000U,
    FLS_BLOCK_3  = 0x300000U,
    FLS_BLOCK_4  = 0x10000000U,
    FLS_UTEST    = 0x1B000000U
} Fls_FlashBlocksType;

/**
    @brief Enumeration breakpoints .
*/
typedef enum
{
    FLS_BREAKPOINTS_ON_DBD = 0U,
    FLS_BREAKPOINTS_ON_DBD_SBC,
    FLS_NO_BREAKPOINTS
} Fls_FlashBreakPointsType;

/**
    @brief Main or Alternate interfaces / express program.
*/
typedef enum
{
    FLS_MAIN_INTERFACE      = 0U,    /* Using main interface */
    FLS_ALTERNATE_INTERFACE = 1U     /* Using alternate interface  */
} Fls_InterfaceAccessType;

/*==================================================================================================
                                 STRUCTURES TYPEDEFS
==================================================================================================*/

/* FLS Configuration Structure */
typedef struct
{
   boolean Fls_bEnableTimeOut;                            /* Enable to use timeout when waiting for the Done bit of not(STD_ON/STD_OFF)*/
   uint32 Fls_u32ValueWaitDoneBitOrDomainIDsTimeOut;      /* value the timeout to wait for the Done bit or Domain IDs(this field will be used when Fls_EnableTimeOut is enabled )*/
   const uint32 *Fls_pAllSectors;                         /* All the sectors need Ex:  AllSectors[2] ={ FLS_CODE_ARRAY_0_BLOCK_3_S499, FLS_CODE_ARRAY_0_BLOCK_3_S503}*/
   uint32 Fls_u32NumberOfconfiguredSectors;               /* Number of the configured sectors (ex: 5 sectors so will fill this field = 5 )*/
   Fls_InterfaceAccessType Fls_InterfaceAccess;           /* FLS_MAIN_INTERFACE: Use APIs for main interface (the application cores) and FLS_ALTERNATE_INTERFACE use APIs for alter interface (the HSE core) */
} FLASH_CONFIG;


#endif  /* _FLS_TYPE_H_ */

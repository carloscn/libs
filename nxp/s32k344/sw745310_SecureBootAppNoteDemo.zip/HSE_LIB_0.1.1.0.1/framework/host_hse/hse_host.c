/**
 *   @file    hse_host.c
 *
 *   @brief   HOST APIs to send Hse messages.
 *   @details HOST APIs to send Hse messages over MU.
 *
 */

/*==================================================================================================
 *
 *   Copyright 2020-2021 NXP.
 *
 *   This software is owned or controlled by NXP and may only be used strictly in accordance with
 *   the applicable license terms. By expressly accepting such terms or by downloading, installing,
 *   activating and/or otherwise using the software, you are agreeing that you have read, and that
 *   you agree to comply with and are bound by, such license terms. If you do not agree to
 *   be bound by the applicable license terms, then you may not retain, install, activate or
 *   otherwise use the software.
 ==================================================================================================*/

#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
 *                                        INCLUDE FILES
 * 1) system and project includes
 * 2) needed interfaces from external units
 * 3) internal and external interfaces from this unit
 ==================================================================================================*/
/**
 * @file           hse_host.c
 */
#include "hse_host.h"

/*==================================================================================================
 *                          LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
 ==================================================================================================*/


/*==================================================================================================
 *                                       LOCAL MACROS
 ==================================================================================================*/

/* Timeout for blocking send/receive */
#define HSE_MU_TIMEOUT_DURATION ((uint32_t)0xFFFFFFFFUL)


#if ( 1 == HSE_USE_DTCM )

/* HSE service descriptors arrays for each MU placed in system DTCM */
static hseSrvDescriptor_t __attribute__((section("._HseSrvDesc"))) hseSrvDescMu0[HSE_NUM_OF_CHANNELS_PER_MU];
static hseSrvDescriptor_t __attribute__((section("._HseSrvDesc"))) hseSrvDescMu1[HSE_NUM_OF_CHANNELS_PER_MU];

#else
/* HSE service descriptors arrays for each MU placed in system RAM */
#define CRYPTO_START_SEC_VAR_CLEARED_UNSPECIFIED_NO_CACHEABLE
#include "Crypto_MemMap.h"
static hseSrvDescriptor_t hseSrvDescMu0[HSE_NUM_OF_CHANNELS_PER_MU];
static hseSrvDescriptor_t hseSrvDescMu1[HSE_NUM_OF_CHANNELS_PER_MU];
#define CRYPTO_STOP_SEC_VAR_CLEARED_UNSPECIFIED_NO_CACHEABLE
#include "Crypto_MemMap.h"
#endif

#if (HSE_NUM_OF_MU_INSTANCES > 2)
static hseSrvDescriptor_t hseSrvDescMu2[HSE_NUM_OF_CHANNELS_PER_MU];
#if (HSE_NUM_OF_MU_INSTANCES > 3)
static hseSrvDescriptor_t hseSrvDescMu3[HSE_NUM_OF_CHANNELS_PER_MU];
#endif /* (HSE_NUM_OF_MU_INSTANCES > 3) */
#endif /* (HSE_NUM_OF_MU_INSTANCES > 2) */

/* HSE service descriptors placed in system RAM */
hseSrvDescriptor_t *const gHseSrvDesc[HSE_NUM_OF_MU_INSTANCES] =
{ hseSrvDescMu0, hseSrvDescMu1,
#if (HSE_NUM_OF_MU_INSTANCES > 2)
    hseSrvDescMu2,
#if (HSE_NUM_OF_MU_INSTANCES > 3)
    hseSrvDescMu3
#endif /* (HSE_NUM_OF_MU_INSTANCES > 3) */
#endif /* (HSE_NUM_OF_MU_INSTANCES > 2) */
        };

/*==================================================================================================
 *                                      GLOBAL CONSTANTS
 ==================================================================================================*/
/* Global sync TX options */
hseTxOptions_t gSyncTxOption =
{ HSE_TX_SYNCHRONOUS, NULL, NULL };

Hse_Ip_ReqType gHseIp_Request[HSE_NUM_OF_MU_INSTANCES][HSE_NUM_OF_CHANNELS_PER_MU] = {0};

/*==================================================================================================
 *                                      GLOBAL VARIABLES
 ==================================================================================================*/



/*==================================================================================================
 *                                       GLOBAL FUNCTIONS
 ==================================================================================================*/

/*******************************************************************************
 * Description   : Send the request to HSE.
 ******************************************************************************/
hseSrvResponse_t HSE_Send(uint8_t u8MuInstance, uint8_t u8MuChannel, hseTxOptions_t txOptions, hseSrvDescriptor_t *pHseSrvDesc)
{
    hseSrvResponse_t srvResponse = HSE_SRV_RSP_GENERAL_ERROR;

    Hse_Ip_ReqType* pHseIp_Request = &gHseIp_Request[u8MuInstance][u8MuChannel];

    pHseIp_Request->u32Timeout = 0xffffffffu;

    /* Build the request to be sent to Hse Ip layer */
    if(HSE_TX_SYNCHRONOUS == txOptions.txOp)
    {
        pHseIp_Request->eReqType = HSE_IP_REQTYPE_SYNC;
        pHseIp_Request->pfCallback = NULL ;
        pHseIp_Request->pCallbackParam = NULL ;
    }
    else
    {
        pHseIp_Request->eReqType = HSE_IP_REQTYPE_ASYNC_IRQ;
        pHseIp_Request->pfCallback = txOptions.pfAsyncCallback;
        pHseIp_Request->pCallbackParam = txOptions.pCallbackpArg;
    }

    srvResponse = Hse_Ip_ServiceRequest(u8MuInstance, u8MuChannel, pHseIp_Request , HSE_DTCM_ADDR(pHseSrvDesc));

    return srvResponse ;
}

/*******************************************************************************
 * Description   : Get available channel to send request to HSE.
 ******************************************************************************/

uint8_t HSE_GetFreeChannel(uint8_t u8MuInstance)
{

    return Hse_Ip_GetFreeChannel(u8MuInstance);

}

bool HSE_CheckStatus(hseStatus_t status)
{
    hseStatus_t HseStatus;

    HseStatus = Hse_Ip_GetHseStatus(0);

    return ((status) == ((status) & HseStatus)) ;
}
//HSE_MU_GetHseStatus
hseStatus_t HSE_GetStatus(uint8_t u8MuInstance)
{
    return Hse_Ip_GetHseStatus(u8MuInstance);
}

#ifdef __cplusplus
}
#endif

/** @} */

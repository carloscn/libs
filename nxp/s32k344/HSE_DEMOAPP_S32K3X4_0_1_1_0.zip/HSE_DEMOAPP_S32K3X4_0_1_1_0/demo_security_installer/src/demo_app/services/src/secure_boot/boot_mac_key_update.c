/**
 *   @file    hse_memory_update_protocol.c
 *
 *   @brief   This file is used to test SHE Key Memory Update commands
 *   @details
 *
 *   @addtogroup [SECURITY_FIRMWARE_UNITTEST]
 *   @{
 */
/*==================================================================================================
 *   Copyright 2020-2021 NXP. .
 *
 *   This software is owned or controlled by NXP and may only be used strictly in accordance with 
 *   the applicable license terms. By expressly accepting such terms or by downloading, installing, 
 *   activating and/or otherwise using the software, you are agreeing that you have read, and that 
 *   you agree to comply with and are bound by, such license terms. If you do not agree to 
 *   be bound by the applicable license terms, then you may not retain, install, activate or 
 *   otherwise use the software.
 ==================================================================================================*/
/*==================================================================================================
 ==================================================================================================*/

#ifdef __cplusplus
extern "C"
{
#endif

/*==================================================================================================
 *                                        INCLUDE FILES
 ==================================================================================================*/

#include "hse_host.h"
#include "hse_interface.h"
#include "string.h"
#include "hse_default_config.h"
#include "global_defs.h"
#include "hse_host_rng.h"
#include "hse_host_mac.h"
#include "hse_host_format_key_catalogs.h"
#include "hse_host_cipher.h"
#include "hse_host_import_key.h"

#ifdef HSE_SPT_SHE
/*==================================================================================================
 *                          LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
 ==================================================================================================*/
#define RAM_KEY_ID 0x0E
#define KEY_SIZE_IN_WORD 4
#define AES_BLOCK_SIZE  16

typedef struct
{
    uint8_t uid[15];
    uint8_t KeyId;
    uint8_t AuthId;
    uint32_t count_val;
    uint8_t flag_val;
    uint8_t sheGroupId;
    uint8_t AuthKey[AES_BLOCK_SIZE];
    uint8_t KeyNew[AES_BLOCK_SIZE];
}MemoryUpdate_t;


/*==================================================================================================
 *                                       LOCAL MACROS
 ==================================================================================================*/
#define ARRAY_SIZE(x) (sizeof(x) / sizeof((x)[0]))

/*==================================================================================================
 *                                      LOCAL CONSTANTS
 ==================================================================================================*/
// static const hseKeyGroupCfgEntry_t nvmSheCatalog[] = {HSE_SHE_NVM_KEY_CATALOG_CFG};
// static const hseKeyGroupCfgEntry_t ramSheCatalog[] = {HSE_SHE_RAM_KEY_CATALOG_CFG};
/*==================================================================================================
 *                                      LOCAL VARIABLES
 ==================================================================================================*/
static uint8_t          muIf = 0U;
static uint8_t          muChannelIdx = 1U;
static hseTxOptions_t txOptions =
{ HSE_TX_SYNCHRONOUS, NULL, NULL };
/*==================================================================================================
 *                                      GLOBAL CONSTANTS
 ==================================================================================================*/

/*==================================================================================================
 *                                      GLOBAL VARIABLES
 ==================================================================================================*/

/*==================================================================================================
 *                                   LOCAL FUNCTION PROTOTYPES
 ==================================================================================================*/

/*==================================================================================================
 *                                       LOCAL FUNCTIONS
 ==================================================================================================*/
hseSrvResponse_t hse_kdf(uint8_t *plaintext, uint8_t *dst,uint32_t numblocks);

hseSrvResponse_t MemoryUpdateProtocol(MemoryUpdate_t *pMemUpdate);
/*==================================================================================================
 *                                       GLOBAL FUNCTIONS
 ==================================================================================================*/



/*******************************************************************************
 * Function:    SheLoadKey
 *
 * Description: This function is used to test She Load Key Command.
 *
 * Returns:
 HSE_SRV_RSP_OK                               HSE command successfully executed with no error
 HSE_SRV_RSP_INVALID_PARAM                    The HSE request parameters are invalid (e.g misaligned, invalid range)
 HSE_SRV_RSP_SMALL_BUFFER                     The provided buffer is too small
 HSE_SRV_RSP_NOT_ENOUGH_SPACE                 There is no enough space to perform operation (e.g. load a key)
 HSE_SRV_RSP_READ_FAILURE                     The service request failed because read access was denied
 HSE_SRV_RSP_WRITE_FAILURE                    The service request failed because write access was denied
 HSE_SRV_RSP_STREAMING_MODE_FAILURE           The service request that uses streaming mode failed (e.g. UPDATES and FINISH steps do not use the same HSE interface ID and channel ID as START step)
 HSE_SRV_RSP_VERIFY_FAILED                    HSE signals that a verification request fails (e.g. MAC and Signature verification)
 HSE_SRV_RSP_KEY_NOT_AVAILABLE                This error code is returned if a key is locked due to failed boot measurement or an active debugger
 HSE_SRV_RSP_KEY_INVALID                      Specified key slot is either not valid or not available due to a key usage flags restrictions
 HSE_SRV_RSP_KEY_EMPTY                        Specified key slot is empty
 HSE_SRV_RSP_BUSY                             HSE request issued when the HSE is in busy state (on that HSE channel)
 HSE_SRV_RSP_MEMORY_FAILURE                   Detect physical errors, flipped bits etc., during memory read or write operations
 HSE_SRV_RSP_GENERAL_ERROR                    This error code is returned if an error not covered by the error codes above is detected inside HSE
 ******************************************************************************/
hseSrvResponse_t SheLoadKey(uint8_t sheGroupId, uint8_t *M1, uint8_t *M2,
        uint8_t *M3, uint8_t *M4, uint8_t *M5)
{

    hseSrvDescriptor_t* pHseSrvDesc = &gHseSrvDesc[muIf][muChannelIdx];
    hseSheLoadKeySrv_t* pSheLoadKeyReq = &pHseSrvDesc->hseSrv.sheLoadKeyReq;

    memset(pHseSrvDesc, 0, sizeof(hseSrvDescriptor_t));

    pHseSrvDesc->srvId = HSE_SRV_ID_SHE_LOAD_KEY;

    pSheLoadKeyReq->sheGroupIndex = (hseKeyGroupIdx_t) sheGroupId;
    pSheLoadKeyReq->pM1 = (HOST_ADDR) M1;
    pSheLoadKeyReq->pM2 = (HOST_ADDR) M2;
    pSheLoadKeyReq->pM3 = (HOST_ADDR) M3;
    pSheLoadKeyReq->pM4 = (HOST_ADDR) M4;
    pSheLoadKeyReq->pM5 = (HOST_ADDR) M5;

    return HSE_Send(muIf, muChannelIdx, txOptions, pHseSrvDesc);

}

/*******************************************************************************
 * Function:    SheLoadPlainKey
 *
 * Description: This function is used to test She Load Plain Key Command.
 *
 * Returns:
 HSE_SRV_RSP_OK                               HSE command successfully executed with no error
 HSE_SRV_RSP_INVALID_PARAM                    The HSE request parameters are invalid (e.g misaligned, invalid range)
 HSE_SRV_RSP_SMALL_BUFFER                     The provided buffer is too small
 HSE_SRV_RSP_NOT_ENOUGH_SPACE                 There is no enough space to perform operation (e.g. load a key)
 HSE_SRV_RSP_READ_FAILURE                     The service request failed because read access was denied
 HSE_SRV_RSP_WRITE_FAILURE                    The service request failed because write access was denied
 HSE_SRV_RSP_STREAMING_MODE_FAILURE           The service request that uses streaming mode failed (e.g. UPDATES and FINISH steps do not use the same HSE interface ID and channel ID as START step)
 HSE_SRV_RSP_VERIFY_FAILED                    HSE signals that a verification request fails (e.g. MAC and Signature verification)
 HSE_SRV_RSP_KEY_NOT_AVAILABLE                This error code is returned if a key is locked due to failed boot measurement or an active debugger
 HSE_SRV_RSP_KEY_INVALID                      Specified key slot is either not valid or not available due to a key usage flags restrictions
 HSE_SRV_RSP_KEY_EMPTY                        Specified key slot is empty
 HSE_SRV_RSP_BUSY                             HSE request issued when the HSE is in busy state (on that HSE channel)
 HSE_SRV_RSP_MEMORY_FAILURE                   Detect physical errors, flipped bits etc., during memory read or write operations
 HSE_SRV_RSP_GENERAL_ERROR                    This error code is returned if an error not covered by the error codes above is detected inside HSE
 ******************************************************************************/
hseSrvResponse_t SheLoadPlainKey(const uint8_t *pKey)
{

    hseSrvDescriptor_t* pHseSrvDesc = &gHseSrvDesc[muIf][muChannelIdx];
    hseSheLoadPlainKeySrv_t* pSheLoadPlainKeyReq = &pHseSrvDesc->hseSrv.sheLoadPlainKeyReq;

    memset(pHseSrvDesc, 0, sizeof(hseSrvDescriptor_t));
    pHseSrvDesc->srvId = HSE_SRV_ID_SHE_LOAD_PLAIN_KEY;
    pSheLoadPlainKeyReq->pKey = (HOST_ADDR) pKey;

    return HSE_Send(muIf, muChannelIdx, txOptions, pHseSrvDesc);

}

/*******************************************************************************
 * Function:    SheGetId
 *
 * Description: This function is used to issue SheGetId service.
 *
 * Returns:
 HSE_SRV_RSP_OK                               HSE command successfully executed with no error
 HSE_SRV_RSP_INVALID_PARAM                    The HSE request parameters are invalid (e.g misaligned, invalid range)
 HSE_SRV_RSP_SMALL_BUFFER                     The provided buffer is too small
 HSE_SRV_RSP_NOT_ENOUGH_SPACE                 There is no enough space to perform operation (e.g. load a key)
 HSE_SRV_RSP_READ_FAILURE                     The service request failed because read access was denied
 HSE_SRV_RSP_WRITE_FAILURE                    The service request failed because write access was denied
 HSE_SRV_RSP_STREAMING_MODE_FAILURE           The service request that uses streaming mode failed (e.g. UPDATES and FINISH steps do not use the same HSE interface ID and channel ID as START step)
 HSE_SRV_RSP_VERIFY_FAILED                    HSE signals that a verification request fails (e.g. MAC and Signature verification)
 HSE_SRV_RSP_KEY_NOT_AVAILABLE                This error code is returned if a key is locked due to failed boot measurement or an active debugger
 HSE_SRV_RSP_KEY_INVALID                      Specified key slot is either not valid or not available due to a key usage flags restrictions
 HSE_SRV_RSP_KEY_EMPTY                        Specified key slot is empty
 HSE_SRV_RSP_BUSY                             HSE request issued when the HSE is in busy state (on that HSE channel)
 HSE_SRV_RSP_MEMORY_FAILURE                   Detect physical errors, flipped bits etc., during memory read or write operations
 HSE_SRV_RSP_GENERAL_ERROR                    This error code is returned if an error not covered by the error codes above is detected inside HSE
 ******************************************************************************/
hseSrvResponse_t SheGetId(uint8_t *pChallenge, uint8_t *pId, uint8_t *pSreg, uint8_t *pMac)
{

    hseSrvDescriptor_t* pHseSrvDesc = &gHseSrvDesc[muIf][muChannelIdx];
    hseSheGetIdSrv_t* pSheGetIdReq = &pHseSrvDesc->hseSrv.sheGetIdReq;

    memset(pHseSrvDesc, 0, sizeof(hseSrvDescriptor_t));

    pHseSrvDesc->srvId = HSE_SRV_ID_SHE_GET_ID;

    pSheGetIdReq->pChallenge = (HOST_ADDR) pChallenge;
    pSheGetIdReq->pId = (HOST_ADDR) pId;
    pSheGetIdReq->pSreg = (HOST_ADDR) pSreg;
    pSheGetIdReq->pMac = (HOST_ADDR) pMac;

    return HSE_Send(muIf, muChannelIdx, txOptions, pHseSrvDesc);

}
/********************************************************************************
 * Function:    hse_kdf
 *
 * Description: This function is used to  derive the key values e.g. K1, K2, K3 , K4.
 ********************************************************************************/

hseSrvResponse_t hse_kdf(uint8_t *plaintext, uint8_t *dst, uint32_t numblocks)
{
    hseSrvResponse_t hseResponse;
    /*Load IV as RAM key*/
    /* IV is loaded to RAM KEY */
    uint8_t *temp;
    uint8_t cipher[16] = { 0U };
    uint8_t iv[16]     = { 0U };

    temp = dst;
    uint8_t ptr_plaintext = 0U;
    uint8_t t_plaintext[AES_BLOCK_SIZE];
    while(numblocks)
    {
        /*Load IV as RAM key*/
        /* IV is loaded to RAM KEY */
        for(uint32_t i = 0U; i < AES_BLOCK_SIZE; i++)
        {
            t_plaintext[i] = plaintext[i + (AES_BLOCK_SIZE * ptr_plaintext)];
        }
        SheLoadPlainKey(iv);
        /*Calculate ECB ENC over 128 bit chunk of Plaintext*/
        /* prepares data structure for encrypt ECB command */
        hseResponse = AesEncrypt(SHE_RAM_KEY_HANDLE, HSE_CIPHER_BLOCK_MODE_ECB, iv, ARRAY_SIZE(t_plaintext),
                                 t_plaintext, cipher, HSE_SGT_OPTION_NONE);
        if(HSE_SRV_RSP_OK != hseResponse)
        {
            return hseResponse;
        }
        numblocks--;
        for(uint32_t i = 0U; i < AES_BLOCK_SIZE; i++)
        {
            iv[i] = iv[i] ^ cipher[i] ^ plaintext[i + (AES_BLOCK_SIZE * ptr_plaintext)];

        }
        ptr_plaintext++;
    }
    memcpy(temp, iv, ARRAY_SIZE(iv));
    return hseResponse;
}

/**
 * Function:    MemoryUpdateProtocol
 * @brief       This function is used to prepare Load Key Parameters based on SHE Memory Update Protocol.
 * @details
 ******************************************************************************/

hseSrvResponse_t MemoryUpdateProtocol(MemoryUpdate_t *pMemUpdate)
{
    hseSrvResponse_t status;
    uint8_t uid[15]             = { 0U };

    const uint8_t KEY_UPDATE_ENC_C[AES_BLOCK_SIZE] =
    { 0x01, 0x01, 0x53, 0x48, 0x45, 0x00, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xB0 };
    const uint8_t KEY_UPDATE_MAC_C[AES_BLOCK_SIZE] =
    { 0x01, 0x02, 0x53, 0x48, 0x45, 0x00, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xB0 };

    /* Initialization Vector */
    uint8_t IV[AES_BLOCK_SIZE] =
    { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
    uint8_t K1[AES_BLOCK_SIZE];
    uint8_t K2[AES_BLOCK_SIZE];
    uint8_t K3[AES_BLOCK_SIZE];
    uint8_t K4[AES_BLOCK_SIZE];

    uint8_t M1[AES_BLOCK_SIZE];
    uint8_t M2_t[AES_BLOCK_SIZE * 2];
    uint8_t M2[AES_BLOCK_SIZE * 2];
    uint8_t M3_t[AES_BLOCK_SIZE * 3];
    uint8_t M3[AES_BLOCK_SIZE];
    uint8_t M4_t[AES_BLOCK_SIZE];
    uint8_t M4_te[AES_BLOCK_SIZE];
    uint8_t M4[AES_BLOCK_SIZE * 2];
    uint8_t M4_o[AES_BLOCK_SIZE * 2];
    uint8_t M5_o[AES_BLOCK_SIZE];
    uint8_t M5[AES_BLOCK_SIZE];
    uint8_t plaintext[AES_BLOCK_SIZE * 2];
    int i = 0;

/* Generate K1 */
    /* K1 = KDF(KAuthID, KEY_UPDATE_ENC_C) */
    for(i = 0; i < AES_BLOCK_SIZE; i++)
    {
        plaintext[i] = pMemUpdate->AuthKey[i];
    }
    for(i = AES_BLOCK_SIZE; i < AES_BLOCK_SIZE * 2; i++)
    {
        plaintext[i] = KEY_UPDATE_ENC_C[i - AES_BLOCK_SIZE];
    }
    /* running KDF function to get K1 */
    status = hse_kdf(plaintext, K1, 2UL);
    if(HSE_SRV_RSP_OK != status)
    {
        return status;
    }

/*Generate K2*/
    /* K2 = KDF(KAuthID,KEY_UPDATE_MAC_C) */
    for(i = 0; i < AES_BLOCK_SIZE; i++)
    {
        plaintext[i] = pMemUpdate->AuthKey[i];
    }
    for(i = AES_BLOCK_SIZE; i < AES_BLOCK_SIZE * 2; i++)
    {
        plaintext[i] = KEY_UPDATE_MAC_C[i - AES_BLOCK_SIZE];
    }
    /* running KDF function to get K2 */
    status = hse_kdf(plaintext, K2, 2UL);
    if(HSE_SRV_RSP_OK != status)
    {
        return status;
    }
/* generate M1 */
    /* M1 = UIDâ€™|ID|AuthID */
    for(i = 0; i < 15; i++)
    {
        M1[i] = pMemUpdate->uid[i];
    }
    /* key to be updated and authorizing key ID */
    M1[15] = (pMemUpdate->KeyId << 4 & 0xF0) | (pMemUpdate->AuthId & 0x0F);
/* generate M2 */
    /* M2 = ENCCBC,K1,IV=0(CIDâ€™|FIDâ€™|â€œ0...0"95|KIDâ€™)*/
    M2_t[0] = ((pMemUpdate->count_val >> 20) & 0xFF);
    M2_t[1] = ((pMemUpdate->count_val >> 12) & 0xFF);
    M2_t[2] = ((pMemUpdate->count_val >> 4) & 0xFF);
    M2_t[3] = ((pMemUpdate->count_val << 4) & 0xF0) | ((pMemUpdate->flag_val >> 2) & 0x0F);
    M2_t[4] = ((pMemUpdate->flag_val << 6) & 0xC0);
    for(i = 5; i < 16; i++)
    {
        M2_t[i] = 0x00;
    }
    for(i = 16; i < AES_BLOCK_SIZE * 2; i++)
    {
        M2_t[i] = pMemUpdate->KeyNew[i - AES_BLOCK_SIZE];
    }
/* Load K1 in RAM key */
    status = SheLoadPlainKey(K1);
    /*EU_ASSERT(HSE_SRV_RSP_OK == LoadAesKey(SHE_RAM_KEY_HANDLE, ARRAY_SIZE(K1), K1));*/
    memset(M2, 0, AES_BLOCK_SIZE * 2);
/*CBC ENCRYPT M2_t using K1 to get M2*/
    status = AesEncrypt(SHE_RAM_KEY_HANDLE, HSE_CIPHER_BLOCK_MODE_CBC, IV,
                        ARRAY_SIZE(M2_t), M2_t, M2, HSE_SGT_OPTION_NONE);
    if(HSE_SRV_RSP_OK != status)
    {
        return status;
    }
/* generate M3 */
    /* M3 = CMACK2(M1|M2) */
    /*Load K2 in RAM key*/

    status = SheLoadPlainKey(K2);
/*Generate (M1|M2)*/
    for(i = 0; i < AES_BLOCK_SIZE; i++)
    {
        M3_t[i] = M1[i];
    }
    for(i = AES_BLOCK_SIZE; i < AES_BLOCK_SIZE * 3; i++)
    {
        M3_t[i] = M2[i - AES_BLOCK_SIZE];
    }

    uint32_t outputLen = ARRAY_SIZE(M3);
    /*generate MAC over (M1|M2) to get M3*/
    status = AesCmacGenerate(SHE_RAM_KEY_HANDLE, ARRAY_SIZE(M3_t),
                             M3_t, &outputLen, M3, HSE_SGT_OPTION_NONE);
    if(HSE_SRV_RSP_OK != status)
    {
        return status;
    }

/* key to be updated and authorizing key ID */
    M1[15] = (pMemUpdate->KeyId << 4 & 0xF0) | (pMemUpdate->AuthId & 0x0F);
/* load key to the Key Storage Area */
    status = SheLoadKey(pMemUpdate->sheGroupId, M1, M2, M3, M4_o, M5_o);
    /*EU_ASSERT(HSE_SRV_RSP_OK == status);*/
    if(HSE_SRV_RSP_OK != status)
    {
        return status;
    }

/*Get K3*/
    /* K3 = KDF(KEYID,KEY_UPDATE_ENC_C) */
    for(i = 0; i < AES_BLOCK_SIZE; i++)
    {
        plaintext[i] = pMemUpdate->KeyNew[i];
    }
    for(i = AES_BLOCK_SIZE; i < AES_BLOCK_SIZE * 2; i++)
    {
        plaintext[i] = KEY_UPDATE_ENC_C [i - AES_BLOCK_SIZE];
    }
    status = hse_kdf(plaintext, K3, 2UL);
    if(HSE_SRV_RSP_OK != status)
    {
        return status;
    }

/*Get K4*/
    /* K4 = KDF (KEYID,KEY_UPDATE_MAC_C) */
    /*for(i=0;i<KEY_SIZE_IN_WORD;i++)*/
    for(i = 0; i < AES_BLOCK_SIZE; i++)
    {
        plaintext[i] = pMemUpdate->KeyNew[i];
    }
    for(i = AES_BLOCK_SIZE; i < AES_BLOCK_SIZE * 2; i++)
    {
        plaintext[i] = KEY_UPDATE_MAC_C [i - AES_BLOCK_SIZE];
    }
    status = hse_kdf(plaintext, K4, 2UL);
    if(HSE_SRV_RSP_OK != status)
    {
        return status;
    }

/* Generate M4 */

    /* M4 = UID|ID|AuthID|M4*
     * M4* - the encrypted counter value; prior to encryption the counter
     * value (28 bits) is padded with a 1 and 99 0â€™s.
     * The key for the ECB encryption is K3
     */
    M4_t[0] = ((pMemUpdate->count_val >> 20) & 0xFF);
    M4_t[1] = ((pMemUpdate->count_val >> 12) & 0xFF);
    M4_t[2] = ((pMemUpdate->count_val >> 4) & 0xFF);
    // M4_t[3] = ((pMemUpdate->count_val<<4) & 0xF0)|0x08;
    M4_t[3] = ((pMemUpdate->count_val << 4) & 0xF0);
    /*Single "1"-bit Padding followed by "0"-bits on the LSB side*/
    M4_t[3] |= (uint8_t)(1UL << 3U);
    for(i = 4; i < AES_BLOCK_SIZE; i++)
    {
        M4_t[i] = 0x00;
    }
/* Load K3 in RAM key */
    status = SheLoadPlainKey(K3);
    memset(M4_te, 0, sizeof(M4_te));
/*EBC ENCRYPT */
    status = AesEncrypt(SHE_RAM_KEY_HANDLE, HSE_CIPHER_BLOCK_MODE_ECB, IV, ARRAY_SIZE(M4_t),
                        M4_t, M4_te, HSE_SGT_OPTION_NONE);
    if(HSE_SRV_RSP_OK != status)
    {
        return status;
    }

    for(i = 0; i < (AES_BLOCK_SIZE - 1); i++)
    {
        M4[i] = uid[i];
    }
    M4[15] = ((((uint8_t)pMemUpdate->KeyId) << 4U) & 0xF0U) | (((uint8_t)pMemUpdate->AuthId) & 0x0FU);
    for(i = AES_BLOCK_SIZE; i < AES_BLOCK_SIZE * 2; i++)
    {
        M4[i] = M4_te[i - AES_BLOCK_SIZE];
    }

/* Generate M5 */
    /* M5 = CMACK4(M4) */
    status = SheLoadPlainKey(K4);
/* Generate MAC to get M5 */
    uint32_t outputLen1 = ARRAY_SIZE(M5);
    ASSERT( HSE_SRV_RSP_OK == AesCmacGenerate(SHE_RAM_KEY_HANDLE, ARRAY_SIZE(M4),
                                                M4, &outputLen1, M5, HSE_SGT_OPTION_NONE));
/* check if M4 and M5 are equal */
    /*EU_ASSERT(0 == memcmp(M4, M4_o, ARRAY_SIZE(M4)));*/
    /*EU_ASSERT(0 == memcmp(M5, M5_o,ARRAY_SIZE(M5)));*/
    if(((0 == memcmp(M4, M4_o, ARRAY_SIZE(M4)))) && (0 == memcmp(M5, M5_o, ARRAY_SIZE(M5))))
    {
        return HSE_SRV_RSP_OK;
    }
    else
    {
        return HSE_SRV_RSP_GENERAL_ERROR;
    }

}

hseSrvResponse_t LoadBootMacKey(void)
{ 
    hseSrvResponse_t hseResponse;
    //hseResponse = SHEFormatKeyCatalogs();
    MemoryUpdate_t MemUpdate;
    /*UID’ is the wildcard value 0*/
    uint8_t t_uid[]={0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00 };
    /*The new key value to be loaded*/
    uint8_t t_KeyNew[]={0x0f, 0x0e, 0x0d, 0x0c, 0x0b, 0x0a, 0x09, 0x08, 0x07, 0x06, 0x05, 
    0x04, 0x03, 0x02, 0x01, 0x00};
    /*initial value of Master Ecu Key*/
    uint8_t MASTER_ECU_KEY [AES_BLOCK_SIZE]=
    { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
    memcpy(MemUpdate.uid,t_uid,ARRAY_SIZE(MemUpdate.uid));
    memcpy(MemUpdate.KeyNew,t_KeyNew,ARRAY_SIZE(MemUpdate.KeyNew));
    memcpy(MemUpdate.AuthKey,MASTER_ECU_KEY,ARRAY_SIZE(MemUpdate.AuthKey));
    /*The key ID for the key to be updated i.e. MasterEcuKey*/
    MemUpdate.KeyId = 0x01;
    /*The key ID for the Auth Key i.e. MasterEcuKey as Master EcuKey can Authenticate the same*/
    MemUpdate.AuthId = 0x01;
    /*CID’*/
    MemUpdate.count_val = 0x00000001;
    MemUpdate.sheGroupId =0x00;
    /*FID’ = WRITE_PROTECTION|BOOT_ PROTECTION|DEBUGGER_PROTECTION|KEY_USAGE|WILDCARD*/
    MemUpdate.flag_val = 0x00;
    hseResponse= MemoryUpdateProtocol(&MemUpdate);
    
    /*UPDATE BOOT MAC KEY*/
    memset(&MemUpdate,0,sizeof(MemUpdate));
    /*UID’ is the wildcard value 0*/
    uint8_t t_uid_1[] = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
    /*The new key value to be updated*/
    uint8_t t_KeyNew_1[] = { 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F};
    /*last loaded value of Master Ecu Key*/
    uint8_t MASTER_ECU_KEY_1 [AES_BLOCK_SIZE] = { 0x0f, 0x0e, 0x0d, 0x0c, 0x0b, 0x0a, 0x09, 0x08, 0x07, 0x06, 0x05, 0x04, 0x03, 0x02, 0x01, 0x00};
    memcpy(MemUpdate.uid,t_uid_1,NUM_OF_ELEMS(MemUpdate.uid));
    memcpy(MemUpdate.KeyNew,t_KeyNew_1,NUM_OF_ELEMS(MemUpdate.KeyNew));
    memcpy(MemUpdate.AuthKey,MASTER_ECU_KEY_1,NUM_OF_ELEMS(MemUpdate.AuthKey));
    /*The key ID for the key to be updated i.e. BootMacKey*/
    MemUpdate.KeyId = 0x02;
    /*The key ID for the Auth Key i.e. MasterEcuKey as Master EcuKey can Authenticate the same*/
    MemUpdate.AuthId = 0x01;
    /*CID’*/
    MemUpdate.count_val = 0x00000001;
    MemUpdate.sheGroupId =0x00;
    /*FID’ = WRITE_PROTECTION|BOOT_ PROTECTION|DEBUGGER_PROTECTION|KEY_USAGE|WILDCARD*/
    MemUpdate.flag_val = 0x00;
    hseResponse= MemoryUpdateProtocol(&MemUpdate);
    return hseResponse;
}



#endif /* HSE_SPT_SHE */

#ifdef __cplusplus
}
#endif

/** @} */


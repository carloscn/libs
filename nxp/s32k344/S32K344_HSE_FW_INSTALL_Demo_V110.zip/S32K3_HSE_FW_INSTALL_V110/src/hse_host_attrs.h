#ifndef _HSE_HOST_ATTRS_H_
#define _HSE_HOST_ATTRS_H_

#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/

#include "hse_interface.h"

/*==================================================================================================
*                              SOURCE FILE VERSION INFORMATION
==================================================================================================*/

/*==================================================================================================
*                                     FILE VERSION CHECKS
==================================================================================================*/

/*==================================================================================================
*                                          CONSTANTS
==================================================================================================*/

/*==================================================================================================
*                                      DEFINES AND MACROS
==================================================================================================*/

/*==================================================================================================
*                                             ENUMS
==================================================================================================*/

/*==================================================================================================
                                 STRUCTURES AND OTHER TYPEDEFS
==================================================================================================*/

/*==================================================================================================
                                 GLOBAL VARIABLE DECLARATIONS
==================================================================================================*/

/*==================================================================================================
                                     FUNCTION PROTOTYPES
==================================================================================================*/

/*******************************************************************************
 * Function:    SetAttr
 * Description: Sets the specified attribute
 * Returns:     Service response code of the operation.
 ******************************************************************************/
hseSrvResponse_t SetAttr
(
    hseAttrId_t attrId,
    uint32_t attrLen,
    void *pAttr
);

/*******************************************************************************
 * Function:    GetAttr
 * Description: Gets the specified attribute
 * Returns:     Service response code of the operation.
 ******************************************************************************/
hseSrvResponse_t GetAttr
(
    hseAttrId_t attrId,
    uint32_t attrLen,
    void *pAttr
);

/*******************************************************************************
 * Function:    GetSetAttrByMu
 * Description: Gets/Sets the specified attribute on specified MU interface and channel
 * Returns:     Service response code of the operation.
 ******************************************************************************/
hseSrvResponse_t GetSetAttrByMu
(
    hseAttrId_t attrId,
    uint32_t attrLen,
    void *pAttr,
    bool_t bSet,
    uint8_t muInstance,
    uint8_t muChannel
);

/*trigger update HSE FW
 * updateMode: HSE_ACCESS_MODE_ONE_PASS/HSE_ACCESS_MODE_START/HSE_ACCESS_MODE_UPDATE/HSE_ACCESS_MODE_FINISH
 * */
hseSrvResponse_t TrigUpdateHSEFW(uint32_t storeHseFWAddr,
								 hseAccessMode_t updateMode);
#ifdef __cplusplus
}
#endif

#endif /* _HSE_HOST_ATTRS_H_ */

/** @} */

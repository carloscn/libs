/**
    @file        main.c
    @version     1.0.0

    @brief       HSE - Host Demo Application.
    @details     Sample application demonstrating host request flow using MU driver.

    This file contains sample code only. It is not part of the production code deliverables.
*/
/*==================================================================================================
*
*   Copyright 2020-2021 NXP.
*
*   This software is owned or controlled by NXP and may only be used strictly in accordance with 
*   the applicable license terms. By expressly accepting such terms or by downloading, installing, 
*   activating and/or otherwise using the software, you are agreeing that you have read, and that 
*   you agree to comply with and are bound by, such license terms. If you do not agree to 
*   be bound by the applicable license terms, then you may not retain, install, activate or 
*   otherwise use the software.
==================================================================================================*/

#ifdef __cplusplus
extern "C"{
#endif

/*=============================================================================
                                         INCLUDE FILES
 1) system and project includes
 2) needed interfaces from external units
 3) internal and external interfaces from this unit
=============================================================================*/
#include "demo_app_services.h"
#include "global_variables.h"
#include "hse_common_types.h"
#include "hse_interface.h"
#include "host_compiler_api.h"
#include "hse_host_boot.h"
#include "hse_mu.h"
#include "host_flash.h"
#include "host_flashSrv.h"
#include "string.h"
#include "monotonic_cnt.h"
#include "hse_host_import_key.h"
#include "hse_host_cipher.h"

/*=============================================================================
                              LOCAL MACROS
  ===========================================================================*/
#define MU_REG_READ8(address)              (*(volatile uint8_t*)(address))
/*=============================================================================
                           FILE VERSION CHECKS
=============================================================================*/


/*=============================================================================
                   LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
=============================================================================*/

typedef enum
{
    FW_NOT_INSTALLED = 0,
    FW_INSTALLED
}fwteststatus_t;

typedef enum
{
    NO_ATTRIBUTE_PROGRAMMED = 0,
    READ_HSE_VERSION = 0x1,
    READ_HSE_CAPABILITIES = 0x2,
    PROGRAM_APPLICATION_DEBUG_AUTH_KEY = 0x4,
    PROGRAM_DEBUG_AUTH = 0x8,
    ADVANCE_LC = 0x10,
    ENABLE_AUTH_MODE = 0x20,
    CONFIG_MU = 0x40,
    PROGRAM_EXTEND_CUST_SECURITY_POLICY = 0x80,
    ERASE_KEYS = 0x100,
    MONOTONIC_COUNTER = 0x200,
    UTEST_PROGRAM = 0x400,
    INVALID_ATTRIBUTE = 0xFF,
}eHSEFWAttributes;

typedef enum
{
    MONOTONIC_CNT_NOT_SELECTED = 0,
    MONOTONIC_CNT_CONFIGURE,
    MONOTONIC_CNT_INCREMENT,
    MONOTONIC_CNT_READ,
}monoTonicCounter_Selection_t;

/*
 * ============================================================================
 *                            LOCAL CONSTANTS
 * ============================================================================
*/
#define MONOTONIC_CNT_INIT          (0xA55AU)
#define IVT_FOR_BASE_SB_ADDR        (uint32_t)0x434000U
/*
 * ============================================================================
 *                            LOCAL VARIABLES
 * ============================================================================
*/

/*
 * ============================================================================
 *                               GLOBAL CONSTANTS
 * ============================================================================
*/

/*
 * ============================================================================
 *                               GLOBAL VARIABLES
 * ============================================================================
*/
volatile fwteststatus_t gInstallHSEFwTest = FW_NOT_INSTALLED;
volatile fwteststatus_t gInstallNewHSEFwTest = FW_NOT_INSTALLED;
hseAttrDebugAuthMode_t gDebugAuthMode = 0U;
volatile uint8_t gRunSecureBootType = 0U;
volatile bool_t authentication_type[5U] = {TRUE, TRUE, TRUE, TRUE, TRUE};
// this address is same as also in fw_update.cmm, for fw update demonstration, address is set to BLOCK0 address, update this if address in fw_update.cmm is changed.
volatile uint32_t gNewHseFwAddress;
volatile eHSEFWAttributes gProgramAttributes = NO_ATTRIBUTE_PROGRAMMED;
volatile eHSEFWAttributes gEnableIVTAuthBit = NO_ATTRIBUTE_PROGRAMMED;
volatile bool_t gADKPmasterbit = FALSE;
volatile bool_t debug_auth = FALSE;
volatile hseAttrFwVersion_t gHSEFWversion = {0};
volatile hseSrvResponse_t gsrvResponse = HSE_SRV_RSP_GENERAL_ERROR;
hseSrvResponse_t formatkey_srvResponse = HSE_SRV_RSP_GENERAL_ERROR;
hseSrvResponse_t keyprog_srvResponse = HSE_SRV_RSP_GENERAL_ERROR;
hseAttrFwVersion_t gHseFwVersion            = {0U};
volatile uint8_t ghseCapabilites[8]           = {0U};
volatile uint8_t programmed_appdebugkey[ADKP_LENGTH] = {0U};
volatile uint8_t adkp_hash[ADKP_LENGTH]              = {0U};
/* Current Life Cycle value */
hseAttrSecureLifecycle_t gHseCurrentLC = HSE_LC_CUST_DEL;
hseAttrConfigBootAuth_t gIVTauthvalue = 0U;
hseAttrMUConfig_t Read_hseMuConfigValue;
volatile hseMUConfig_t WriteMu1Config = 0xFFU;
volatile hseMUConfig_t ReadMu1Config = 0xFFU;
/* variable to store HSE FW version number before and after requesting for HSE FW update*/
hseAttrFwVersion_t gOldHseFwVersion = {0};
volatile bool_t write_attr = FALSE;
volatile monoTonicCounter_Selection_t monotonic_cnt_select = MONOTONIC_CNT_NOT_SELECTED;
volatile HOST_ADDR MonotonicCntReadValue = 0U;
volatile uint32_t MonotonicCntIncrementValue = 0U;
volatile uint32_t MonotonicCntIndex = 0xFFU;
volatile uint8_t MonotonicCntRPBitSize = 0xFFU;
hseSrvResponse_t MonotonicCntResponse = HSE_SRV_RSP_GENERAL_ERROR;
volatile bool_t hsefwusageflag = 0x0UL;
volatile hseAttrExtendCustSecurityPolicy_t ReadSecurityPolicy = {0};
volatile bool_t StartAsUserBit = FALSE;
volatile bool_t SetEnableAdkmBit = FALSE;
volatile int8_t GetStartAsUserBit = 0x7F;
volatile int8_t GetEnableAdkmBit = 0x7F;
volatile bool_t ActivatePassiveBlock = FALSE;
volatile bool_t fwudpate_only = FALSE;
volatile hseAttrSecureLifecycle_t programLC = 0U;
/*
 * ============================================================================
 *                        LOCAL FUNCTION PROTOTYPES
 * ============================================================================
*/
static void reset_tests(void);
static void BackUp(void);
static hseSrvResponse_t HSE_CalculateAdkpHash( uint8_t *pDebugKey );
/* ============================================================================
 *                              LOCAL FUNCTIONS
 * ============================================================================
*/
extern uint32_t HSE_HOST_RAM_DST_START_ADDR[];
extern uint32_t HSE_HOST_FLASH_SRC_START_ADDR[];
extern uint32_t HSE_HOST_FLASH_SRC_END_ADDR[];
/* ============================================================================
 *                              GLOBAL FUNCTIONS
 * ============================================================================
*/

/******************************************************************************
 * Function:    main
 * Description: Main function of the sample application.
 *          Calls different functionality example of requests issued to HSE:
 *          - Attribute programming
 *                     - example of an HSE request - set or get and attribute
 *                     for ex HSE FW version;
 *                   - HSE_FormatKeyCatalogs
 *                           - formats the key catalog with the default format;
 *                           - simulates configure step in the HSE life-cycle;
 *                           - needed for services involving keys;
 *                   - Cryptographic services
 *                           - example of requests sent synchronously;
 *                           - ImportKey, SymCipher;
 *                   - Secure boot
 *                           - example of base secure boot;
 *                           - Advanced secure boot;
 ******************************************************************************/
int main(void)
{    
    testStatus = NO_TEST_EXECUTED;
    /*check if HSE FW usage flag is already enabled,
     * if not enabled then do not proceed */ 
    while( FALSE == checkHseFwFeatureFlagEnabled())
    {
        /*user has requested to program HSE FW feature flag*/
        if ( UTEST_PROGRAM == gProgramAttributes )
        {
            gsrvResponse = EnableHSEFWUsage();
        }
    }
    /*hse fw flag is enabled either already programmed or requested by user*/
    testStatus |= HSE_FW_USAGE_ENABLED;

    /* Wait for HSE to initialize(read status bits) after installation */
    while((HSE_STATUS_INIT_OK & HSE_MU_GetHseStatus(0)) == 0)
    {
        gInstallHSEFwTest = FW_NOT_INSTALLED;
    }
    /* firmware installed, read hse */
    gInstallHSEFwTest = FW_INSTALLED;
    (void)HSE_GetVersion_Example(&gHseFwVersion);
    bool_t key_status = FALSE;
    /* Initialize Flash Driver */
    ASSERT(FLS_JOB_OK == HostFlash_Init());

    /* reserved bit checked for OTA_E to OTA_E update */
    fwversion[0].reserved = gHseFwVersion.reserved;
    /* after running test cases, run in infinite loop */
    while(1)
    {
        /* Check if NVM and RAM keys already formatted */
        /* format NVM and RAM key catalog */
        if (FALSE == CHECK_HSE_STATUS(HSE_STATUS_INSTALL_OK))
        {
            formatkey_srvResponse = HSE_Config();
            if(HSE_SRV_RSP_OK == formatkey_srvResponse)
                testStatus |= KEY_CATALOGS_FORMATTED;
	        /* import keys for cryptographic operation and secure boot */
	        ASSERT(HSE_SRV_RSP_OK == Generic_ImportKeys());
        }
        else
        {
            formatkey_srvResponse = HSE_SRV_RSP_OK;
	        testStatus |= KEY_CATALOGS_FORMATTED;
        }
        /* while(1) loop until any specific test is request to run from user */
        while(!gRunExampleTest);
        /* User Requested Monotonic Counter Operation */
        if( MONOTONIC_COUNTER == gProgramAttributes )
        {
            gsrvResponse = HSE_SRV_RSP_GENERAL_ERROR;
            switch(monotonic_cnt_select)
            {
                case MONOTONIC_CNT_CONFIGURE:
                    /* Configure MonoTonic Counter */
                    MonotonicCntResponse = MonotonicCnt_Config(MonotonicCntIndex,MonotonicCntRPBitSize);
                    break;
                case MONOTONIC_CNT_INCREMENT:
                    MonotonicCntResponse = MonotonicCnt_Increment(MonotonicCntIndex,MonotonicCntIncrementValue );
                    break;
                case MONOTONIC_CNT_READ:
                    MonotonicCntResponse = MonotonicCnt_Read(MonotonicCntIndex,(uint32_t)&MonotonicCntReadValue );
                    break;
                default:
                    MonotonicCntResponse = HSE_SRV_RSP_INVALID_PARAM;
                    break;
            }
            /* Clear Monotonic Variables */
            monotonic_cnt_select = MONOTONIC_CNT_NOT_SELECTED;
            MonotonicCntIndex = 0xFFU;
            MonotonicCntIncrementValue = 0x0U;
            MonotonicCntRPBitSize = 0xFFU;

            gsrvResponse = MonotonicCntResponse;
            if(HSE_SRV_RSP_OK == gsrvResponse)
            {
                testStatus |= MONOTONIC_CNT_DONE;
            }
        }
        /*
         * ADKP needs to be programmed for CMAC generation during
         * debug and boot authorization hence checking if ADKP is
         * programmed or not
         */
        if((testStatus | ADKP_PROGRAMMING_SUCCESS) != ADKP_PROGRAMMING_SUCCESS)
        {
            key_status = check_debug_password_programmed_status();
        }
        if( key_status == TRUE )
        {
            testStatus |= ADKP_PROGRAMMING_SUCCESS;
        }
        /* user has requested attribute programming */
        if( APP_PROGRAM_HSE_ATTRIBUTE == gRunExampleTest )
        {
            /* read hse fw version */
            if( READ_HSE_VERSION == gProgramAttributes )
            {
                gsrvResponse = HSE_GetVersion_Example(&gHseFwVersion);
                if(HSE_SRV_RSP_OK == gsrvResponse)
                    testStatus |= GET_VERSION_DONE;
            }
            /* read hse fw capabilities */
            else if( READ_HSE_CAPABILITIES == gProgramAttributes )
            {
                gsrvResponse = HSE_SRV_RSP_GENERAL_ERROR;
                gsrvResponse = HSE_GetCapabilities_Example((uint8_t *)&ghseCapabilites);
            }
            /* program adkp key */
            else if( PROGRAM_APPLICATION_DEBUG_AUTH_KEY == gProgramAttributes )
            {
                /*
                 * Program Application debug key/password example.
                 * Current Life-cycle shall be Customer Delivery.
                 * Check if ADKP is programmed already
                 */
                keyprog_srvResponse = HSE_ReadAdkp((uint8_t *)&programmed_appdebugkey);
                /*
                 * First time when ADKP is not programmed,
                 * read adkp will always result in not allowed
                 * If ADKP is not programmed then do so
                 */
                if( (HSE_SRV_RSP_NOT_ALLOWED == keyprog_srvResponse) && (TRUE == write_attr) )
                {
                    gsrvResponse = HSE_ProgramAdkp();
                }
                /*generate IVT CMAC and take backup*/
                gsrvResponse = generateIvtSign();
                /*
                 *  if adkp is read or adkp is programmed,
                 *  adkp hash is calculated to verify if correct adkp is written
                 */
                if((HSE_SRV_RSP_OK == gsrvResponse) ||( HSE_SRV_RSP_OK == keyprog_srvResponse))
                {
                    /*
                     * SHA2_224 algorithm used for HASH calculation,
                     * service id HSE_SRV_ID_HASH requested to HSE to generate hash in adkp_hash
                     */
                    gsrvResponse = HSE_CalculateAdkpHash((uint8_t *)&adkp_hash);
                }
                /*read adkp hash*/
                gsrvResponse = HSE_ReadAdkp((uint8_t *)&programmed_appdebugkey);
                /*compare hash calculated with hash read, if correct then ADKP program successful*/
                if( ( HSE_SRV_RSP_OK == gsrvResponse )&&\
                    ( TRUE == HSE_CompareAdkp( (uint8_t *)&programmed_appdebugkey, (uint8_t *)&adkp_hash ) )
                  )
                {
                    testStatus |= (ADKP_PROGRAMMING_SUCCESS|ADKP_KEY_VERIFIED);
                }
                else
                {

                }
            }
            else
            {

            }
            /*user requested debug authorization or debug auth mode change*/
            if( (PROGRAM_DEBUG_AUTH == gProgramAttributes))
            {
                gsrvResponse = HSE_SRV_RSP_GENERAL_ERROR;
                /*check if debug auth mode already set to Challenge Response mode*/
                gsrvResponse = HSE_GetDebugAuthMode(&gDebugAuthMode);
                /*ADKP should be programmed in order to update debug mode*/
                if( ( ( (testStatus & (ADKP_PROGRAMMING_SUCCESS | CR_DEBUG_AUTH_MODE)) == ADKP_PROGRAMMING_SUCCESS )\
                        &&  ( HSE_DEBUG_AUTH_MODE_PW == gDebugAuthMode )  && (TRUE == write_attr) ) )
                {
                    gsrvResponse = HSE_SRV_RSP_GENERAL_ERROR;
                    /*change debug authorization mode to CR*/
                    gsrvResponse = HSE_SetDebugAuthModeToChalResp();
                    testStatus |= CR_DEBUG_AUTH_MODE;
                }
                /*if debug auth mode already set to CR*/
                else if(HSE_DEBUG_AUTH_MODE_CR == gDebugAuthMode)
                {
                	/*mode already configured to CR*/
                    testStatus |= CR_DEBUG_AUTH_MODE;
                    /*reponse udpate*/
                    gsrvResponse = HSE_SRV_RSP_GENERAL_ERROR;
                }
                else
                {
                	/*ADKP is not programmed*/
                }
            }
            else
            {

            }
            /*
             *  User has request ADKP master bit to be set i.e.
             *  password generated for debug authorization will always be unique.
             *  Note: ADKP Key shall be programmed prior to this operation
             *  This is one-time programmable only and cannot be revered
             */
            if( PROGRAM_EXTEND_CUST_SECURITY_POLICY == gProgramAttributes )
            {
                gsrvResponse = HSE_SRV_RSP_GENERAL_ERROR;
                (void)HSE_ReadAttrExtendCustSecurityPolicy((hseAttrExtendCustSecurityPolicy_t *)&ReadSecurityPolicy);
                /*user requested to extend security policy*/
                if(
                        /*check if security policy is already extended, if yes then do not request SetAttribute to HSE*/
                        (FALSE == ReadSecurityPolicy.enableADKm)  &&
                        (ADKP_PROGRAMMING_SUCCESS != (testStatus & ADKP_PROGRAMMING_SUCCESS)) &&
                        (TRUE == write_attr)
                  )
                {
                    gsrvResponse = HSE_AttrExtendCustSecurityPolicy( SetEnableAdkmBit, StartAsUserBit );
                    if( HSE_SRV_RSP_OK == gsrvResponse )
                    {
                        testStatus |= EXTEND_CUST_SECURE_POLICY_ENABLED;
                        (void)HSE_ReadAttrExtendCustSecurityPolicy((hseAttrExtendCustSecurityPolicy_t *)&ReadSecurityPolicy);
                    }
                }
                /*security policy already extended*/
                else if(TRUE == ReadSecurityPolicy.enableADKm)
                {
                    testStatus |= EXTEND_CUST_SECURE_POLICY_ENABLED;
                }
                /*user has not programmed ADKP key prior to this operation*/
                else
                {

                }
                GetStartAsUserBit = ReadSecurityPolicy.startAsUser;
                GetEnableAdkmBit = ReadSecurityPolicy.enableADKm;
            }
            /*user has requested life cycle advancement*/
            if( ADVANCE_LC == gProgramAttributes )
            {
                /*
                 * check if LC is CUST_DEL and ADKP is programmed
                 * Note: This is one-time programmable only and
                 * LC can only be advanced and not reversed back
                 */
                gsrvResponse = HSE_ReadLifecycle(&gHseCurrentLC);
                if(((testStatus & ( ADKP_PROGRAMMING_SUCCESS | LIFECYCLE_ADVANCED_TO_INFIELD ) ) == ADKP_PROGRAMMING_SUCCESS )
                        && ((gHseCurrentLC == HSE_LC_CUST_DEL)|| (gHseCurrentLC == HSE_LC_OEM_PROD))
                        && (TRUE == write_attr))
                {
                    gsrvResponse = HSE_SRV_RSP_GENERAL_ERROR;
                    /*Advances Life cycle to OEM Production Life cycle*/
                    HSE_AdvanceLifecycle(programLC);
                    gsrvResponse = HSE_ReadLifecycle(&gHseCurrentLC);
                    if(( HSE_SRV_RSP_OK == gsrvResponse ) && (HSE_LC_IN_FIELD == gHseCurrentLC))
                    {
                        testStatus |= LIFECYCLE_ADVANCED_TO_INFIELD;
                    }
                    else if(( HSE_SRV_RSP_OK == gsrvResponse ) && (HSE_LC_OEM_PROD == gHseCurrentLC))
                    {
                        testStatus |= LIFECYCLE_ADVANCED_TO_OEM_PROD;
                    }
                    else
                    {

                    }
                }
                else if ( gHseCurrentLC == HSE_LC_IN_FIELD )
                {
                    /*Life cycle is already advanced from CUST_DEL*/
                    testStatus |= LIFECYCLE_ADVANCED_TO_INFIELD;
                }
                else if ( gHseCurrentLC == HSE_LC_OEM_PROD )
                {
                    testStatus |= LIFECYCLE_ADVANCED_TO_OEM_PROD;
                }
                else
                {

                }
            }
            else
            {

            }
            /*
             * user can requested IVT auth bit to be set by two ways
             * either by attribute programming option
             * or by enabling boot authentication.
             * Note: ADKP shall be programmed prior to this operation
             * and this is one-time programmable and operation cannot be reversed
             * back i.e. before HSE or app boot, IVT will always be authenticated
             */
            if( (ENABLE_AUTH_MODE == gProgramAttributes) || (ENABLE_AUTH_MODE == gEnableIVTAuthBit) )
            {
                /*read first to confirm if IVT auth already enabled*/
                gsrvResponse = HSE_GetIVTauthbit(&gIVTauthvalue);
                /*check if ADKP is programmed*/
                if( (ADKP_PROGRAMMING_SUCCESS == ( testStatus & ADKP_PROGRAMMING_SUCCESS))
                        && (TRUE == write_attr)  && (0U == gIVTauthvalue) )
                {
                    /*
                     * only if IVT auth bit is not set and ADKP is programmed,
                     * will the user be allowed to change enable boot auth
                     */
                    if(( HSE_IVT_NO_AUTH == gIVTauthvalue ) &&
                       ( HSE_SRV_RSP_OK == gsrvResponse )
                      )
                    {
                        gsrvResponse = HSE_SRV_RSP_GENERAL_ERROR;
                        gsrvResponse = UpdateIvt( NON_SECURE_IVT );
                        /*
                         * write IVT auth bit executed and then read back to
                         * confirm that value was written as expected
                         */
                        gsrvResponse = HSE_EnableIVTAuthentication();
                        if( HSE_SRV_RSP_OK == gsrvResponse)
                        {
                            (void)HSE_GetIVTauthbit(&gIVTauthvalue);
                            if( HSE_IVT_AUTH == gIVTauthvalue)
                                testStatus |= IVT_AUTHENTICATION_ENABLED;
                        }
                    }
                }
                else if (HSE_IVT_AUTH == gIVTauthvalue)
                {
                    testStatus |= IVT_AUTHENTICATION_ENABLED;
                    gsrvResponse = HSE_SRV_RSP_GENERAL_ERROR;
                }
            }
            /*user requested second MU to be enabled*/
            else if( CONFIG_MU == gProgramAttributes )
            {
                gsrvResponse = HSE_SRV_RSP_GENERAL_ERROR;
                if( HSE_SRV_RSP_OK == HSE_GetMUAttribute(&Read_hseMuConfigValue) && (TRUE == write_attr)
                        && ( Read_hseMuConfigValue.muInstances[MU1].muConfig != WriteMu1Config ) )
                {
                    /*read back the MU configuration*/
                    gsrvResponse = HSE_ConfigNvmAttributes(WriteMu1Config);
                }
                if( HSE_SRV_RSP_OK == gsrvResponse)
                {
                    gsrvResponse = HSE_GetMUAttribute(&Read_hseMuConfigValue);
                }
                ReadMu1Config = Read_hseMuConfigValue.muInstances[MU1].muConfig;
            }
            else
            {

            }
            /*user requested to erase keys*/
            if( ERASE_KEYS == gProgramAttributes )
            {
                gsrvResponse = HSE_SRV_RSP_GENERAL_ERROR;
                gsrvResponse = HSE_EraseKeys();
                if(HSE_SRV_RSP_OK == gsrvResponse)
                {
                    testStatus |= NVM_DATA_ERASED;
                }
            }

        }
        /*
         * user has requested to execute all cryptographic services.
         * Keys shall be formatted prior to executing any cryptographic services.
         */
        if( APP_RUN_HSE_CRYPTOGRAPHIC_SERVICES == gRunExampleTest )
        {
            /*HSE crypto examples: sym/asym services; sync/async operation mode*/
            gsrvResponse = HSE_Crypto();
        }
        /*
         * user requested firmware update, following sequence for fw update:
         * 1) Read firmware version of current HSE FW in the device
         * 2) Save this firmware version value
         * 3) Issue fw update request along with new address where encrypted fw
         *    image is kept that has to be updated
         * 4) Poll for HSE_INSTALL_OK bit to make sure new HSE hse installed
         * 5) Read again firmware version of newly updated HSE FW.
         * 6) Compare the saved hse fw version with newly updated HSE fw version
         * 7) If the latter is greater or equal to the former, we confirm that
         *    HSE FW update request is successful.
         */
        else if( APP_HSE_FW_UPDATE == gRunExampleTest )
        {
            gsrvResponse = HSE_SRV_RSP_GENERAL_ERROR;
            memset((void*)fwversion, 0, 0x20);

            /* Get the HSE version before requesting for FW update */
            (void)HSE_GetVersion_Example( &fwversion[0] );
            if( fwudpate_only == TRUE )
            {
                HSE_FwUpdateExample(gNewHseFwAddress);
                /* Wait for HSE to initialize(read status bits) after successful update */
                while((HSE_STATUS_INIT_OK & HSE_MU_GetHseStatus(0U)) == 0U)
                {
                    gInstallNewHSEFwTest = FW_NOT_INSTALLED;
                }
                gInstallNewHSEFwTest = FW_INSTALLED;
                /* Get the HSE version after requesting for FW update */
                (void)HSE_GetVersion_Example(&fwversion[1]);
                testStatus |= FW_UPDATE_SUCCESS;
            }
            else if( TRUE == ActivatePassiveBlock )
            {
                /* Take backup if Active Passive switch is requested */
                if( gHseFwVersion.reserved == 1 )
                {
                    /* Take backup of demo app, secure boot and IVT for BSB */
                    BackUp();
                }

                gsrvResponse = HSE_ActivatePassiveBlock();
                if(HSE_SRV_RSP_OK == gsrvResponse)
                {
                	testStatus |= ACTIVATE_PASSIVE_BLOCK_SUCCESSFUL;
                }
            }
        }
        else if( APP_SECURE_BOOT_CONFIGURED == gRunExampleTest )
        {
        	/* Always Erase NVM before Secure Boot */
            gsrvResponse = HSE_EraseKeys();
            if(HSE_SRV_RSP_OK == gsrvResponse)
            {
            	/* Wait for HSE to initialize(read status bits) after installation */
				while((HSE_STATUS_INIT_OK & HSE_MU_GetHseStatus(0)) == 0);
            	testStatus |= NVM_DATA_ERASED;
            	/* Format Key Catalogs after NVM Erase */
                formatkey_srvResponse = HSE_Config();
                if(HSE_SRV_RSP_OK == formatkey_srvResponse)
                {
                	testStatus |= KEY_CATALOGS_FORMATTED;
                	/* Import keys for cryptographic operation and secure boot */
					ASSERT(HSE_SRV_RSP_OK == Generic_ImportKeys());
                }
            }

            /* configure secure boot first */
            gsrvResponse = SecureBootConfiguration();
            ASSERT( HSE_SRV_RSP_OK == gsrvResponse);

            /* enable secure boot */
            gsrvResponse = UpdateIvt( SECURE_IVT );
            ASSERT( HSE_SRV_RSP_OK == gsrvResponse);
            testStatus |= SECURE_BOOT_CONFIGURATION_DONE;
        }
        else
        {

        }
        /* this variable will be set by scripts when test output have been checked */
        while(!allTestExecuted);
        /* reset all variables to avoid re-run */
        reset_tests();
    }
}

static void reset_tests(void)
{
    gProgramAttributes  = NO_ATTRIBUTE_PROGRAMMED;
    gsrvResponse        = HSE_SRV_RSP_GENERAL_ERROR;
    gRunExampleTest     = APP_NO_TEST_RUNNING;
    gEnableIVTAuthBit   = NO_ATTRIBUTE_PROGRAMMED;
    gADKPmasterbit      = FALSE;
    ReadMu1Config       = 0U;
    WriteMu1Config      = 0U;
    GetStartAsUserBit   = 0x7F;
    GetEnableAdkmBit    = 0x7F;
    allTestExecuted     = 0U;
    write_attr          = FALSE;
    fwudpate_only       = FALSE;
    ActivatePassiveBlock= FALSE;
    testStatus          = NO_TEST_EXECUTED;
}

void CopyFlashToSRAMHseHost(void)
{
    volatile uint32_t* FlashRamAddr=0U;
    volatile uint32_t* FlashSrcAddr=0U;
    volatile uint32_t* FlashSrcEndAddr=0U;
    uint32_t i=0U;

    FlashRamAddr=HSE_HOST_RAM_DST_START_ADDR ;
    FlashSrcAddr=HSE_HOST_FLASH_SRC_START_ADDR ;
    FlashSrcEndAddr=HSE_HOST_FLASH_SRC_END_ADDR ;

    /*Copying the UnsecureBAF Code from flash to RAM to avoid read while write
     *  violation */
    for(i=0U;i<(((uint32_t)FlashSrcEndAddr-(uint32_t)FlashSrcAddr)/4U);i++)
    {
        FlashRamAddr[i]=FlashSrcAddr[i];
    }
}

static hseSrvResponse_t HSE_CalculateAdkpHash( uint8_t *pDebugKey )
{
    uint8_t local_adkp_hash[32] = {0U};
    uint32_t hash_length = 32U;
    uint8_t uid[8] = {0};
    hseSrvResponse_t srvResponse = HSE_SRV_RSP_GENERAL_ERROR;
    uint8_t output[32] = {0U};
    uint8_t uid_hash[32] = {0U};
    hseAttrExtendCustSecurityPolicy_t hseSecurityPolicy = {0};

    (void)HSE_ReadAttrExtendCustSecurityPolicy((hseAttrExtendCustSecurityPolicy_t *)&hseSecurityPolicy);

    if(hseSecurityPolicy.enableADKm == TRUE)
    {
        /* calculate SHA256 hash of ADKP */
        srvResponse = HSE_HashDataBlocking
                    (
                            MU0,
                            HSE_ACCESS_MODE_ONE_PASS,
                            0,
                            HSE_HASH_ALGO_SHA2_256,
                            (const uint8_t *)&applicationDebugKeyPassword[0],
                            sizeof(hseAttrApplDebugKey_t),
                            (uint8_t *)&local_adkp_hash,
                            &hash_length
                    );

        ASSERT(HSE_SRV_RSP_OK == srvResponse);

        /* calculate SHA256 hash of UID */
        memcpy((uint8_t*)uid, (uint8_t*)(UTEST_BASE_ADDRESS + UID_OFFSET), 8UL);
        srvResponse = HSE_HashDataBlocking
                (
                        MU0,
                        HSE_ACCESS_MODE_ONE_PASS,
                        0,
                        HSE_HASH_ALGO_SHA2_256,
                        (const uint8_t *)(uid),
                        8UL,
                        (uint8_t *)&uid_hash,
                        &hash_length
                );

        ASSERT(HSE_SRV_RSP_OK == srvResponse);

        /* encrypt UID hash with ADKP hash as key */
        /* import key */
        srvResponse = ImportPlainSymKeyReq(
                RAM_AES128_ADKP_KEY,
                HSE_KEY_TYPE_AES,
                HSE_KF_USAGE_ENCRYPT,
                hash_length,
                local_adkp_hash
                );
        ASSERT(HSE_SRV_RSP_OK == srvResponse);

        srvResponse = AesEncrypt( RAM_AES128_ADKP_KEY, HSE_CIPHER_BLOCK_MODE_ECB,
                0UL, 16UL, uid_hash, output, HSE_SGT_OPTION_NONE);
        ASSERT(HSE_SRV_RSP_OK == srvResponse);

        /* calculate SHA224  */
        srvResponse = HSE_HashDataBlocking
                (
                        MU0,
                        HSE_ACCESS_MODE_ONE_PASS,
                        0,
                        HSE_HASH_ALGO_SHA2_224,
                        (const uint8_t *)&output[0],
                        16UL,
                        pDebugKey,
                        &hash_length
                );
        ASSERT(HSE_SRV_RSP_OK == srvResponse);
    }
    else
    {
        //read adkp hash simple
        srvResponse = HSE_CalculateHASH(pDebugKey);
        ASSERT(HSE_SRV_RSP_OK == srvResponse);
    }
    return HSE_SRV_RSP_OK;
}


static void BackUp(void)
{
    Fls_CheckStatusType fls_status = FLS_JOB_FAILED;
    //copy IVT
    memcpy((void *)&IVT, (void *)BLOCK0_IVT_ADDRESS, 0x100);
    //Take backup of following sections

    //1)IVT
    fls_status = HostFlash_Erase(
                HOST_CODE_MEMORY_TYPE,
                (BLOCK0_IVT_ADDRESS + BACKUP_ADDRESS_OFFSET),
                1U);
    ASSERT( fls_status == FLS_JOB_OK);

    fls_status = HostFlash_Program(
            HOST_CODE_MEMORY_TYPE,
            (BLOCK0_IVT_ADDRESS + BACKUP_ADDRESS_OFFSET),
            (uint8_t* )BLOCK0_IVT_ADDRESS,
            0x2000UL );

    fls_status = HostFlash_Erase(
            HOST_CODE_MEMORY_TYPE,
            ((IVT.pAppImg_addr_0) + BACKUP_ADDRESS_OFFSET),
            12U);
    ASSERT( fls_status == FLS_JOB_OK);
    //1) demo app code
    fls_status = HostFlash_Program(
            HOST_CODE_MEMORY_TYPE,
            ((IVT.pAppImg_addr_0) + BACKUP_ADDRESS_OFFSET),
            (uint8_t* )(IVT.pAppImg_addr_0),
            0x18000UL
            );
    ASSERT( fls_status == FLS_JOB_OK);
    //2) IVT for BaseSB and secure boot app code and xrdc
    fls_status = HostFlash_Erase(
                HOST_CODE_MEMORY_TYPE,
                ((IVT.pAppImg_addr_1-0x0FC0UL) + BACKUP_ADDRESS_OFFSET),
                3U);
        ASSERT( fls_status == FLS_JOB_OK);
    fls_status = HostFlash_Program(
                HOST_CODE_MEMORY_TYPE,
                ((IVT.pAppImg_addr_1-0x0FC0UL) + BACKUP_ADDRESS_OFFSET),
                (uint8_t* )(IVT.pAppImg_addr_1-0x0FC0UL),    /* secure boot application */
                0x6000UL
                );
    ASSERT( fls_status == FLS_JOB_OK);
}

#ifdef __cplusplus
}
#endif

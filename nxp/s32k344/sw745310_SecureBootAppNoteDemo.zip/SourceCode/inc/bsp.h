/*
 * bsp.h
 *
 *  Created on: Jan 27, 2021
 *      Author: nxf55009
 */

#ifndef BSP_H_
#define BSP_H_

#include <printf.h>
#include "Mcal.h"
#include "Clock_Ip.h"
#include "OsIf.h"
#include "IntCtrl_Ip.h"
#include "Siul2_Port_Ip.h"
#include "Siul2_Dio_Ip.h"
#include "Siul2_Icu_Ip.h"
#include "Pit_Ip.h"
#include "Lpuart_Uart_Ip.h"
#include "Power_Ip.h"
#include "Power_Ip_MC_ME.h"
#include "Cache_Ip.h"
#include "Mpu_M7_Ip.h"

#include "string.h"
#include "Hse_Ip.h"

#include "hse_interface.h"
#include "hse_host.h"
#include "demo_app_services.h"
#include "hse_host_attrs.h"






/******************************************************************************************************************************/

#define BTN_DIO_INSTANCE	(0U)
#define BTN_DIO_SW2_CHANNEL		(84U)
#define BTN_DIO_SW3_CHANNEL		(85U)

#define BTN_ICU_INSTANCE	(0U)
#define BTN_ICU_SW2_CHANNEL		(16U)
#define BTN_ICU_SW3_CHANNEL		(17U)

/******************************************************************************************************************************/



/******************************************************************************************************************************/

#define LED_DIO_PORT	(PTF_L_HALF)
#define LED_DIO_Q1_PIN		(8U)
#define LED_DIO_Q2_PIN		(9U)
#define LED_DIO_Q3_PIN		(10U)
#define LED_DIO_Q4_PIN		(11U)

#define IO_TOGGLE_PORT    (PTA_L_HALF)
#define IO_TOGGLE_PIN      (13U)



/******************************************************************************************************************************/



/******************************************************************************************************************************/

#define PIT_INST        0U      /*!< PIT instance used - 0 */
#define PIT_PERIOD      24E6
#define PIT_CLK         24E6

/******************************************************************************************************************************/

#define MEASURE_PERFORMANCE (false)

/******************************************************************************************************************************/

extern volatile uint8_t erase_flag ;

extern volatile uint8_t reset_flag ;

/******************************************************************************************************************************/



#if ( true == MEASURE_PERFORMANCE )

#define TOGGLE_IO() \
    do\
    {\
        Siul2_Dio_Ip_TogglePins( IO_TOGGLE_PORT, (1<<IO_TOGGLE_PIN));\
        Siul2_Dio_Ip_TogglePins( IO_TOGGLE_PORT, (1<<IO_TOGGLE_PIN));\
    }\
    while(0);

#else

#define TOGGLE_IO()

#endif




void BSP_Init(void) ;

#endif /* BSP_H_ */

/**
*   @file    hse_fuses.c
*
*   @brief   Examples of HSE UTEST  programming.
*
*   @addtogroup [hse_utest]
*   @{
*/
/*==================================================================================================
*
*   Copyright 2020-2021 NXP.
*
*   This software is owned or controlled by NXP and may only be used strictly in accordance with
*   the applicable license terms. By expressly accepting such terms or by downloading, installing,
*   activating and/or otherwise using the software, you are agreeing that you have read, and that
*   you agree to comply with and are bound by, such license terms. If you do not agree to
*   be bound by the applicable license terms, then you may not retain, install, activate or
*   otherwise use the software.
==================================================================================================*/

#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/

#include "global_variables.h"
#include "hse_host_attrs.h"

#include "string.h"

/*=============================================================================
*                          LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
=============================================================================*/

/*=============================================================================
*                                       LOCAL MACROS
=============================================================================*/

/*=============================================================================
*                                      LOCAL CONSTANTS
=============================================================================*/

/*=============================================================================
*                                      LOCAL VARIABLES
=============================================================================*/

/*=============================================================================
*                                      GLOBAL CONSTANTS
=============================================================================*/

/*=============================================================================
*                                      GLOBAL VARIABLES
=============================================================================*/

/*=============================================================================
*                                   LOCAL FUNCTION PROTOTYPES
=============================================================================*/

/*=============================================================================
*                                       LOCAL FUNCTIONS
=============================================================================*/

/*=============================================================================
*                                       GLOBAL FUNCTIONS
=============================================================================*/


/*****************************************************************************
 * Function:    HSE_EnableIVTAuthentication
 * Description: Function for enabling IVT authentication
 *              When authentication of IVT is enabled, during startup,
 *              IVT will be authenticated
 *              and then only execution will go to HSE FW
*****************************************************************************/
hseSrvResponse_t HSE_EnableIVTAuthentication( void )
{
    hseSrvResponse_t srvResponse;
    hseAttrConfigBootAuth_t configIvtAth;

    /* WARNING: This operation is irreversible */
    /* Enable IVT authentication */
    configIvtAth = HSE_IVT_AUTH;

    srvResponse = SetAttr
            (
                    HSE_ENABLE_BOOT_AUTH_ATTR_ID,
                    sizeof(hseAttrConfigBootAuth_t),
                    (void *)&configIvtAth
            );
    ASSERT(HSE_SRV_RSP_OK == srvResponse);
    return srvResponse;

}

/******************************************************************************
 * Function:    HSE_GetIVTauthbit
 * Description: Function for reading IVT authentication bit
******************************************************************************/
hseSrvResponse_t HSE_GetIVTauthbit( hseAttrConfigBootAuth_t *pIvtValue )
{
    hseSrvResponse_t srvResponse;

    srvResponse = GetAttr
            (
                    HSE_ENABLE_BOOT_AUTH_ATTR_ID,
                    sizeof(hseAttrConfigBootAuth_t),
                    (void *)pIvtValue
            );
    ASSERT(HSE_SRV_RSP_OK == srvResponse);
    return srvResponse;
}
#ifdef __cplusplus
}
#endif

/** @} */
